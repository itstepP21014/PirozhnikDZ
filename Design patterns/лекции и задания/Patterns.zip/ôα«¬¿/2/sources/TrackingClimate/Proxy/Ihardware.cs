﻿
namespace TrackingClimate
{
    // Интерфес доступа к классу управляющего оборудованием.
    interface Ihardware
    {
        void Watering(Plan a);
    }
}
