﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class TestControl : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.test.Value = "Hello!";
            var data = GetFakeInformation();
            data.ForEach(d =>
            {
                CheckBoxListInformation.Items.Add(d.Name);
            });
            }            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            this.Response.Output.WriteLine("Hello!");
        }

        protected new void PreRenderComplete(object sender, EventArgs e)
        {

        }

        protected List<Dto> GetFakeInformation()
        {
            var result = new List<Dto>();
            for (var i = 0; i < 10; i++)
            {
                result.Add(new Dto() { Name = string.Format("RowNumber: {0}", i) });
            }
            return result;
        }

        protected void Repeater1_ItemCreated(object sender, RepeaterItemEventArgs e)
        {
            //e.Item.FindControl
        }

        protected void CheckBoxListInformation_SelectedIndexChanged(object sender, EventArgs e)
        {
            var collection = new List<Dto>();
            var builder = new StringBuilder();

            foreach(ListItem i in CheckBoxListInformation.Items)
            {
                if (i.Selected)
                {
                    builder.AppendLine(i.Value);
                    collection.Add(new Dto() { Name = i.Value });
                }
            }
            Repeater1.DataSource = collection;
            Repeater1.DataBind();
            this.Response.Output.WriteLine(builder.ToString());
            
        }
    }

    public class Dto
    {
        public string Name { get; set; }
    }
}