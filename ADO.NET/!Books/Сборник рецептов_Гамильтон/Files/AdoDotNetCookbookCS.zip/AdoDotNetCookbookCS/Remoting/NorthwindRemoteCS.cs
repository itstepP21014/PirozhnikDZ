using System;

using System.Data;
using System.Data.SqlClient;

public class RemoteClass : MarshalByRefObject
{
	public const String SQL_CONNECTIONSTRING	= "Data Source=(local);Integrated security=SSPI;Initial Catalog=Northwind;";

	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";

	public DataSet LoadOrders()
	{
		DataSet ds = new DataSet();
	
		SqlDataAdapter da;

		// fill the Order table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders", SQL_CONNECTIONSTRING);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.FillSchema(orderTable, SchemaType.Source);
		da.Fill(orderTable);
		ds.Tables.Add(orderTable);

		// fill the OrderDetails table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM [Order Details]", SQL_CONNECTIONSTRING);
		DataTable orderDetailTable = new DataTable(ORDERDETAILS_TABLE);
		da.FillSchema(orderDetailTable, SchemaType.Source);
		da.Fill(orderDetailTable);
		ds.Tables.Add(orderDetailTable);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
			ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
			true);

		return ds;
	}

	public bool UpdateOrders(DataSet ds)
	{
		// create the DataAdapters for order and order details tables
		SqlDataAdapter daOrders = new SqlDataAdapter("SELECT * FROM Orders", SQL_CONNECTIONSTRING);
		SqlDataAdapter daOrderDetails = new SqlDataAdapter("SELECT * FROM [Order Details]", SQL_CONNECTIONSTRING);

		// use CommandBuilder to generate update logic
		SqlCommandBuilder cbOrders = new SqlCommandBuilder(daOrders);
		SqlCommandBuilder cbOrderDetails = new SqlCommandBuilder(daOrderDetails);

		// update parent and child records
		daOrderDetails.Update(ds.Tables[ORDERDETAILS_TABLE].Select(null, null, DataViewRowState.Deleted));
		daOrders.Update(ds.Tables[ORDERS_TABLE].Select(null, null, DataViewRowState.Deleted));
		daOrders.Update(ds.Tables[ORDERS_TABLE].Select(null, null, DataViewRowState.ModifiedCurrent));
		daOrders.Update(ds.Tables[ORDERS_TABLE].Select(null, null, DataViewRowState.Added));
		daOrderDetails.Update(ds.Tables[ORDERDETAILS_TABLE].Select(null, null, DataViewRowState.ModifiedCurrent));
		daOrderDetails.Update(ds.Tables[ORDERDETAILS_TABLE].Select(null, null, DataViewRowState.Added));
	
		return true;
	}	
}