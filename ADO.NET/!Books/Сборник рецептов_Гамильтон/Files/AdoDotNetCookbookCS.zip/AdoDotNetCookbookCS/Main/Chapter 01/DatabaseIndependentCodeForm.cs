using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.OleDb;

public class DatabaseIndependentCodeForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button sqlButton;
	private System.Windows.Forms.Button oleDbButton;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DatabaseIndependentCodeForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.sqlButton = new System.Windows.Forms.Button();
		this.oleDbButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 0;
		// 
		// sqlButton
		// 
		this.sqlButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.sqlButton.Location = new System.Drawing.Point(328, 232);
		this.sqlButton.Name = "sqlButton";
		this.sqlButton.TabIndex = 1;
		this.sqlButton.Text = "SQL";
		this.sqlButton.Click += new System.EventHandler(this.sqlButton_Click);
		// 
		// oleDbButton
		// 
		this.oleDbButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.oleDbButton.Location = new System.Drawing.Point(408, 232);
		this.oleDbButton.Name = "oleDbButton";
		this.oleDbButton.TabIndex = 2;
		this.oleDbButton.Text = "OLE DB";
		this.oleDbButton.Click += new System.EventHandler(this.oleDbButton_Click);
		// 
		// DatabaseIndependentCodeForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.oleDbButton);
		this.Controls.Add(this.sqlButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "DatabaseIndependentCodeForm";
		this.Text = "1.11 DatabaseIndependentCodeForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void GetData(IDbConnection conn, IDbDataAdapter da)
	{
		// create the command and assign it to the IDbDataAdapter interface
		IDbCommand cmd = conn.CreateCommand();
		cmd.CommandText = "SELECT * FROM Customers";
		da.SelectCommand = cmd;
		// add a table mapping
		da.TableMappings.Add("Table", "Customers");

		dataGrid.DataSource = null;

		// fill the DataSet
		DataSet ds = new DataSet();
		da.Fill(ds);

		// bind the default view for the Customer table to the grid
		dataGrid.DataSource = ds.Tables["Customers"].DefaultView;

		// identify provider-specific connection type and process appropriately
		if (conn is SqlConnection)
		{
			MessageBox.Show("Specific processing for SQL data provider.");
		}
		else if(conn is OleDbConnection)
		{
			MessageBox.Show("Specific processing for OLE DB data provider.");
		}
	}
	private void sqlButton_Click(object sender, System.EventArgs e)
	{
		// Create a SQL Connection and DataAdapter
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlDataAdapter da = new SqlDataAdapter();

		dataGrid.CaptionText = "SQL .NET Provider";

		// call provider independent function to retrieve data
		GetData(conn, da);
	}

	private void oleDbButton_Click(object sender, System.EventArgs e)
	{
		// Create a OLE DB Connection and DataAdapter
		OleDbConnection conn = new OleDbConnection(ConfigurationSettings.AppSettings["OleDb_ConnectString"]);
		OleDbDataAdapter da = new OleDbDataAdapter();

		dataGrid.CaptionText = "OLE DB .NET Provider";

		// call provider independent function to retrieve data
		GetData(conn, da);
	}
}