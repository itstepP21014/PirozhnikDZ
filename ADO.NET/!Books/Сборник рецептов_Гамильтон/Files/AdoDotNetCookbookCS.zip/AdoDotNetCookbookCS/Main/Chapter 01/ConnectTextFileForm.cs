using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.OleDb;

public class ConnectTextFileForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.DataGrid categoriesDataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ConnectTextFileForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.categoriesDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.categoriesDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.goButton.Location = new System.Drawing.Point(208, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// categoriesDataGrid
		// 
		this.categoriesDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.categoriesDataGrid.DataMember = "";
		this.categoriesDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.categoriesDataGrid.Location = new System.Drawing.Point(8, 8);
		this.categoriesDataGrid.Name = "categoriesDataGrid";
		this.categoriesDataGrid.Size = new System.Drawing.Size(276, 216);
		this.categoriesDataGrid.TabIndex = 1;
		// 
		// ConnectTextFileForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.Add(this.categoriesDataGrid);
		this.Controls.Add(this.goButton);
		this.Name = "ConnectTextFileForm";
		this.Text = "1.19 ConnectTextFileForm";
		((System.ComponentModel.ISupportInitialize)(this.categoriesDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		// create the data adapter to retrieve all rows from text file
		OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [Categories.txt]",
			ConfigurationSettings.AppSettings["TextFile_0119_ConnectString"]);

		// create and fill the table
		DataTable dt = new DataTable("Categories");
		da.Fill(dt);

		// bind the default view of the table to the grid
		categoriesDataGrid.DataSource = dt.DefaultView;
	}
}