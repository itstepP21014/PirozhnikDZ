using System;
using System.Configuration;

using System.Data;
using System.Data.Odbc;

public class OdbcConnectForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button connectButton;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public OdbcConnectForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.connectButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// connectButton
		// 
		this.connectButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.connectButton.Location = new System.Drawing.Point(408, 232);
		this.connectButton.Name = "connectButton";
		this.connectButton.TabIndex = 0;
		this.connectButton.Text = "Connect";
		this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 1;
		// 
		// OdbcConnectForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.connectButton);
		this.Name = "OdbcConnectForm";
		this.Text = "1.01 OdbcConnectForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void connectButton_Click(object sender, System.EventArgs e)
	{
		// create the DataAdapter
		String sqlSelect = "SELECT CategoryID, CategoryName, Description " +
			"FROM Categories";
		OdbcDataAdapter da = new OdbcDataAdapter(sqlSelect, ConfigurationSettings.AppSettings["Odbc_ConnectString"]);

		// create the table, fill it, and bind the default view to the grid
		DataTable dt = new DataTable();
		da.Fill(dt);
		dataGrid.DataSource = dt.DefaultView;
	}
}