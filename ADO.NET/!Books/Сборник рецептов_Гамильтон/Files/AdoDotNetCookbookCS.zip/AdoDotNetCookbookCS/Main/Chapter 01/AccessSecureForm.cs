using System;
using System.Configuration;
using System.Text;

using System.Data.OleDb;

public class AccessSecureForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox passwordTextBox;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button connectButton;
	private System.Windows.Forms.TextBox userIdTextBox;
	private System.Windows.Forms.Label label2;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AccessSecureForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.label1 = new System.Windows.Forms.Label();
		this.passwordTextBox = new System.Windows.Forms.TextBox();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.connectButton = new System.Windows.Forms.Button();
		this.userIdTextBox = new System.Windows.Forms.TextBox();
		this.label2 = new System.Windows.Forms.Label();
		this.SuspendLayout();
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(9, 32);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(64, 23);
		this.label1.TabIndex = 7;
		this.label1.Text = "Password:";
		// 
		// passwordTextBox
		// 
		this.passwordTextBox.Location = new System.Drawing.Point(73, 32);
		this.passwordTextBox.Name = "passwordTextBox";
		this.passwordTextBox.Size = new System.Drawing.Size(112, 20);
		this.passwordTextBox.TabIndex = 2;
		this.passwordTextBox.Text = "user1password";
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(9, 64);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 192);
		this.resultTextBox.TabIndex = 5;
		this.resultTextBox.Text = "";
		// 
		// connectButton
		// 
		this.connectButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.connectButton.Location = new System.Drawing.Point(409, 9);
		this.connectButton.Name = "connectButton";
		this.connectButton.TabIndex = 3;
		this.connectButton.Text = "Connect";
		this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
		// 
		// userIdTextBox
		// 
		this.userIdTextBox.Location = new System.Drawing.Point(72, 8);
		this.userIdTextBox.Name = "userIdTextBox";
		this.userIdTextBox.Size = new System.Drawing.Size(112, 20);
		this.userIdTextBox.TabIndex = 1;
		this.userIdTextBox.Text = "user1";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 8);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(56, 23);
		this.label2.TabIndex = 9;
		this.label2.Text = "User ID:";
		// 
		// AccessSecureForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.userIdTextBox);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.passwordTextBox);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.connectButton);
		this.Name = "AccessSecureForm";
		this.Text = "1.04 AccessSecureForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void connectButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// build the connection string with security information
		String connectionString =
			ConfigurationSettings.AppSettings["MsAccess_ConnectString"] +
			@"Jet OLEDB:System database=" +
			ConfigurationSettings.AppSettings["MsAccess_SecureMdw_Filename"] + ";" +
			"User ID=" + userIdTextBox.Text + ";" +
			"Password=" + passwordTextBox.Text + ";" +
			Environment.NewLine + Environment.NewLine;

		result.Append(connectionString);

		// create the connection
		OleDbConnection conn = new OleDbConnection(connectionString);

		try
		{
			// attempt to open the connection
			conn.Open();

			result.Append(
				"Connection State: " + conn.State + Environment.NewLine +
				"OLE DB Provider: " + conn.Provider + Environment.NewLine +
				"Server Version: " + conn.ServerVersion + Environment.NewLine);

			conn.Close();

			result.Append("Connection State: " + conn.State + Environment.NewLine);
		}
		catch(System.Data.OleDb.OleDbException ex)
		{
			result.Append("ERROR: " + ex.Message);
		}

		resultTextBox.Text = result.ToString();
	}
}