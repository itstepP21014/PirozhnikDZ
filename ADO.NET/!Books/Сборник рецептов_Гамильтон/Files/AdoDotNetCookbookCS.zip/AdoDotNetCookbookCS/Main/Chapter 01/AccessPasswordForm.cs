using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.OleDb;

public class AccessPasswordForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button connectButton;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.TextBox passwordTextBox;
	private System.Windows.Forms.Label label1;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AccessPasswordForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.connectButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.passwordTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.SuspendLayout();
		// 
		// connectButton
		// 
		this.connectButton.Location = new System.Drawing.Point(208, 8);
		this.connectButton.Name = "connectButton";
		this.connectButton.TabIndex = 0;
		this.connectButton.Text = "Connect";
		this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 40);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(276, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// passwordTextBox
		// 
		this.passwordTextBox.Location = new System.Drawing.Point(72, 8);
		this.passwordTextBox.Name = "passwordTextBox";
		this.passwordTextBox.Size = new System.Drawing.Size(112, 20);
		this.passwordTextBox.TabIndex = 2;
		this.passwordTextBox.Text = "password";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(64, 23);
		this.label1.TabIndex = 3;
		this.label1.Text = "Password:";
		// 
		// AccessPasswordForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.passwordTextBox);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.connectButton);
		this.Name = "AccessPasswordForm";
		this.Text = "1.03 AccessPasswordForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void connectButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// build the connections string incorporating the password
		String connectionString =
			ConfigurationSettings.AppSettings["MsAccess_Secure_ConnectString"] +
			"Jet OLEDB:Database Password=" + passwordTextBox.Text + ";";

		result.Append("ConnectionString: " + Environment.NewLine +
			connectionString + Environment.NewLine + Environment.NewLine);

		OleDbConnection conn = new OleDbConnection(connectionString);
		try
		{
			conn.Open();

			// retrieve some database information
			result.Append(
				"Connection State: " + conn.State + Environment.NewLine +
				"OLE DB Provider: " + conn.Provider +
				Environment.NewLine +
				"Server Version: " + conn.ServerVersion +
				Environment.NewLine);

			conn.Close();
			result.Append("Connection State: " + conn.State);
		}
		catch(System.Data.OleDb.OleDbException ex)
		{
			conn.Close();
			result.Append("ERROR: " + ex.Message);
		}

		resultTextBox.Text = result.ToString();
	}
}