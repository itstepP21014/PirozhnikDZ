using System;
using System.Configuration;

using System.Data.OleDb;
using System.Data.OracleClient;

public class ConnectOracleForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button oracleProviderButton;
	private System.Windows.Forms.Button oleDbButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ConnectOracleForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.oracleProviderButton = new System.Windows.Forms.Button();
		this.oleDbButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 0;
		this.resultTextBox.Text = "";
		// 
		// oracleProviderButton
		// 
		this.oracleProviderButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.oracleProviderButton.Location = new System.Drawing.Point(388, 232);
		this.oracleProviderButton.Name = "oracleProviderButton";
		this.oracleProviderButton.Size = new System.Drawing.Size(96, 23);
		this.oracleProviderButton.TabIndex = 1;
		this.oracleProviderButton.Text = "Oracle Provider";
		this.oracleProviderButton.Click += new System.EventHandler(this.oracleProviderButton_Click);
		// 
		// oleDbButton
		// 
		this.oleDbButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.oleDbButton.Location = new System.Drawing.Point(304, 232);
		this.oleDbButton.Name = "oleDbButton";
		this.oleDbButton.TabIndex = 2;
		this.oleDbButton.Text = "OLE DB";
		this.oleDbButton.Click += new System.EventHandler(this.oleDbButton_Click);
		// 
		// ConnectOracleForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.oleDbButton);
		this.Controls.Add(this.oracleProviderButton);
		this.Controls.Add(this.resultTextBox);
		this.Name = "ConnectOracleForm";
		this.Text = "1.10 ConnectOracleForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void oracleProviderButton_Click(object sender, System.EventArgs e)
	{
		// connect to Oracle using Microsoft Oracle .NET data provider
		OracleConnection conn =
			new OracleConnection(ConfigurationSettings.AppSettings["Oracle_Scott_ConnectString"]);

		resultTextBox.Text = "Connection with ORACLE Provider" +
			Environment.NewLine;
		try
		{
			conn.Open();

			resultTextBox.Text +=
				"ConnectionState = " + conn.State + Environment.NewLine +
				"DataSource = " + conn.DataSource +	Environment.NewLine +
				"ServerVersion = " + conn.ServerVersion + Environment.NewLine;
		}
		catch(OracleException ex)
		{
			resultTextBox.Text += "ERROR: " + ex.Message;
		}
		finally
		{
			conn.Close();
			resultTextBox.Text += "ConnectionState = " + conn.State;
		}
	}

	private void oleDbButton_Click(object sender, System.EventArgs e)
	{
		// connect to Oracle using OLE DB .NET data provider
		OleDbConnection conn = new OleDbConnection(ConfigurationSettings.AppSettings["OleDb_Oracle_ConnectString"]);

		resultTextBox.Text = "Connection with OLE DB Provider" +
			Environment.NewLine;
		try
		{
			conn.Open();

			resultTextBox.Text +=
				"ConnectionState = " + conn.State + Environment.NewLine +
				"DataSource = " + conn.DataSource +	Environment.NewLine +
				"ServerVersion = " + conn.ServerVersion + Environment.NewLine;
		}
		catch(OleDbException ex)
		{
			resultTextBox.Text += "ERROR: " + ex.Message;
		}
		finally
		{
			conn.Close();
			resultTextBox.Text += "ConnectionState = " + conn.State + Environment.NewLine;
		}		
	}
}