using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class ChangeDatabaseForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox resultTextBox;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ChangeDatabaseForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}
	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(276, 248);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.TabStop = false;
		this.resultTextBox.Text = "";
		// 
		// ChangeDatabaseForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox});
		this.Name = "ChangeDatabaseForm";
		this.Text = "1.18 ChangeDatabaseForm";
		this.Load += new System.EventHandler(this.ChangeDatabaseForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void ChangeDatabaseForm_Load(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// create the connection accessing Northwind database
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		result.Append("Connection String:" + Environment.NewLine);
		result.Append(conn.ConnectionString + Environment.NewLine + Environment.NewLine);

		// open the connection
		conn.Open();
		result.Append("Connection.State: " + conn.State + Environment.NewLine);
		result.Append("Database: " + conn.Database + Environment.NewLine);

		// change the database to pubs
		conn.ChangeDatabase("pubs");
		result.Append("Database: " + conn.Database + Environment.NewLine);

		// close the connection
		conn.Close();
		result.Append("Connection.State: " + conn.State + Environment.NewLine);
		result.Append("Database: " + conn.Database);

		resultTextBox.Text = result.ToString();
	}
}