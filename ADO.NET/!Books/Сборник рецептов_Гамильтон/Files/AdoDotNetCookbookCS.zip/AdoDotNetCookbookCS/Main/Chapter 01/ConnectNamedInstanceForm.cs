using System;
using System.Configuration;
using System.Windows.Forms;
using System.Text;

using System.Data.SqlClient;

public class ConnectNamedInstanceForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button connectButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ConnectNamedInstanceForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.connectButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 3;
		this.resultTextBox.Text = "";
		// 
		// connectButton
		// 
		this.connectButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.connectButton.Location = new System.Drawing.Point(409, 234);
		this.connectButton.Name = "connectButton";
		this.connectButton.TabIndex = 2;
		this.connectButton.Text = "Connect";
		this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
		// 
		// ConnectNamedInstanceForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.connectButton);
		this.Name = "ConnectNamedInstanceForm";
		this.Text = "1.07 ConnectNamedInstanceForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void connectButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		SqlConnection conn =
			new SqlConnection(ConfigurationSettings.AppSettings["Sql_Msde_ConnectString"]);

		try
		{
			conn.Open();

			// return some information about the server
			result.Append(
				"ConnectionState = " + conn.State + Environment.NewLine +
				"DataSource = " + conn.DataSource + Environment.NewLine +
				"ConnectionState = " + conn.State + Environment.NewLine +
				"ServerVersion=" + conn.ServerVersion + Environment.NewLine);
		} 
		catch(Exception ex) 
		{
			MessageBox.Show(ex.Message);
		}
		finally
		{
			conn.Close();
		}

		result.Append("ConnectionState = " + conn.State);

		resultTextBox.Text = result.ToString();
	}
}