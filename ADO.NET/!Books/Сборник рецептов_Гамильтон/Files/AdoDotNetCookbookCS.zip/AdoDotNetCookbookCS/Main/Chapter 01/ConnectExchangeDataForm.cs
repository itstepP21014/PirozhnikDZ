using System;
using System.Windows.Forms;

using System.Data;
using System.Data.OleDb;

public class ConnectExchangeDataForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button connectButton;
	private System.Windows.Forms.TextBox tempPathTextBox;
	private System.Windows.Forms.TextBox mailboxNameTextBox;
	private System.Windows.Forms.TextBox profileTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ConnectExchangeDataForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.connectButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.mailboxNameTextBox = new System.Windows.Forms.TextBox();
		this.profileTextBox = new System.Windows.Forms.TextBox();
		this.tempPathTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// connectButton
		// 
		this.connectButton.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
		this.connectButton.Location = new System.Drawing.Point(408, 8);
		this.connectButton.Name = "connectButton";
		this.connectButton.TabIndex = 0;
		this.connectButton.Text = "Connect";
		this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 88);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 168);
		this.dataGrid.TabIndex = 1;
		// 
		// mailboxNameTextBox
		// 
		this.mailboxNameTextBox.Location = new System.Drawing.Point(96, 8);
		this.mailboxNameTextBox.Name = "mailboxNameTextBox";
		this.mailboxNameTextBox.Size = new System.Drawing.Size(184, 20);
		this.mailboxNameTextBox.TabIndex = 2;
		this.mailboxNameTextBox.Text = "";
		// 
		// profileTextBox
		// 
		this.profileTextBox.Location = new System.Drawing.Point(96, 32);
		this.profileTextBox.Name = "profileTextBox";
		this.profileTextBox.Size = new System.Drawing.Size(184, 20);
		this.profileTextBox.TabIndex = 3;
		this.profileTextBox.Text = "";
		// 
		// tempPathTextBox
		// 
		this.tempPathTextBox.Location = new System.Drawing.Point(96, 56);
		this.tempPathTextBox.Name = "tempPathTextBox";
		this.tempPathTextBox.Size = new System.Drawing.Size(184, 20);
		this.tempPathTextBox.TabIndex = 4;
		this.tempPathTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(80, 16);
		this.label1.TabIndex = 5;
		this.label1.Text = "Mailbox Name:";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 36);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(80, 16);
		this.label2.TabIndex = 6;
		this.label2.Text = "Profile:";
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(8, 60);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(80, 16);
		this.label3.TabIndex = 7;
		this.label3.Text = "TEMP Path:";
		// 
		// ConnectExchangeDataForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.label3,
																		this.label2,
																		this.label1,
																		this.tempPathTextBox,
																		this.profileTextBox,
																		this.mailboxNameTextBox,
																		this.dataGrid,
																		this.connectButton});
		this.Name = "ConnectExchangeDataForm";
		this.Text = "1.16 ConnectExchangeDataForm";
		this.Load += new System.EventHandler(this.ConnectExchangeDataForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void ConnectExchangeDataForm_Load(object sender,
		System.EventArgs e)
	{
		mailboxNameTextBox.Text = "Personal Folders";
		profileTextBox.Text = "Outlook";
	}

	private void connectButton_Click(object sender, System.EventArgs e)
	{
		String sqlText = "SELECT Subject, Contents FROM Inbox";

		// build the connection string
		String connectionString="Provider=Microsoft.Jet.OLEDB.4.0;" +
			"Outlook 9.0;" +
			"MAPILEVEL=" + mailboxNameTextBox.Text + "|;" +
			"PROFILE=" + profileTextBox.Text + ";" +
			"TABLETYPE=0;" +
			"DATABASE=" + System.IO.Path.GetTempPath();

		// create the DataAdapter
		OleDbDataAdapter da = new OleDbDataAdapter(sqlText, connectionString);

		// create and fill the table
		DataTable dt = new DataTable("Inbox");
		try
		{
			da.Fill(dt);
			dataGrid.DataSource = dt.DefaultView;
		}
		catch(Exception ex)
		{
			MessageBox.Show("ERROR: " + ex.Message);
			return;
		}
	}
}