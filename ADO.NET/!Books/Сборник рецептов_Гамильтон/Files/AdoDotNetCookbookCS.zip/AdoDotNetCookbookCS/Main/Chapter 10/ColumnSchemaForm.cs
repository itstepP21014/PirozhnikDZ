using System;
using System.Configuration;
using System.Collections;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class ColumnSchemaForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button getSchema;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ColumnSchemaForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.getSchema = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// getSchema
		// 
		this.getSchema.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.getSchema.Location = new System.Drawing.Point(408, 232);
		this.getSchema.Name = "getSchema";
		this.getSchema.TabIndex = 0;
		this.getSchema.Text = "Get Schema";
		this.getSchema.Click += new System.EventHandler(this.getSchema_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// ColumnSchemaForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox,
																		this.getSchema});
		this.Name = "ColumnSchemaForm";
		this.Text = "10.04 ColumnSchemaForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void getSchema_Click(object sender, System.EventArgs e)
	{
		StringBuilder schemaInfo = new StringBuilder();

		// create a batch query to retrieve order and details
		String sqlText = "select OrderID, CustomerID, EmployeeID, OrderDate, " +
			"RequiredDate, ShippedDate, ShipVia, Freight, ShipName, " +
			"ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry " +
			"FROM Orders;" +
			"SELECT OrderID, ProductID, UnitPrice, Quantity, Discount " +
			"FROM [Order Details];";

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// create DataAdapter
		SqlDataAdapter da = new SqlDataAdapter(sqlText, conn);

		// add table mappings
		da.TableMappings.Add("Table", "Orders");
		da.TableMappings.Add("Table1", "Order Details");

		// create the DataSet
		DataSet ds = new DataSet();
		// fill the schema and data
		da.FillSchema(ds, SchemaType.Mapped);
		da.Fill(ds);

		// iterate over the table collection in the DataSet
		foreach(DataTable dt in ds.Tables)
		{
			schemaInfo.Append("TABLE: " + dt.TableName + Environment.NewLine);

			// create the command to retrieve column information
			SqlCommand cmd = new SqlCommand("sp_help", conn);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@objname", SqlDbType.NVarChar, 776);
			cmd.Parameters[0].Value = dt.TableName;

			conn.Open();
			// create the DataReader from the command
			SqlDataReader dr = cmd.ExecuteReader();
			// get the second result set containing column information
			dr.NextResult();

			Hashtable colInfo = new Hashtable();
			// iterate over the second result to retrieve column information
			while(dr.Read())
			{
				colInfo.Add(dr["Column_name"].ToString(),
					"Length = " + dr["Length"] +
					"; Precision = " + dr["Prec"] +
					"; Scale = " + dr["Scale"]);
			}
			dr.Close();
			conn.Close();

			// iterate over the column collection in the table
			foreach(DataColumn col in dt.Columns)
			{
				// get column information
				schemaInfo.Append("\tCOLUMN: " + col.ColumnName + Environment.NewLine);
				schemaInfo.Append("\tAllowDBNull: " + col.AllowDBNull + Environment.NewLine);
				schemaInfo.Append("\tAutoIncrement: " + col.AutoIncrement + Environment.NewLine);
				schemaInfo.Append("\tDataType: " + col.DataType + Environment.NewLine);
				schemaInfo.Append("\tMaxLength: " + col.MaxLength + Environment.NewLine);
				schemaInfo.Append("\tUnique: " + col.Unique + Environment.NewLine);
				schemaInfo.Append("\tOther: " + colInfo[col.ColumnName] + Environment.NewLine);
				schemaInfo.Append(Environment.NewLine);
			}
			schemaInfo.Append(Environment.NewLine);
		}

		resultTextBox.Text = schemaInfo.ToString();
	}
}