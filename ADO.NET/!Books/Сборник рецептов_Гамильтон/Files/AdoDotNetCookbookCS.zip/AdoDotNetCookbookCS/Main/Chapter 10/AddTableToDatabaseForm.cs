using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class AddTableToDatabaseForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button addTableButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AddTableToDatabaseForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.addTableButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// addTableButton
		// 
		this.addTableButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.addTableButton.Location = new System.Drawing.Point(208, 232);
		this.addTableButton.Name = "addTableButton";
		this.addTableButton.TabIndex = 0;
		this.addTableButton.Text = "Add Table";
		this.addTableButton.Click += new System.EventHandler(this.addTableButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(276, 216);
		this.resultTextBox.TabIndex = 2;
		this.resultTextBox.Text = "";
		// 
		// AddTableToDatabaseForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox,
																		this.addTableButton});
		this.Name = "AddTableToDatabaseForm";
		this.Text = "10.08 AddTableToDatabaseForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void addTableButton_Click(object sender, System.EventArgs e)
	{
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		String createSql = "CREATE TABLE MyTable " +
			"(MyTableId int IDENTITY(1,1) PRIMARY KEY CLUSTERED)";

		SqlCommand cmd = new SqlCommand(createSql, conn);
		// create the table in the database
		try 
		{
			conn.Open();
			cmd.ExecuteNonQuery();
			resultTextBox.Text = "Table created successfully";
		}
		catch (System.Exception ex)
		{
			resultTextBox.Text = ex.ToString();
		}
		finally
		{
			if (conn.State == ConnectionState.Open)
				conn.Close();
		} 
	}
}