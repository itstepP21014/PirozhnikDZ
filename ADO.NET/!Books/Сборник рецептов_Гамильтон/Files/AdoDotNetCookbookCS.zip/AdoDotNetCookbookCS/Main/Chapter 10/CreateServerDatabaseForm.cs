using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class CreateServerDatabaseForm : System.Windows.Forms.Form
{
	private readonly String DATAFILENAME	= ConfigurationSettings.AppSettings["Temp_Directory"] + "MyDatabaseData.mdf";
	private readonly String LOGFILENAME	= ConfigurationSettings.AppSettings["Temp_Directory"] + "MyDatabaseLog.ldf";

	private System.Windows.Forms.Button createServerDatabaseButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public CreateServerDatabaseForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.createServerDatabaseButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// createServerDatabaseButton
		// 
		this.createServerDatabaseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.createServerDatabaseButton.Location = new System.Drawing.Point(348, 232);
		this.createServerDatabaseButton.Name = "createServerDatabaseButton";
		this.createServerDatabaseButton.Size = new System.Drawing.Size(136, 23);
		this.createServerDatabaseButton.TabIndex = 0;
		this.createServerDatabaseButton.Text = "Create Server Database";
		this.createServerDatabaseButton.Click += new System.EventHandler(this.createServerDatabaseButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// CreateServerDatabaseForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.createServerDatabaseButton);
		this.Name = "CreateServerDatabaseForm";
		this.Text = "10.07 CreateServerDatabaseForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void createServerDatabaseButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder sb = new StringBuilder();

		// SQL DDL command text to create database
		String sqlText = "CREATE DATABASE MyDatabase ON PRIMARY " +
				"(NAME = MyDatabase_Data, " +
				"FILENAME = '" + DATAFILENAME + "', " +
				"SIZE = 2MB, MAXSIZE = 10MB, FILEGROWTH = 10%) " +
				"LOG ON (NAME = MyDatabase_Log, " +
				"FILENAME = '" + LOGFILENAME + "', " +
				"SIZE = 1MB, " +
				"MAXSIZE = 5MB, " +
				"FILEGROWTH = 10%)";

		sb.Append(sqlText + Environment.NewLine + Environment.NewLine);

		// create a connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_Master_ConnectString"]);

		// create the command to create the database
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		// create the new database
		try 
		{
			conn.Open();
			cmd.ExecuteNonQuery();
			sb.Append("DataBase created successfully.");
		}
		catch (System.Exception ex)
		{
			sb.Append(ex.ToString());
		}
		finally
		{
			if (conn.State == ConnectionState.Open)
				conn.Close();
			conn.Close();
		} 

		resultTextBox.Text = sb.ToString();
	}
}