using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class ShowPlanForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button showPlanButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ShowPlanForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.showPlanButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// showPlanButton
		// 
		this.showPlanButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.showPlanButton.Location = new System.Drawing.Point(408, 232);
		this.showPlanButton.Name = "showPlanButton";
		this.showPlanButton.TabIndex = 0;
		this.showPlanButton.Text = "Show Plan";
		this.showPlanButton.Click += new System.EventHandler(this.showPlanButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// ShowPlanForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.showPlanButton);
		this.Name = "ShowPlanForm";
		this.Text = "10.09 Show Plan";
		this.ResumeLayout(false);

	}
	#endregion

	private void showPlanButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder sb = new StringBuilder();

		// open a new connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// create and execute the command to retrieve the plan
		SqlCommand cmd = new SqlCommand("SET SHOWPLAN_TEXT ON", conn);
		conn.Open();
		cmd.ExecuteNonQuery();

		// create the command to get the plan for
		cmd.CommandText = "SELECT * FROM Customers WHERE Country='USA' " +
			"ORDER BY CompanyName";
		
		// retrieve the plan into DataReader
		SqlDataReader dr = cmd.ExecuteReader();

		// iterate over all result sets and all rows to get plan
		do
		{
			while (dr.Read())
				sb.Append(dr.GetString(0) + Environment.NewLine);
			sb.Append(Environment.NewLine);
		} while(dr.NextResult());
		dr.Close();

		// create and execute the command to retrieve query results
		cmd = new SqlCommand("SET SHOWPLAN_ALL OFF", conn);
		cmd.ExecuteNonQuery();

		conn.Close();

		resultTextBox.Text = sb.ToString();
	}
}