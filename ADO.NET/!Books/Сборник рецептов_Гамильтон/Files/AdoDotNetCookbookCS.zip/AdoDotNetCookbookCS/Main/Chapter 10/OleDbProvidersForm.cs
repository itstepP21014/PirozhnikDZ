using System;
using System.Configuration;
using System.Text;

using Microsoft.Win32;

using System.Data;
using System.Data.SqlClient;

public class OleDbProvidersForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button sqlServerButton;
	private System.Windows.Forms.Button registryButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public OleDbProvidersForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.sqlServerButton = new System.Windows.Forms.Button();
		this.registryButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 0;
		this.resultTextBox.Text = "";
		// 
		// sqlServerButton
		// 
		this.sqlServerButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.sqlServerButton.Location = new System.Drawing.Point(328, 232);
		this.sqlServerButton.Name = "sqlServerButton";
		this.sqlServerButton.TabIndex = 1;
		this.sqlServerButton.Text = "SQL Server";
		this.sqlServerButton.Click += new System.EventHandler(this.sqlServerButton_Click);
		// 
		// registryButton
		// 
		this.registryButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.registryButton.Location = new System.Drawing.Point(408, 232);
		this.registryButton.Name = "registryButton";
		this.registryButton.TabIndex = 2;
		this.registryButton.Text = "Registry";
		this.registryButton.Click += new System.EventHandler(this.registryButton_Click);
		// 
		// OleDbProvidersForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.registryButton);
		this.Controls.Add(this.sqlServerButton);
		this.Controls.Add(this.resultTextBox);
		this.Name = "OleDbProvidersForm";
		this.Text = "10.13 OleDbProvidersForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void sqlServerButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder("Using SQL Server xp_enum_oledb_providers." + Environment.NewLine);
		int count = 0;

		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_Master_ConnectString"]);

		// create a command to execute the extended stored procedure to
		// retrieve OLE DB providers
		SqlCommand cmd = new SqlCommand("xp_enum_oledb_providers", conn);
		cmd.CommandType = CommandType.StoredProcedure;

		// create the DataReader
		conn.Open();
		SqlDataReader rdr = cmd.ExecuteReader();
		// iterate through the OLE DB providers in the DataReader
		while(rdr.Read())
		{
			result.Append(++count + ": " + rdr["Provider Description"].ToString() + Environment.NewLine);
		}
		conn.Close();

		resultTextBox.Text = result.ToString();
	}

	private void registryButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder("Using Registry scan." + Environment.NewLine);
		int count = 0;

		// get the HKEY_CLASSES_ROOT/CLSID key
		RegistryKey keyCLSID = Registry.ClassesRoot.OpenSubKey("CLSID", false);
		// iterate through the collection of subkeys
		String[] keys = keyCLSID.GetSubKeyNames();
		for(int i = 0; i < keys.Length; i++)
		{
			// look for the OLE DB Provider subkey and retrieve the value if found
			RegistryKey key = keyCLSID.OpenSubKey(keys[i], false);
			RegistryKey subKey = key.OpenSubKey("OLE DB Provider", false);
			if(subKey != null)
			{
				result.Append(++count + ": " + subKey.GetValue(subKey.GetValueNames()[0]) + Environment.NewLine);
			}
		}
	
		resultTextBox.Text = result.ToString();
	}
}