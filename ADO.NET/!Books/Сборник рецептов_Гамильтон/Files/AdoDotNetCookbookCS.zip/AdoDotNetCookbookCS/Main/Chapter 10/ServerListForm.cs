using System;

public class ServerListForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button buttonServerList;
	private System.Windows.Forms.ListBox serverListListBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ServerListForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.buttonServerList = new System.Windows.Forms.Button();
		this.serverListListBox = new System.Windows.Forms.ListBox();
		this.SuspendLayout();
		// 
		// buttonServerList
		// 
		this.buttonServerList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.buttonServerList.Location = new System.Drawing.Point(192, 232);
		this.buttonServerList.Name = "buttonServerList";
		this.buttonServerList.Size = new System.Drawing.Size(88, 23);
		this.buttonServerList.TabIndex = 0;
		this.buttonServerList.Text = "Get Server List";
		this.buttonServerList.Click += new System.EventHandler(this.buttonServerList_Click);
		// 
		// serverListListBox
		// 
		this.serverListListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.serverListListBox.Location = new System.Drawing.Point(8, 8);
		this.serverListListBox.Name = "serverListListBox";
		this.serverListListBox.Size = new System.Drawing.Size(272, 212);
		this.serverListListBox.TabIndex = 1;
		// 
		// ServerListForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.Add(this.serverListListBox);
		this.Controls.Add(this.buttonServerList);
		this.Name = "ServerListForm";
		this.Text = "10.01 ServerListForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void buttonServerList_Click(object sender, System.EventArgs e)
	{
		serverListListBox.Items.Clear();

		// create a SQL Distributed Management Objects (SQL-DMO) application object
		SQLDMO.Application dmo = new SQLDMO.Application();
		// retrieve the available servers
		SQLDMO.NameList serverNameList = dmo.ListAvailableSQLServers();

		// iterate over the collection of available servers
		for(int i = 0; i < serverNameList.Count; i++)
		{
			if (serverNameList.Item(i) !=  null)
				serverListListBox.Items.Add(serverNameList.Item(i));
		}
		serverListListBox.Items.Add("End of list.");
	}
}