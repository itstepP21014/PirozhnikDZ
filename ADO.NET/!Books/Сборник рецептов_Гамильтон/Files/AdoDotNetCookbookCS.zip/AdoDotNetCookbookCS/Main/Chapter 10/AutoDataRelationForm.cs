using System;
using System.Configuration;
using System.Collections;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class AutoDataRelationForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE			= "Orders";
	private const String ORDERDETAILS_TABLE		= "Order Details";
	private const String PARENTMULTICOLKEYTABLE	= "TBL1011a";
	private const String CHILDMULTICOLKEYTABLE	= "TBL1011b";

	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AutoDataRelationForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 332);
		this.goButton.Name = "goButton";
		this.goButton.Size = new System.Drawing.Size(76, 23);
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 312);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// AutoDataRelationForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 366);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox,
																		this.goButton});
		this.Name = "AutoDataRelationForm";
		this.Text = "10.11 AutoDataRelationForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		DataSet ds = new DataSet();
		
		SqlDataAdapter da;

		// add the Orders and Order Details tables to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(ds, ORDERS_TABLE);
		da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(ds, ORDERDETAILS_TABLE);

		// add the TBL1011a and TBL1101b tables to the DataSet
		da = new SqlDataAdapter("SELECT * FROM TBL1011a", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(ds, PARENTMULTICOLKEYTABLE);
		da = new SqlDataAdapter("SELECT * FROM TBL1011b", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(ds, CHILDMULTICOLKEYTABLE);

		StringBuilder result = new StringBuilder();

		String sqlText = "SELECT rc.CONSTRAINT_NAME, rc.UPDATE_RULE, rc.DELETE_RULE, " +
			"kcuP.TABLE_NAME ParentTable, kcuC.TABLE_NAME ChildTable, " +
			"kcuP.COLUMN_NAME ParentColumn, kcuC.COLUMN_NAME ChildColumn " +
			"FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS rc " +
			"LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcuP ON rc.UNIQUE_CONSTRAINT_NAME = kcuP.CONSTRAINT_NAME " +
			"LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcuC ON rc.CONSTRAINT_NAME = kcuC.CONSTRAINT_NAME AND " +
			"kcuP.ORDINAL_POSITION = kcuC.ORDINAL_POSITION " +
			"ORDER BY rc.CONSTRAINT_NAME, kcuP.ORDINAL_POSITION";

		// create the connection and command to retrieve constraint information
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);

		// fill the DataReader with constraint information
		conn.Open();
		SqlDataReader reader = cmd.ExecuteReader();

		String prevConstraintName = "";
		String constraintName = "";
		String parentTableName = "";
		String childTableName = "";
		bool updateCascade = false;
		bool deleteCascade = false;
		String relationName = "";

		// arrays to store related columns from constraints in DataReader
		ArrayList parentColsAL = new ArrayList();
		ArrayList childColsAL = new ArrayList();
		DataColumn[] parentCols;
		DataColumn[] childCols;

		DataRelation dr;
		
		bool isRecord = false;
		// iterate over the constraint collection for the database
		do
		{
			// read the next record from the DataReader
			isRecord = reader.Read();

			// store the current constraint as the previous constraint name 
			// to handle multi-column based relations
			prevConstraintName = constraintName;

			// get the current constraint name
			constraintName = isRecord ? reader["CONSTRAINT_NAME"].ToString() : "";

			// if the constraint name has changed and both tables exist in the DataSet,
			// create a relation based on the previous constraint column(s)
			if (prevConstraintName != "" && constraintName != prevConstraintName &&
				ds.Tables.Contains(parentTableName) && ds.Tables.Contains(childTableName))
			{
				// create the parent and child column arrays
				parentCols = new DataColumn[parentColsAL.Count];
				parentColsAL.CopyTo(parentCols);
				childCols = new DataColumn[childColsAL.Count];
				childColsAL.CopyTo(childCols);

				// create the relation name based on the constraint name
				relationName = prevConstraintName.Replace("FK_","RELATION_");

				// create the relation and add it to the DataSet
				dr = new DataRelation(relationName, parentCols, childCols, true);
				ds.Relations.Add(dr);
				// set the cascade update and delete rules
				dr.ChildKeyConstraint.UpdateRule = updateCascade ? Rule.Cascade : Rule.None;
				dr.ChildKeyConstraint.DeleteRule = deleteCascade ? Rule.Cascade : Rule.None;

				// clear the parent and child column arrays for the previous constraint
				parentColsAL.Clear();
				childColsAL.Clear();

				result.Append("Added relationship " + relationName + " to DataSet." + Environment.NewLine);
			}				

			if (isRecord)
			{
				// store the current parent and child table names
				parentTableName = reader["ParentTable"].ToString();
				childTableName = reader["ChildTable"].ToString();
				// store the cascade update and delete for the current constraint
				updateCascade = (reader["UPDATE_RULE"].ToString() == "CASCADE");
				deleteCascade = (reader["DELETE_RULE"].ToString() == "CASCADE");

				// add the parent and child column for the current constraint
				// to the ArrayLists, if both parent and child are in DataSet
				if (ds.Tables.Contains(parentTableName) && ds.Tables.Contains(childTableName))
				{
					parentColsAL.Add(ds.Tables[parentTableName].Columns[reader["ParentColumn"].ToString()]);
					childColsAL.Add(ds.Tables[childTableName].Columns[reader["ChildColumn"].ToString()]);
				}
			}
		} while(isRecord);

		// close the DataReader and connection
		reader.Close();
		conn.Close();

		resultTextBox.Text = result.ToString();
	}
}