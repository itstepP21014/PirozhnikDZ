using System;
using System.Configuration;
using System.Windows.Forms;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class CreateDatabaseTableFromDataTableSchemaForm : System.Windows.Forms.Form
{
	private const String TABLENAME = "TBL1015";

	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.TextBox sqlTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public CreateDatabaseTableFromDataTableSchemaForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.sqlTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 332);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// sqlTextBox
		// 
		this.sqlTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.sqlTextBox.Location = new System.Drawing.Point(8, 8);
		this.sqlTextBox.Multiline = true;
		this.sqlTextBox.Name = "sqlTextBox";
		this.sqlTextBox.ReadOnly = true;
		this.sqlTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.sqlTextBox.Size = new System.Drawing.Size(476, 312);
		this.sqlTextBox.TabIndex = 1;
		this.sqlTextBox.Text = "";
		// 
		// CreateDatabaseTableFromDataTableSchemaForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 366);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.sqlTextBox,
																		this.goButton});
		this.Name = "CreateDatabaseTableFromDataTableSchemaForm";
		this.Text = "10.15 CreateDatabaseTableFromDataTableSchemaForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		// fill a table with the Orders table schema
		String sqlText = "SELECT * FROM [Orders]";
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable("Orders");
		da.FillSchema(dt, SchemaType.Source);

		CreateTableFromSchema(dt, ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		MessageBox.Show("Table " + TABLENAME + " created.", "Create DataTable from schema.",
			MessageBoxButtons.OK, MessageBoxIcon.Information);
	}

	private void CreateTableFromSchema(DataTable dt, String connectionString)
	{
		// drop the new table if it is already there
		StringBuilder sqlCmd = new StringBuilder("if exists (SELECT * FROM dbo.sysobjects WHERE id  =  object_id('[" + TABLENAME + "]') " +
			"AND OBJECTPROPERTY(id, 'IsUserTable')  =  1)" + Environment.NewLine +
			"DROP TABLE " + TABLENAME + ";" + Environment.NewLine + Environment.NewLine);

		// start building a command string to create the table
		sqlCmd.Append("CREATE TABLE [" + TABLENAME + "] (" + Environment.NewLine);
		// iterate over the column collection in the source table
		foreach(DataColumn col in dt.Columns)
		{
			// add the column
			sqlCmd.Append("[" + col.ColumnName + "] ");
			// map the source column type to a SQL Server type
			sqlCmd.Append(NetType2SqlType(col.DataType.ToString(), col.MaxLength) + " ");
			// add identity information
			if(col.AutoIncrement)
				sqlCmd.Append("IDENTITY ");
			// add AllowNull information
			sqlCmd.Append((col.AllowDBNull ? "" : "NOT ") + "NULL," + Environment.NewLine);
		}	
		sqlCmd.Remove(sqlCmd.Length - (Environment.NewLine.Length + 1), 1);
		sqlCmd.Append(") ON [PRIMARY];" + Environment.NewLine + Environment.NewLine);

		// add the primary key to the table, if it exists
		if(dt.PrimaryKey != null)
		{
			sqlCmd.Append("ALTER TABLE " + TABLENAME + " WITH NOCHECK ADD " + Environment.NewLine);
			sqlCmd.Append("CONSTRAINT [PK_" + TABLENAME + "] PRIMARY KEY CLUSTERED (" + Environment.NewLine);
			// add the columns to the primary key
			foreach(DataColumn col in dt.PrimaryKey)
			{
				sqlCmd.Append("[" + col.ColumnName + "]," + Environment.NewLine);
			}
			sqlCmd.Remove(sqlCmd.Length - (Environment.NewLine.Length + 1), 1);
			sqlCmd.Append(") ON [PRIMARY];" + Environment.NewLine + Environment.NewLine);
		}

		sqlTextBox.Text = sqlCmd.ToString();

		// create and execute the command to create the new table
		SqlConnection conn = new SqlConnection(connectionString);
		SqlCommand cmd = new SqlCommand(sqlCmd.ToString(), conn);
		conn.Open();
		cmd.ExecuteNonQuery();
		conn.Close();
	}

	private String NetType2SqlType(String netType, int maxLength)
	{
		String sqlType = "";

		// map the .NET type to the data source type
		// this is not perfect because mappings are not always 1-to-1
		switch(netType)
		{
			case "System.Boolean":
				sqlType = "[bit]";
				break;
			case "System.Byte":
				sqlType = "[tinyint]";
				break;
			case "System.Int16":
				sqlType = "[smallint]";
				break;
			case "System.Int32":
				sqlType = "[int]";
				break;
			case "System.Int64":
				sqlType = "[bigint]";
				break;
			case "System.Byte[]":
				sqlType = "[binary]";
				break;
			case "System.Char[]":
				sqlType = "[nchar] (" + maxLength + ")";
				break;
			case "System.String":
				if(maxLength == 0x3FFFFFFF)
					sqlType = "[ntext]";
				else
					sqlType =  "[nvarchar] (" + maxLength + ")";
				break;
			case "System.Single":
				sqlType = "[real]";
				break;
			case "System.Double":
				sqlType = "[float]";
				break;
			case "System.Decimal":
				sqlType = "[decimal]";
				break;
			case "System.DateTime":
				sqlType = "[datetime]";
				break;
			case "System.Guid":
				sqlType = "[uniqueidentifier]";
				break;
			case "System.Object":
				sqlType = "[sql_variant]";
				break;
		}

		return sqlType;
	}
}