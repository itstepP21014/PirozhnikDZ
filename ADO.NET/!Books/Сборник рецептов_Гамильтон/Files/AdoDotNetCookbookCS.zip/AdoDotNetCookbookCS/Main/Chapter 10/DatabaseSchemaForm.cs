using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

public class DatabaseSchemaForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.DataGrid schemaDataGrid;
	private System.Windows.Forms.Button getTablesButton;
	private System.Windows.Forms.RadioButton sqlServerRadioButton;
	private System.Windows.Forms.RadioButton oleDbRadioButton;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DatabaseSchemaForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.schemaDataGrid = new System.Windows.Forms.DataGrid();
		this.getTablesButton = new System.Windows.Forms.Button();
		this.sqlServerRadioButton = new System.Windows.Forms.RadioButton();
		this.oleDbRadioButton = new System.Windows.Forms.RadioButton();
		((System.ComponentModel.ISupportInitialize)(this.schemaDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// schemaDataGrid
		// 
		this.schemaDataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.schemaDataGrid.DataMember = "";
		this.schemaDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.schemaDataGrid.Location = new System.Drawing.Point(8, 8);
		this.schemaDataGrid.Name = "schemaDataGrid";
		this.schemaDataGrid.Size = new System.Drawing.Size(476, 216);
		this.schemaDataGrid.TabIndex = 0;
		// 
		// getTablesButton
		// 
		this.getTablesButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.getTablesButton.Location = new System.Drawing.Point(408, 232);
		this.getTablesButton.Name = "getTablesButton";
		this.getTablesButton.TabIndex = 1;
		this.getTablesButton.Text = "Get Tables";
		this.getTablesButton.Click += new System.EventHandler(this.getTablesButton_Click);
		// 
		// sqlServerRadioButton
		// 
		this.sqlServerRadioButton.Checked = true;
		this.sqlServerRadioButton.Location = new System.Drawing.Point(8, 232);
		this.sqlServerRadioButton.Name = "sqlServerRadioButton";
		this.sqlServerRadioButton.Size = new System.Drawing.Size(160, 24);
		this.sqlServerRadioButton.TabIndex = 2;
		this.sqlServerRadioButton.TabStop = true;
		this.sqlServerRadioButton.Text = "SQL Server .NET Provider";
		// 
		// oleDbRadioButton
		// 
		this.oleDbRadioButton.Location = new System.Drawing.Point(168, 232);
		this.oleDbRadioButton.Name = "oleDbRadioButton";
		this.oleDbRadioButton.Size = new System.Drawing.Size(144, 24);
		this.oleDbRadioButton.TabIndex = 3;
		this.oleDbRadioButton.Text = "OLE DB .NET Provider";
		// 
		// DatabaseSchemaForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.oleDbRadioButton,
																		this.sqlServerRadioButton,
																		this.getTablesButton,
																		this.schemaDataGrid});
		this.Name = "DatabaseSchemaForm";
		this.Text = "10.02 DatabaseSchemaForm";
		((System.ComponentModel.ISupportInitialize)(this.schemaDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void getTablesButton_Click(object sender, System.EventArgs e)
	{
		DataTable schemaTable;

		if(sqlServerRadioButton.Checked)
		{
			String getSchemaTableText = "SELECT * " +
				"FROM INFORMATION_SCHEMA.TABLES " +
				"WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_TYPE";

			// retrieve the schema table contents
			SqlDataAdapter da = new SqlDataAdapter(getSchemaTableText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			schemaTable = new DataTable();
			da.Fill(schemaTable);

			schemaDataGrid.CaptionText = "SQL Server .NET Provider";
		}
		else
		{
			OleDbConnection conn = new OleDbConnection(ConfigurationSettings.AppSettings["OleDb_ConnectString"]);
			conn.Open();
			// get the schema table
			schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] {null, null, null, "TABLE"});
			conn.Close();

			schemaDataGrid.CaptionText = "OLE DB .NET Provider";
		}

		// bind the default view of schema table to the grid
		schemaDataGrid.DataSource = schemaTable.DefaultView;
	}
}