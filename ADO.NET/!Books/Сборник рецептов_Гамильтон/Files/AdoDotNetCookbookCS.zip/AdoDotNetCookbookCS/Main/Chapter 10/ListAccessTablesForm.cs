using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.OleDb;

public class ListAccessTablesForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button adoxButton;
	private System.Windows.Forms.Button oleDbButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ListAccessTablesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.adoxButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.oleDbButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// adoxButton
		// 
		this.adoxButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.adoxButton.Location = new System.Drawing.Point(408, 232);
		this.adoxButton.Name = "adoxButton";
		this.adoxButton.TabIndex = 0;
		this.adoxButton.Text = "ADOX";
		this.adoxButton.Click += new System.EventHandler(this.adoxButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 208);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// oleDbButton
		// 
		this.oleDbButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.oleDbButton.Location = new System.Drawing.Point(328, 232);
		this.oleDbButton.Name = "oleDbButton";
		this.oleDbButton.TabIndex = 2;
		this.oleDbButton.Text = "OLE DB";
		this.oleDbButton.Click += new System.EventHandler(this.oleDbButton_Click);
		// 
		// ListAccessTablesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.oleDbButton,
																		this.resultTextBox,
																		this.adoxButton});
		this.Name = "ListAccessTablesForm";
		this.Text = "10.14 ListAccessTablesForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void oleDbButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();
	
		// open the OLE DB connection
		OleDbConnection conn = new OleDbConnection(ConfigurationSettings.AppSettings["MsAccess_ConnectString"]);
		conn.Open();

		// retrieve schema information for all tables 
		DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
			new object[] {null, null, null, "TABLE"});

		result.Append("TABLE" + Environment.NewLine);
		// iterate over the collection of table records
		foreach(DataRow row in schemaTable.Rows)
		{
			result.Append(row["TABLE_NAME"] + Environment.NewLine);
		}

		conn.Close();

		resultTextBox.Text = result.ToString();
	}

	private void adoxButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// open the connection
		ADODB.Connection conn = new ADODB.ConnectionClass();
		conn.Open(ConfigurationSettings.AppSettings["MsAccess_ConnectString"], "", "", 0);

		// create an ADOX catalog object for the connecton
		ADOX.Catalog cat = new ADOX.Catalog();
		cat.ActiveConnection = conn;

		result.Append("TABLE\tKEY" + Environment.NewLine);
		// iterate over the collection of tables
		foreach(ADOX.Table table in cat.Tables)
		{
			if(table.Type == "TABLE")
			{
				result.Append(table.Name + Environment.NewLine);
				// iterate over the collection of keys for the table
				foreach(ADOX.Key key in table.Keys)
				{
					result.Append("\t" + key.Name + " (");
					// iterate over the collection of columns for the key
					foreach(ADOX.Column col in key.Columns)
					{
						result.Append(col.Name + ", ");
					}
					result.Remove(result.Length - 2, 2).Append(")" + Environment.NewLine);
				}
				result.Append(Environment.NewLine);
			}
		}

		cat = null;
		conn.Close();

		resultTextBox.Text = result.ToString();
	}
}