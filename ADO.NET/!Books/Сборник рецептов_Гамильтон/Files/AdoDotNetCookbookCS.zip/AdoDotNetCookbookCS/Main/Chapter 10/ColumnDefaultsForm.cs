using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class ColumnDefaultsForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";

	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ColumnDefaultsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// ColumnDefaultsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox,
																		this.goButton});
		this.Name = "ColumnDefaultsForm";
		this.Text = "10.03 ColumnDefaultsForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// fill the Orders table with schema and data
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable ordersTable = new DataTable(ORDERS_TABLE);
		da.FillSchema(ordersTable, SchemaType.Source);
		da.Fill(ordersTable);

		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// command for system stored procedure returning constraints
		SqlCommand cmd = new SqlCommand("sp_helpconstraint", conn);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@objname",SqlDbType.NVarChar,776);
		cmd.Parameters[0].Value = "Orders";
		cmd.Parameters.Add("@nomsg",SqlDbType.VarChar,5);
		cmd.Parameters[1].Value = "nomsg";

		// create a DataReader from the stored procedure
		conn.Open();
		SqlDataReader dr = cmd.ExecuteReader();

		// iterate over the constraints records in the DataReader
		while(dr.Read())
		{
			// select the default value constraints only
			String constraintType = dr["constraint_type"].ToString();
			if (constraintType.StartsWith("DEFAULT"))
			{
				String constraintKeys = dr["constraint_keys"].ToString();
				// only strips single quotes for numeric default types
				// add necessary handling as required for non-numeric defaults
				String defaultValue = constraintKeys.Substring(1, constraintKeys.Length - 2);

				String colName = constraintType.Substring((constraintType.LastIndexOf("column") + 7));

				ordersTable.Columns[colName].DefaultValue = defaultValue;

				result.Append("Column: " + colName + "   Default: " + defaultValue + Environment.NewLine);
			}
		}
		dr.Close();
		conn.Close();

		resultTextBox.Text = result.ToString();
	}
}