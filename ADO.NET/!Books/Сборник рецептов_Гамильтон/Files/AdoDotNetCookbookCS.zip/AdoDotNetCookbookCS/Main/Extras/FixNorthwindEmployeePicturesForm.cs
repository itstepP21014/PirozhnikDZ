using System;
using System.Configuration;
using System.IO;

using System.Data;
using System.Data.SqlClient;

public class FixNorthwindEmployeePicturesForm : System.Windows.Forms.Form
{
	private const int MSACCESSIMAGEOFFSET=78;

	private System.Windows.Forms.Button goButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public FixNorthwindEmployeePicturesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Location = new System.Drawing.Point(200, 224);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// FixNorthwindEmployeePicturesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.goButton});
		this.Name = "FixNorthwindEmployeePicturesForm";
		this.Text = "FixNorthwindEmployeePicturesForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		//strips the Access OLE header from the SQL Server images in the Employees table.
		//*** don't run more than once ***
		String selectCommand = "SELECT EmployeeID FROM Employees";
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlDataAdapter da = new SqlDataAdapter(selectCommand, conn);
	
		DataTable table = new DataTable("Employees");
		da.FillSchema(table, SchemaType.Source);
		da.Fill(table);

		conn.Open();
		foreach(DataRow row in table.Rows)
		{
			Int32 employeeId = (Int32)row["EmployeeID"];

			String sqlRead = "SELECT Photo FROM Employees WHERE EmployeeID=" + employeeId;
			SqlCommand cmdRead = new SqlCommand(sqlRead, conn);

			MemoryStream ms = new MemoryStream();
			Byte[] image = (Byte[])cmdRead.ExecuteScalar();
			ms.Write(image, MSACCESSIMAGEOFFSET, image.Length - MSACCESSIMAGEOFFSET);

			String sqlWrite = "UPDATE Employees SET Photo = @Photo WHERE EmployeeID=" + employeeId;
			SqlCommand cmdWrite = new SqlCommand(sqlWrite, conn);

			//Create parameter for insert command and add to SqlCommand object.
			SqlParameter prm = new  SqlParameter("@Photo", SqlDbType.VarBinary, ms.ToArray().Length, ParameterDirection.Input, false, 
				0, 0, null, DataRowVersion.Current, ms.ToArray());
			cmdWrite.Parameters.Add(prm);

			//Execute query.
			cmdWrite.ExecuteNonQuery();
		}
		conn.Close();
	}
}