using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.OleDb;

public class ShapeForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ShapeForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// ShapeForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.goButton);
		this.Name = "ShapeForm";
		this.Text = "3.14 ShapeForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// SHAPE SQL to retrieve TOP 5 Orders and associated Order Detail records
		String shapeText = "SHAPE {select TOP 5 * from Orders} AS Orders " + 
			"APPEND ({select * from [Order Details]} AS 'Order Details' " +
			"RELATE OrderID TO OrderID)";

		// create the connection
		OleDbConnection conn = new OleDbConnection(ConfigurationSettings.AppSettings["OleDb_Shape_ConnectString"]);												

		// create a command and fill a DataReader with the SHAPE result set
		OleDbCommand cmd = new OleDbCommand(shapeText, conn);
		conn.Open();
		OleDbDataReader orderDR = cmd.ExecuteReader();

		// iterate over the collection of rows in the DataReader
		while(orderDR.Read())
		{
			result.Append("ORDER" + Environment.NewLine);
			// iterate over the collection of Order columns in the DataReader
			for(int colOrder = 0; colOrder < orderDR.FieldCount; colOrder++)
			{
				if (orderDR[colOrder] is IDataReader)
				{
					// the column is an IDataReader interface
					result.Append(Environment.NewLine);
					result.Append(orderDR.GetName(colOrder).ToUpper() + Environment.NewLine);

					// create a DataReader for the Order Detail from the
					// IDataReader interface column
					OleDbDataReader orderDetailDR = (OleDbDataReader)orderDR.GetValue(colOrder);
					// iterate over records in the Order Detail DataReader
					while(orderDetailDR.Read())
					{
						// iterate over the Order Detail columns
						// in the Data Reader
						for(int colOrderDetail = 0; colOrderDetail < orderDetailDR.FieldCount; colOrderDetail++)
						{
							result.Append("   " + orderDetailDR.GetName(colOrderDetail) + ": " + orderDetailDR[colOrderDetail] + Environment.NewLine);
						}
						result.Append(Environment.NewLine);
					}
				}
				else
				{
					result.Append(orderDR.GetName(colOrder)+ ": " + orderDR[colOrder] + Environment.NewLine);
				}
			}
			result.Append(Environment.NewLine);
		}

		orderDR.Close();
		conn.Close();

		resultTextBox.Text = result.ToString();
	}
}