using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class FilterNullValuesForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";

	// field name constants
	private const String SHIPREGION_FIELD	= "ShipRegion";

	private System.Windows.Forms.Button filterButton;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public FilterNullValuesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.filterButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// filterButton
		// 
		this.filterButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.filterButton.Location = new System.Drawing.Point(384, 232);
		this.filterButton.Name = "filterButton";
		this.filterButton.Size = new System.Drawing.Size(96, 23);
		this.filterButton.TabIndex = 0;
		this.filterButton.Text = "Apply Filter";
		this.filterButton.Click += new System.EventHandler(this.filterButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 1;
		// 
		// FilterNullValuesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.filterButton);
		this.Name = "FilterNullValuesForm";
		this.Text = "3.12 FilterNullValuesForm";
		this.Load += new System.EventHandler(this.FilterNullValuesForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void FilterNullValuesForm_Load(object sender, System.EventArgs e)
	{
		// create and fill the Orders table
		DataTable dt = new DataTable(ORDERS_TABLE);
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(dt);

		// bind the default view to the grid
		dataGrid.DataSource = dt.DefaultView;		
	}


	private void filterButton_Click(object sender, System.EventArgs e)
	{
		String filter = SHIPREGION_FIELD + " IS NULL";

		DataView dv = (DataView)dataGrid.DataSource;

		if(filterButton.Text == "Apply Filter")
		{
			// apply the filter
			dv.RowFilter = filter;
			dataGrid.CaptionText = "Orders table: filtered for null ShipRegion field.";
			filterButton.Text = "Remove Filter";
		}
		else
		{
			// remove the filter
			dv.RowFilter = "";
			dataGrid.CaptionText = "Orders table: no filter.";
			filterButton.Text = "Apply Filter";
		}
	}
}