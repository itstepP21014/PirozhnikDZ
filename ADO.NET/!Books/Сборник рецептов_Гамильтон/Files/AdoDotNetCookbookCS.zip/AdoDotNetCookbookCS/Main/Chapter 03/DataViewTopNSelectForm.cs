using System;
using System.Configuration;
using System.Windows.Forms;

using System.Text;
using System.Data;
using System.Data.SqlClient;

public class DataViewTopNSelectForm : System.Windows.Forms.Form
{
	private DataView dv;

	// table name constants
	private const String ORDERS_TABLE		= "Orders";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";
	private const String FREIGHT_FIELD		= "Freight";

	private System.Windows.Forms.Button selectButton;
	private System.Windows.Forms.TextBox topNTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.DataGrid dataGrid;
	
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DataViewTopNSelectForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.selectButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.topNTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// selectButton
		// 
		this.selectButton.Location = new System.Drawing.Point(144, 8);
		this.selectButton.Name = "selectButton";
		this.selectButton.TabIndex = 0;
		this.selectButton.Text = "Select";
		this.selectButton.Click += new System.EventHandler(this.selectButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 40);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 1;
		// 
		// topNTextBox
		// 
		this.topNTextBox.Location = new System.Drawing.Point(56, 8);
		this.topNTextBox.Name = "topNTextBox";
		this.topNTextBox.Size = new System.Drawing.Size(72, 20);
		this.topNTextBox.TabIndex = 2;
		this.topNTextBox.Text = "5";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(48, 23);
		this.label1.TabIndex = 3;
		this.label1.Text = "Top N:";
		// 
		// DataViewTopNSelectForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.topNTextBox);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.selectButton);
		this.Name = "DataViewTopNSelectForm";
		this.Text = "3.10 DataViewTopNSelectForm";
		this.Load += new System.EventHandler(this.DataViewTopNSelectForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void DataViewTopNSelectForm_Load(object sender, System.EventArgs e)
	{
		// fill the Orders table
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable(ORDERS_TABLE);
		da.Fill(dt);
		da.FillSchema(dt, SchemaType.Source);

		// get the default view for the table and bind it to the grid
		dv = dt.DefaultView;
		dataGrid.DataSource = dv;
	}

	private void selectButton_Click(object sender, System.EventArgs e)
	{
		// this example will select the top N freight values
		// set the field name variable
		String topNFieldName = FREIGHT_FIELD;

		int topN = 0;
		try
		{
			topN = Convert.ToInt32(topNTextBox.Text);

			if(topN <= 0)
			{
				MessageBox.Show("Enter an Integer greater than 0.", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
				return;
			}
		}
		catch(System.FormatException)
		{
			MessageBox.Show("Enter an Integer greater than 0.", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
			return;
		}

		// clear the filter on the view
		dv.RowFilter = "";
		// sort the view descending on the top N field
		dv.Sort = topNFieldName + " DESC";

		// create a filter for all records with a value greater than the Nth 
		StringBuilder rowFilter = new StringBuilder(topNFieldName + ">=" + dv[topN-1][topNFieldName]);
		// apply the filter to the view
		dv.RowFilter = rowFilter.ToString(); 
		
		// handle where there is more than one record with the Nth value
		// eliminate enough rows from the bottom of the dv using a filter on
		// primary key to return the correct number (TOP N) values.
		bool refilter = false;
		// iterate over all records in the view after the Nth
		for(int i = dv.Count; i > topN; i--)
		{
			// exclude the record using a filter on the primary key
			rowFilter.Append(" AND " + ORDERID_FIELD + "<>" + dv[i-1][ORDERID_FIELD]);
			refilter = true;
		}

		// reapply the view filter if necessary
		if (refilter)
			dv.RowFilter = rowFilter.ToString();

		// bind the view to the grid
		dataGrid.DataSource = dv;
		dataGrid.CaptionText = ORDERS_TABLE + " table: Top " + topN + " records for " + FREIGHT_FIELD + " value.";
	}
}