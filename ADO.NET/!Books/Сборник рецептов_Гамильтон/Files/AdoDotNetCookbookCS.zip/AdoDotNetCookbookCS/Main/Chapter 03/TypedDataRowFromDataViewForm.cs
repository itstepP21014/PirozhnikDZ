using System;
using System.Configuration;
using System.Windows.Forms;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class TypedDataRowFromDataViewForm : System.Windows.Forms.Form
{
	private DataView dv;

	// table name constants
	private const String CATEGORIES_TABLE		= "Categories";

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button findButton;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox categoryIdTextBox;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public TypedDataRowFromDataViewForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.findButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.label1 = new System.Windows.Forms.Label();
		this.categoryIdTextBox = new System.Windows.Forms.TextBox();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// findButton
		// 
		this.findButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.findButton.Location = new System.Drawing.Point(308, 8);
		this.findButton.Name = "findButton";
		this.findButton.TabIndex = 1;
		this.findButton.Text = "Find";
		this.findButton.Click += new System.EventHandler(this.findButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 40);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(376, 216);
		this.dataGrid.TabIndex = 2;
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(72, 16);
		this.label1.TabIndex = 3;
		this.label1.Text = "Category ID:";
		// 
		// categoryIdTextBox
		// 
		this.categoryIdTextBox.Location = new System.Drawing.Point(80, 8);
		this.categoryIdTextBox.Name = "categoryIdTextBox";
		this.categoryIdTextBox.TabIndex = 0;
		this.categoryIdTextBox.Text = "";
		// 
		// TypedDataRowFromDataViewForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(392, 266);
		this.Controls.Add(this.categoryIdTextBox);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.findButton);
		this.Name = "TypedDataRowFromDataViewForm";
		this.Text = "3.11 TypedDataRowFromDataViewForm";
		this.Load += new System.EventHandler(this.TypedDataRowFromDataViewForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void TypedDataRowFromDataViewForm_Load(object sender, System.EventArgs e)
	{
		// create the typed DataSet
		CategoriesDS dsTyped = new CategoriesDS();

		// create and fill the Categories table
		String sqlText = "SELECT CategoryID, CategoryName, Description FROM Categories";
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(dsTyped.Categories);

		// get the default view and set the sort key
		dv = dsTyped.Categories.DefaultView;
		dv.Sort = "CategoryID";
		// bind the default view of the Categories table to the grid
		dataGrid.DataSource = dv;
	}

	private void findButton_Click(object sender, System.EventArgs e)
	{
		int categoryId = 0;
		try
		{
			categoryId = Convert.ToInt32(categoryIdTextBox.Text);
			// get the index of the find row in the view
			int viewRowIndex = dv.Find(categoryId);
			if (viewRowIndex == -1)
				MessageBox.Show("Row not found for Category ID = " + categoryId);
			else
			{
				// cast the underlying row in the view to a typed row
				CategoriesDS.CategoriesRow typedRow = (CategoriesDS.CategoriesRow)dv[viewRowIndex].Row;

				// display the located typed row
				MessageBox.Show(typedRow.CategoryID + " - " + typedRow.CategoryName);
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}
}