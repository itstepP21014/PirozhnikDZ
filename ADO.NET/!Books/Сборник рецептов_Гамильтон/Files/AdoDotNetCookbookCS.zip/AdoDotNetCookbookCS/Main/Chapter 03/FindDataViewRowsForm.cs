using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class FindDataViewRowsForm : System.Windows.Forms.Form
{
	private DataView dv;

	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button findButton;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox customerIdTextBox;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.TextBox employeeIdTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public FindDataViewRowsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.findButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.customerIdTextBox = new System.Windows.Forms.TextBox();
		this.label2 = new System.Windows.Forms.Label();
		this.employeeIdTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// findButton
		// 
		this.findButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.findButton.Location = new System.Drawing.Point(408, 8);
		this.findButton.Name = "findButton";
		this.findButton.TabIndex = 2;
		this.findButton.Text = "Find";
		this.findButton.Click += new System.EventHandler(this.findButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 64);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(472, 192);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(72, 23);
		this.label1.TabIndex = 2;
		this.label1.Text = "Customer ID:";
		// 
		// customerIdTextBox
		// 
		this.customerIdTextBox.Location = new System.Drawing.Point(96, 8);
		this.customerIdTextBox.Name = "customerIdTextBox";
		this.customerIdTextBox.TabIndex = 0;
		this.customerIdTextBox.Text = "";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 32);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(72, 23);
		this.label2.TabIndex = 4;
		this.label2.Text = "Employee ID:";
		// 
		// employeeIdTextBox
		// 
		this.employeeIdTextBox.Location = new System.Drawing.Point(96, 32);
		this.employeeIdTextBox.Name = "employeeIdTextBox";
		this.employeeIdTextBox.TabIndex = 1;
		this.employeeIdTextBox.Text = "";
		// 
		// FindDataViewRowsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.employeeIdTextBox);
		this.Controls.Add(this.customerIdTextBox);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.findButton);
		this.Name = "FindDataViewRowsForm";
		this.Text = "3.09 FindDataViewRowsForm";
		this.Load += new System.EventHandler(this.DataViewSearchPerformanceForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void DataViewSearchPerformanceForm_Load(object sender, System.EventArgs e)
	{
		// fill the source table with schema and data
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable("Orders");
		da.FillSchema(dt, SchemaType.Source);
		da.Fill(dt);

		// create the data view for the Orders table and sort
		dv = new DataView(dt);
		dv.Sort = "CustomerID, EmployeeID";

	}

	private void findButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();
		DataRowView[] foundRows;

		// find the rows by the sort key value ProductID
		try
		{
			foundRows = dv.FindRows(new object[] {customerIdTextBox.Text,
				employeeIdTextBox.Text});
		}
		catch (FormatException ex)
		{
			resultTextBox.Text = ex.Message;
			return;
		}

		// display the results
		if(foundRows.Length == 0)
		{
			result.Append("No rows found.");
		}
		else
		{
			result.Append("ORDER\tREQUIRED DATE" + Environment.NewLine);

			// iterate over the collection of found rows
			foreach(DataRowView row in foundRows)
			{
				result.Append(row["OrderID"] + "\t" +
					row["RequiredDate"] +
					Environment.NewLine);
			}

			result.Append("COUNT\t" + foundRows.Length + Environment.NewLine);
		}

		resultTextBox.Text = result.ToString();
	}
}