using System;
using System.Configuration;
using System.IO;

using System.Data;
using System.Data.SqlClient;

public class DataSetDifferenceForm : System.Windows.Forms.Form
{
	// field name constants
	private const String CATEGORYID_FIELD		= "CategoryID";

	DataSet dsA, dsB;

	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.DataGrid aDataGrid;
	private System.Windows.Forms.DataGrid bDataGrid;
	private System.Windows.Forms.Button getDifferenceButton;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DataSetDifferenceForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.getDifferenceButton = new System.Windows.Forms.Button();
		this.aDataGrid = new System.Windows.Forms.DataGrid();
		this.bDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.aDataGrid)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.bDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 240);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(460, 144);
		this.resultTextBox.TabIndex = 0;
		this.resultTextBox.Text = "";
		// 
		// getDifferenceButton
		// 
		this.getDifferenceButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.getDifferenceButton.Location = new System.Drawing.Point(376, 396);
		this.getDifferenceButton.Name = "getDifferenceButton";
		this.getDifferenceButton.Size = new System.Drawing.Size(88, 23);
		this.getDifferenceButton.TabIndex = 1;
		this.getDifferenceButton.Text = "Get Difference";
		this.getDifferenceButton.Click += new System.EventHandler(this.getDifferenceButton_Click);
		// 
		// aDataGrid
		// 
		this.aDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.aDataGrid.CaptionText = "Table A";
		this.aDataGrid.DataMember = "";
		this.aDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.aDataGrid.Location = new System.Drawing.Point(8, 16);
		this.aDataGrid.Name = "aDataGrid";
		this.aDataGrid.Size = new System.Drawing.Size(224, 216);
		this.aDataGrid.TabIndex = 2;
		// 
		// bDataGrid
		// 
		this.bDataGrid.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
		this.bDataGrid.CaptionText = "Table B";
		this.bDataGrid.DataMember = "";
		this.bDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.bDataGrid.Location = new System.Drawing.Point(240, 16);
		this.bDataGrid.Name = "bDataGrid";
		this.bDataGrid.Size = new System.Drawing.Size(224, 216);
		this.bDataGrid.TabIndex = 3;
		// 
		// DataSetDifferenceForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(480, 430);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.bDataGrid,
																		this.aDataGrid,
																		this.getDifferenceButton,
																		this.resultTextBox});
		this.Name = "DataSetDifferenceForm";
		this.Text = "3.03 DataSetDifferenceForm";
		this.Load += new System.EventHandler(this.DataSetDifferenceForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.aDataGrid)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.bDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void DataSetDifferenceForm_Load(object sender, System.EventArgs e)
	{
		SqlDataAdapter da;
		String sqlText;

		// fill table A with Category schema and subset of data
		sqlText = "SELECT CategoryID, CategoryName, Description FROM Categories WHERE CategoryID BETWEEN 1 AND 5";
		DataTable dtA = new DataTable("TableA");
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(dtA);
		da.FillSchema(dtA, SchemaType.Source);
		// set up the identity column CategoryID
		dtA.Columns[0].AutoIncrement = true;
		dtA.Columns[0].AutoIncrementSeed = -1;
		dtA.Columns[0].AutoIncrementStep = -1;
		// create DataSet A and add table A
		dsA = new DataSet();
		dsA.Tables.Add(dtA);

		// fill table B with Category schema and subset of data
		sqlText = "SELECT CategoryID, CategoryName, Description FROM Categories WHERE CategoryID BETWEEN 4 AND 8";
		DataTable dtB = new DataTable("TableB");
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(dtB);
		da.FillSchema(dtB, SchemaType.Source);
		// set up the identity column CategoryID
		dtB.Columns[0].AutoIncrement = true;
		dtB.Columns[0].AutoIncrementSeed = -1;
		dtB.Columns[0].AutoIncrementStep = -1;
		// create DataSet B and add table B
		dsB = new DataSet();
		dsB.Tables.Add(dtB);

		// bind the default views for table A and table B to DataGrids
		// on the form
		aDataGrid.DataSource = dtA.DefaultView;
		bDataGrid.DataSource = dtB.DefaultView;
	}

	private void getDifferenceButton_Click(object sender, System.EventArgs e)
	{
		resultTextBox.Text = GetDataSetDifference(dsA, dsB);
	}

	private String GetDataSetDifference(DataSet ds1, DataSet ds2)
	{
		// accept any edits within the DataSet objects
		ds1.AcceptChanges();
		ds2.AcceptChanges();

		// create a DataSet to store the differences
		DataSet ds = new DataSet();

		DataTable dt1Copy = null;
		//iterate over the collection of tables in the first DataSet
		for (int i = 0; i < ds1.Tables.Count; i++)
		{
			DataTable dt1 = ds1.Tables[i];
			DataTable dt2 = ds2.Tables[i];

			// create a copy of the table in the first DataSet
			dt1Copy = dt1.Copy();

			// iterate over the collection of rows in the
			// copy of the table from the first DataSet
			foreach(DataRow row1 in dt1Copy.Rows)
			{
				DataRow row2 = dt2.Rows.Find(row1[CATEGORYID_FIELD]);
				if(row2 == null)
				{
					// delete rows not in table 2 from table 1
					row1.Delete();
				}
				else
				{
					// modify table 1 rows that are different from
					// table 2 rows
					for(int j = 0; j < dt1Copy.Columns.Count; j++)
					{
						if(row2[j] == DBNull.Value)
						{
							// column in table 2 is null,
							// but not null in table 1
							if(row1[j] != DBNull.Value)
								row1[j] = DBNull.Value;
						}
						else if (row1[j] == DBNull.Value)
						{
							// column in table 1 is null,
							// but not null in table 2
							row1[j] = row2[j];
						}
						else if(row1[j].ToString() != row2[j].ToString())
						{
							// neither column in table 1 or
							// table 2 is null, and the
							// values in the columns are
							// different
							row1[j] = row2[j];
						}
					}
				}
			}

			foreach(DataRow row2 in dt2.Rows)
			{
				DataRow row1 = dt1Copy.Rows.Find(row2[CATEGORYID_FIELD]);
				if(row1 == null)
				{
					// insert rows into table 1 that are in table 2
					// but not in table 1
					dt1Copy.LoadDataRow(row2.ItemArray, false);
				}
			}
			
			// add the table to the difference DataSet
			ds.Tables.Add(dt1Copy);
		}

		// write a XML Diffgram with containing the differences between tables
		StringWriter sw = new StringWriter();
		ds.WriteXml(sw, XmlWriteMode.DiffGram);

		return sw.ToString();
	}
}