using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class FindDataTableRowsForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";
	private const String SHIPCOUNTRY_FIELD	= "ShipCountry";

	private System.Windows.Forms.Button findButton;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.TextBox shipCountryTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public FindDataTableRowsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.findButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.label1 = new System.Windows.Forms.Label();
		this.shipCountryTextBox = new System.Windows.Forms.TextBox();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// findButton
		// 
		this.findButton.Location = new System.Drawing.Point(208, 8);
		this.findButton.Name = "findButton";
		this.findButton.TabIndex = 1;
		this.findButton.Text = "Find";
		this.findButton.Click += new System.EventHandler(this.findButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 40);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 64);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 112);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 144);
		this.dataGrid.TabIndex = 2;
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(48, 16);
		this.label1.TabIndex = 3;
		this.label1.Text = "Country:";
		// 
		// shipCountryTextBox
		// 
		this.shipCountryTextBox.Location = new System.Drawing.Point(64, 8);
		this.shipCountryTextBox.Name = "shipCountryTextBox";
		this.shipCountryTextBox.Size = new System.Drawing.Size(136, 20);
		this.shipCountryTextBox.TabIndex = 0;
		this.shipCountryTextBox.Text = "";
		// 
		// FindDataTableRowsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.shipCountryTextBox,
																		this.label1,
																		this.dataGrid,
																		this.resultTextBox,
																		this.findButton});
		this.Name = "FindDataTableRowsForm";
		this.Text = "3.08 FindDataTableRowsForm";
		this.Load += new System.EventHandler(this.FindDataTableRowsForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void FindDataTableRowsForm_Load(object sender, System.EventArgs e)
	{
		// fill the Orders table
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable(ORDERS_TABLE);
		da.Fill(dt);
		da.FillSchema(dt, SchemaType.Source);

		// bind the table to the grid
		dataGrid.DataSource = dt.DefaultView;
	}

	private void findButton_Click(object sender, System.EventArgs e)
	{
		// get the table bound to the grid
		DataTable dt = ((DataView)dataGrid.DataSource).Table;

		// build the filter using contents of the text box
		String filter = SHIPCOUNTRY_FIELD + " = '" + shipCountryTextBox.Text + "'";

		// locate the records using the Select() method of the DataTable
		DataRow[] drc = dt.Select(filter);
		resultTextBox.Text = "DataTable.Select returned " + drc.Length + " record(s)." + Environment.NewLine;

		// iterate over the collection of rows filtered in the previous step
		// and find them in the table using the Find() method of the 
		// DataRowCollection for the DataTable
		int findCount = 0;
		foreach(DataRow row in drc)
		{
			DataRow foundRow = dt.Rows.Find(row[ORDERID_FIELD]);
			if (foundRow != null)
				findCount++;
		}
		resultTextBox.Text += "DataTable.Rows.Find returned " + findCount + " record(s)." + Environment.NewLine;

		// locate records using the RowFilter property of the DataView
		DataView dv = new DataView(dt);
		dv.RowFilter = filter;
		resultTextBox.Text += "DataView.RowFilter returned " + dv.Count + " record(s).";
	}
}