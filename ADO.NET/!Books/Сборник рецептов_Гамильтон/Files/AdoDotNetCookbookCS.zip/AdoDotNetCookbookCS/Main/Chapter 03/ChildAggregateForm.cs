using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class ChildAggregateForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";

	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.DataGrid childAggregateDataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ChildAggregateForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.childAggregateDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.childAggregateDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// childAggregateDataGrid
		// 
		this.childAggregateDataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.childAggregateDataGrid.DataMember = "";
		this.childAggregateDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.childAggregateDataGrid.Location = new System.Drawing.Point(8, 8);
		this.childAggregateDataGrid.Name = "childAggregateDataGrid";
		this.childAggregateDataGrid.Size = new System.Drawing.Size(476, 216);
		this.childAggregateDataGrid.TabIndex = 1;
		// 
		// ChildAggregateForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.childAggregateDataGrid,
																		this.goButton});
		this.Name = "ChildAggregateForm";
		this.Text = "3.07 ChildAggregateForm";
		((System.ComponentModel.ISupportInitialize)(this.childAggregateDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		DataSet ds = new DataSet();
		
		SqlDataAdapter da;

		// fill the Order table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.Fill(orderTable);
		ds.Tables.Add(orderTable);

		// fill the OrderDetails table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderDetailTable = new DataTable(ORDERDETAILS_TABLE);
		da.Fill(orderDetailTable);
		ds.Tables.Add(orderDetailTable);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
			ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
			true);

		// create the expression column for the line total
		orderDetailTable.Columns.Add("OrderDetailTotal", typeof(Decimal), "(Quantity * UnitPrice) * (1-Discount)");
		// create the OrderDetails aggregate values in the Order table
		orderTable.Columns.Add("OrderDetailCount", typeof(int), "COUNT(Child.ProductId)");
		orderTable.Columns.Add("OrderTotal", typeof(Decimal), "SUM(Child.OrderDetailTotal)");

		// bind the DataSet to the grid
		childAggregateDataGrid.DataSource = ds.DefaultViewManager;
		childAggregateDataGrid.DataMember = ORDERS_TABLE;
	}
}