using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class ExpressionColumnForm : System.Windows.Forms.Form
{
	private DataView dv;
	private System.Windows.Forms.DataGrid resultDataGrid;
	private System.Windows.Forms.GroupBox groupBox1;
	private System.Windows.Forms.RadioButton sortNoneRadioButton;
	private System.Windows.Forms.RadioButton sortAscRadioButton;
	private System.Windows.Forms.RadioButton sortDescRadioButton;
	private System.Windows.Forms.GroupBox groupBox2;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Button applyButton;
	private System.Windows.Forms.TextBox filterLowerBound;
	private System.Windows.Forms.TextBox filterUpperBound;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ExpressionColumnForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultDataGrid = new System.Windows.Forms.DataGrid();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.sortDescRadioButton = new System.Windows.Forms.RadioButton();
		this.sortAscRadioButton = new System.Windows.Forms.RadioButton();
		this.sortNoneRadioButton = new System.Windows.Forms.RadioButton();
		this.groupBox2 = new System.Windows.Forms.GroupBox();
		this.filterUpperBound = new System.Windows.Forms.TextBox();
		this.filterLowerBound = new System.Windows.Forms.TextBox();
		this.label2 = new System.Windows.Forms.Label();
		this.label1 = new System.Windows.Forms.Label();
		this.applyButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).BeginInit();
		this.groupBox1.SuspendLayout();
		this.groupBox2.SuspendLayout();
		this.SuspendLayout();
		// 
		// resultDataGrid
		// 
		this.resultDataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultDataGrid.DataMember = "";
		this.resultDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.resultDataGrid.Location = new System.Drawing.Point(8, 112);
		this.resultDataGrid.Name = "resultDataGrid";
		this.resultDataGrid.Size = new System.Drawing.Size(512, 176);
		this.resultDataGrid.TabIndex = 1;
		// 
		// groupBox1
		// 
		this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				this.sortDescRadioButton,
																				this.sortAscRadioButton,
																				this.sortNoneRadioButton});
		this.groupBox1.Location = new System.Drawing.Point(8, 8);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(104, 96);
		this.groupBox1.TabIndex = 2;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Sort";
		// 
		// sortDescRadioButton
		// 
		this.sortDescRadioButton.Location = new System.Drawing.Point(8, 64);
		this.sortDescRadioButton.Name = "sortDescRadioButton";
		this.sortDescRadioButton.Size = new System.Drawing.Size(88, 24);
		this.sortDescRadioButton.TabIndex = 2;
		this.sortDescRadioButton.Text = "Descending";
		// 
		// sortAscRadioButton
		// 
		this.sortAscRadioButton.Location = new System.Drawing.Point(8, 40);
		this.sortAscRadioButton.Name = "sortAscRadioButton";
		this.sortAscRadioButton.Size = new System.Drawing.Size(88, 24);
		this.sortAscRadioButton.TabIndex = 1;
		this.sortAscRadioButton.Text = "Ascending";
		// 
		// sortNoneRadioButton
		// 
		this.sortNoneRadioButton.Checked = true;
		this.sortNoneRadioButton.Location = new System.Drawing.Point(8, 16);
		this.sortNoneRadioButton.Name = "sortNoneRadioButton";
		this.sortNoneRadioButton.Size = new System.Drawing.Size(88, 24);
		this.sortNoneRadioButton.TabIndex = 0;
		this.sortNoneRadioButton.TabStop = true;
		this.sortNoneRadioButton.Text = "None";
		// 
		// groupBox2
		// 
		this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				this.filterUpperBound,
																				this.filterLowerBound,
																				this.label2,
																				this.label1});
		this.groupBox2.Location = new System.Drawing.Point(120, 8);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new System.Drawing.Size(128, 96);
		this.groupBox2.TabIndex = 3;
		this.groupBox2.TabStop = false;
		this.groupBox2.Text = "Filter";
		// 
		// filterUpperBound
		// 
		this.filterUpperBound.Location = new System.Drawing.Point(48, 48);
		this.filterUpperBound.Name = "filterUpperBound";
		this.filterUpperBound.Size = new System.Drawing.Size(72, 20);
		this.filterUpperBound.TabIndex = 3;
		this.filterUpperBound.Text = "";
		// 
		// filterLowerBound
		// 
		this.filterLowerBound.Location = new System.Drawing.Point(48, 24);
		this.filterLowerBound.Name = "filterLowerBound";
		this.filterLowerBound.Size = new System.Drawing.Size(72, 20);
		this.filterLowerBound.TabIndex = 2;
		this.filterLowerBound.Text = "";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 48);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(40, 16);
		this.label2.TabIndex = 1;
		this.label2.Text = "To:";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 24);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(40, 16);
		this.label1.TabIndex = 0;
		this.label1.Text = "From:";
		// 
		// applyButton
		// 
		this.applyButton.Location = new System.Drawing.Point(256, 16);
		this.applyButton.Name = "applyButton";
		this.applyButton.TabIndex = 4;
		this.applyButton.Text = "Apply";
		this.applyButton.Click += new System.EventHandler(this.applyButton_Click);
		// 
		// ExpressionColumnForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(528, 302);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.applyButton,
																		this.groupBox2,
																		this.groupBox1,
																		this.resultDataGrid});
		this.Name = "ExpressionColumnForm";
		this.Text = "3.02 ExpressionColumnForm";
		this.Load += new System.EventHandler(this.ExpressionColumnForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).EndInit();
		this.groupBox1.ResumeLayout(false);
		this.groupBox2.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion

	private void ExpressionColumnForm_Load(object sender, System.EventArgs e)
	{
		// define the table and fill it with data
		DataTable dt = new DataTable("OrderDetails");
		String selectText = "SELECT * FROM [Order Details]";
		SqlDataAdapter da = new SqlDataAdapter(selectText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(dt);

		// add an expression column to the table
		dt.Columns.Add(new DataColumn("ExtendedPrice", typeof(Decimal), "(Quantity * UnitPrice) * (1 - Discount)"));

		// define the DataView object
		dv = dt.DefaultView;

		// bind the DataView to the DataGrid
		resultDataGrid.DataSource = dv;
	}

	private void applyButton_Click(object sender, System.EventArgs e)
	{
		bool isLowerBound = false;
		bool isUpperBound = false;

		Decimal lowerBound = 0;
		Decimal upperBound = 0;

		if(filterLowerBound.Text.Trim().Length > 0)
		{
			isLowerBound = true;
			try
			{
				lowerBound = Decimal.Parse(filterLowerBound.Text);
			}
			catch(System.FormatException)
			{
				MessageBox.Show("Invalid entry for lower bound.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
		}

		if(filterUpperBound.Text.Trim().Length>0)
		{
			isUpperBound = true;
			try
			{
				upperBound = Decimal.Parse(filterUpperBound.Text);
			}
			catch(System.FormatException)
			{
				MessageBox.Show("Invalid entry for upper bound.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
		}

		String filter = "";
		if(isLowerBound)
			filter = "ExtendedPrice >= " + lowerBound;
		
		if(isUpperBound)
			filter += ((isLowerBound)?" AND " : "") + "ExtendedPrice <= " + upperBound;

		// set the filter
		dv.RowFilter=filter;

		// set the sort
		if(sortNoneRadioButton.Checked)
			dv.Sort = "";
		else if(sortAscRadioButton.Checked)
			dv.Sort = "ExtendedPrice";
		else if(sortDescRadioButton.Checked)
			dv.Sort = "ExtendedPrice DESC";
	}
}