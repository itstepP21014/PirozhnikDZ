using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class FilterSortForm : System.Windows.Forms.Form
{
	// table name constants
	private const String CUSTOMERS_TABLE	= "Customers";
	private const String ORDERS_TABLE		= "Orders";

	// relation name constants
	private const String CUSTOMERS_ORDERS_RELATION = "Customers_Orders_Relation";

	// field name constants
	private const String CUSTOMERID_FIELD	= "CustomerID";
	private const String ORDERID_FIELD		= "OrderID";
	private const String CONTACTNAME_FIELD	= "ContactName";

	private DataSet ds;

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button refreshButton;
	private System.Windows.Forms.TextBox orderEmployeeIdTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.TextBox customerCountryTextBox;
	private System.Windows.Forms.CheckBox contactSortCheckBox;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public FilterSortForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.refreshButton = new System.Windows.Forms.Button();
		this.orderEmployeeIdTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.customerCountryTextBox = new System.Windows.Forms.TextBox();
		this.contactSortCheckBox = new System.Windows.Forms.CheckBox();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 88);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(392, 168);
		this.dataGrid.TabIndex = 4;
		// 
		// refreshButton
		// 
		this.refreshButton.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
		this.refreshButton.Location = new System.Drawing.Point(320, 8);
		this.refreshButton.Name = "refreshButton";
		this.refreshButton.TabIndex = 3;
		this.refreshButton.Text = "Refresh";
		this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
		// 
		// orderEmployeeIdTextBox
		// 
		this.orderEmployeeIdTextBox.Location = new System.Drawing.Point(120, 32);
		this.orderEmployeeIdTextBox.Name = "orderEmployeeIdTextBox";
		this.orderEmployeeIdTextBox.Size = new System.Drawing.Size(104, 20);
		this.orderEmployeeIdTextBox.TabIndex = 1;
		this.orderEmployeeIdTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 32);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(104, 16);
		this.label1.TabIndex = 3;
		this.label1.Text = "Order Employee ID:";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 8);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(104, 16);
		this.label2.TabIndex = 1;
		this.label2.Text = "Customer Country:";
		// 
		// customerCountryTextBox
		// 
		this.customerCountryTextBox.Location = new System.Drawing.Point(120, 8);
		this.customerCountryTextBox.Name = "customerCountryTextBox";
		this.customerCountryTextBox.Size = new System.Drawing.Size(104, 20);
		this.customerCountryTextBox.TabIndex = 0;
		this.customerCountryTextBox.Text = "";
		// 
		// contactSortCheckBox
		// 
		this.contactSortCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
		this.contactSortCheckBox.Location = new System.Drawing.Point(8, 56);
		this.contactSortCheckBox.Name = "contactSortCheckBox";
		this.contactSortCheckBox.Size = new System.Drawing.Size(128, 24);
		this.contactSortCheckBox.TabIndex = 2;
		this.contactSortCheckBox.Text = "Contact Name Sort";
		// 
		// FilterSortForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(408, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.contactSortCheckBox,
																		this.label2,
																		this.customerCountryTextBox,
																		this.label1,
																		this.orderEmployeeIdTextBox,
																		this.refreshButton,
																		this.dataGrid});
		this.Name = "FilterSortForm";
		this.Text = "3.01 FilterSortForm";
		this.Load += new System.EventHandler(this.FilterSortForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void FilterSortForm_Load(object sender, System.EventArgs e)
	{
		ds = new DataSet();
		
		SqlDataAdapter da;

		// fill the Customers table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Customers", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable customersTable = new DataTable(CUSTOMERS_TABLE);
		da.Fill(customersTable);
		ds.Tables.Add(customersTable);

		// fill the Order table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.Fill(orderTable);
		ds.Tables.Add(orderTable);

		// create a relation between the tables
		ds.Relations.Add(CUSTOMERS_ORDERS_RELATION,
			ds.Tables[CUSTOMERS_TABLE].Columns[CUSTOMERID_FIELD],
			ds.Tables[ORDERS_TABLE].Columns[CUSTOMERID_FIELD],
			true);

		// bind the DataViewManager to the grid
		dataGrid.SetDataBinding(ds.DefaultViewManager, CUSTOMERS_TABLE);
	}

	private void refreshButton_Click(object sender, System.EventArgs e)
	{
		String countryFilter = "";
		if (customerCountryTextBox.Text != "")
			countryFilter = "Country = '" + customerCountryTextBox.Text + "'";

		DataViewManager dvm = new DataViewManager(ds);

		// sort on the contact name, as appropriate
		if(contactSortCheckBox.Checked)
			dvm.DataViewSettings[CUSTOMERS_TABLE].Sort = CONTACTNAME_FIELD;

		// filter the Customers view for the country
		dvm.DataViewSettings[CUSTOMERS_TABLE].RowFilter = countryFilter;

		// filter to Orders view for the employee
		String employeeIdFilter = "";
		if (orderEmployeeIdTextBox.Text != "")
		{
			try
			{
				employeeIdFilter = "EmployeeId = " + Int32.Parse(orderEmployeeIdTextBox.Text);
			}
			catch (FormatException)
			{
				orderEmployeeIdTextBox.Text = "";
			}
		}
		dvm.DataViewSettings[ORDERS_TABLE].RowFilter = employeeIdFilter;

		// bind the DataViewManager to the grid
		dataGrid.SetDataBinding(dvm, CUSTOMERS_TABLE);
	}
}