using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class BuildDataSetProgramaticallyForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button buildDataSetButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public BuildDataSetProgramaticallyForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.buildDataSetButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(10, 10);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 3;
		// 
		// buildDataSetButton
		// 
		this.buildDataSetButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.buildDataSetButton.Location = new System.Drawing.Point(396, 234);
		this.buildDataSetButton.Name = "buildDataSetButton";
		this.buildDataSetButton.Size = new System.Drawing.Size(88, 23);
		this.buildDataSetButton.TabIndex = 2;
		this.buildDataSetButton.Text = "Build DataSet";
		this.buildDataSetButton.Click += new System.EventHandler(this.buildDataSetButton_Click);
		// 
		// BuildDataSetProgramaticallyForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.dataGrid,
																		this.buildDataSetButton});
		this.Name = "BuildDataSetProgramaticallyForm";
		this.Text = "2.02 BuildDataSetProgramaticallyForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void buildDataSetButton_Click(object sender, System.EventArgs e)
	{
		// create the DataSet
		DataSet ds = new DataSet("MyDataSet");

		// build the Orders (parent) table
		DataTable parentTable = new DataTable("Orders");
		
		DataColumnCollection cols = parentTable.Columns;
		// add the identity field
		DataColumn column = cols.Add("OrderID", typeof(System.Int32));            
		column.AutoIncrement = true;
		column.AutoIncrementSeed = -1;
		column.AutoIncrementStep = -1;
		// add the other fields
		cols.Add("CustomerID", typeof(System.String)).MaxLength = 5;  
		cols.Add("EmployeeID", typeof(System.Int32));  
		cols.Add("OrderDate", typeof(System.DateTime));  
		cols.Add("RequiredDate", typeof(System.DateTime));  
		cols.Add("ShippedDate", typeof(System.DateTime));  
		cols.Add("ShipVia", typeof(System.Int32));  
		cols.Add("Freight", typeof(System.Decimal));  
		cols.Add("ShipName", typeof(System.String)).MaxLength = 40;  
		cols.Add("ShipAddress", typeof(System.String)).MaxLength = 60;  
		cols.Add("ShipCity", typeof(System.String)).MaxLength = 15;  
		cols.Add("ShipRegion", typeof(System.String)).MaxLength = 15;  
		cols.Add("ShipPostalCode", typeof(System.String)).MaxLength = 10;  
		cols.Add("ShipCountry", typeof(System.String)).MaxLength = 15;  
		//set the primary key
		parentTable.PrimaryKey = new DataColumn[] {cols["OrderID"]};
		// add the Orders table to the DataSet
		ds.Tables.Add(parentTable);

		// build the Order Details (child) table
		DataTable childTable = new DataTable("Order Details");

		cols = childTable.Columns;
		// add the PK fields
		cols.Add("OrderID", typeof(System.Int32)).AllowDBNull = false;  
		cols.Add("ProductID", typeof(System.Int32)).AllowDBNull = false;  
		// add the other fields
		cols.Add("UnitPrice", typeof(System.Decimal)).AllowDBNull = false;  
		cols.Add("Quantity", typeof(System.Int16)).AllowDBNull = false;  
		cols.Add("Discount", typeof(System.Single)).AllowDBNull = false;  
		//set the primary key
		childTable.PrimaryKey = new DataColumn[]
			{
				cols["OrderID"],
				cols["ProductID"]
			};
		// Add the Order Details table to the DataSet
		ds.Tables.Add(childTable);

		// add the relationship between parent and child tables
		ds.Relations.Add("Order_OrderDetails_Relation",
			parentTable.Columns["OrderID"], childTable.Columns["OrderID"], true);

		// fill the tables from the data source
		SqlDataAdapter da;
		String sqlText;

		sqlText = "SELECT OrderID, CustomerID, EmployeeID, OrderDate, " +
			"RequiredDate, ShippedDate, ShipVia, Freight, ShipName, " +
			"ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry " +
			"FROM Orders";
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(parentTable);

		sqlText = "SELECT OrderID, ProductID, UnitPrice, Quantity, Discount " +
			"FROM [Order Details]";
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(childTable);

		// bind the default view of the Order table to the grid
		dataGrid.DataSource = parentTable.DefaultView;
	}
}