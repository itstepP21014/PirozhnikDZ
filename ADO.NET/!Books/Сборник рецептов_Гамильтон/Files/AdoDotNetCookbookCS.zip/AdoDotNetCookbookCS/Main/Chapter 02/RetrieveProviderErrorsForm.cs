using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class RetrieveProviderErrorsForm : System.Windows.Forms.Form
{
	private const String TABLENAME	= "TBL0215";
	private DataSet ds;
	private SqlDataAdapter da;

	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button updateButton;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.CheckBox testColumnErrorCheckBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public RetrieveProviderErrorsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.updateButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.testColumnErrorCheckBox = new System.Windows.Forms.CheckBox();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 232);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 92);
		this.resultTextBox.TabIndex = 0;
		this.resultTextBox.Text = "";
		// 
		// updateButton
		// 
		this.updateButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.updateButton.Location = new System.Drawing.Point(408, 8);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 1;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 40);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 184);
		this.dataGrid.TabIndex = 2;
		// 
		// testColumnErrorCheckBox
		// 
		this.testColumnErrorCheckBox.Location = new System.Drawing.Point(8, 8);
		this.testColumnErrorCheckBox.Name = "testColumnErrorCheckBox";
		this.testColumnErrorCheckBox.Size = new System.Drawing.Size(120, 24);
		this.testColumnErrorCheckBox.TabIndex = 3;
		this.testColumnErrorCheckBox.Text = "Test Column Error";
		// 
		// RetrieveProviderErrorsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 334);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.testColumnErrorCheckBox,
																		this.dataGrid,
																		this.updateButton,
																		this.resultTextBox});
		this.Name = "RetrieveProviderErrorsForm";
		this.Text = "2.15 RetrieveProviderErrorsForm";
		this.Load += new System.EventHandler(this.RetrieveProviderErrorsForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void RetrieveProviderErrorsForm_Load(object sender, System.EventArgs e)
	{
		String sqlText = "SELECT * FROM " + TABLENAME;

		// create the DataAdapter and its CommandBuilder
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.ContinueUpdateOnError = true;
		SqlCommandBuilder cb = new SqlCommandBuilder(da);

		// create a table and fill it
		DataTable dt = new DataTable(TABLENAME);
		dt.Columns.Add("UniqueId", typeof(Int32));
		dt.Columns.Add("NumericField");		// data type not specified
		dt.Columns.Add("StringNoNullsField", typeof(String));
		dt.Columns.Add("ConstrainedNegativeField", typeof(Int32));
		da.Fill(dt);
		
		// create the DataSet and add the table
		ds = new DataSet();
		ds.Tables.Add(dt);

		// bind the default view for the table to the grid
		dataGrid.DataSource = dt.DefaultView;
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		if (testColumnErrorCheckBox.Checked)
			// set a column error on to demonstrate
			ds.Tables[0].Rows[0].SetColumnError(0, "test error");
		else
			// clear the demonstration column error
			ds.Tables[0].Rows[0].SetColumnError(0, "");

		da.Update(ds, TABLENAME);

		result.Append("Dataset.HasErrors = " + ds.HasErrors + Environment.NewLine);

		// iterate over the collection of tables in the DataSet
		foreach(DataTable dt in ds.Tables)
		{
			// Display whether the table has errors
			result.Append("\tTable [" + dt.TableName + "] HasErrors = " + dt.HasErrors + Environment.NewLine);

			int rowCount = 0;
			// iterate over trows in the table having errors
			foreach(DataRow row in dt.GetErrors())
			{
				// display whether error information for the row
				result.Append("\t\tRow [" + (++rowCount) + "] HasErrors = " + row.HasErrors + Environment.NewLine);
				if(row.RowError != "")
					result.Append("\t\t" + row.RowError + Environment.NewLine);

				// iterate over the column errors for the row
				foreach(DataColumn col in row.GetColumnsInError())
				{
					// display error information for the column
					result.Append("\t\t\tColumn [" + col.ColumnName + "]: " + row.GetColumnError(col) + Environment.NewLine);
				}
			}
		}

		resultTextBox.Text = result.ToString();
	}
}