using System;
using System.Configuration;
using System.IO;
using System.Text;

using System.Messaging;

using System.Data;
using System.Data.SqlClient;

public class MessageQueueQueryForm : System.Windows.Forms.Form
{
	private const String QUEUENAMEQUERY		= @".\Private$\adodotnetcb0222query";
	private const String QUEUENAMERESULT	= @".\Private$\adodotnetcb0222result";

	private System.Messaging.MessageQueue messageQueue;

	private System.Windows.Forms.Button sendButton;
	private System.Windows.Forms.TextBox customerIdTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Button processQueryButton;
	private System.Windows.Forms.Button processResultButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public MessageQueueQueryForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.messageQueue = new System.Messaging.MessageQueue();
		this.processQueryButton = new System.Windows.Forms.Button();
		this.sendButton = new System.Windows.Forms.Button();
		this.customerIdTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.processResultButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// messageQueue
		// 
		this.messageQueue.SynchronizingObject = this;
		// 
		// processQueryButton
		// 
		this.processQueryButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.processQueryButton.Location = new System.Drawing.Point(296, 40);
		this.processQueryButton.Name = "processQueryButton";
		this.processQueryButton.Size = new System.Drawing.Size(88, 23);
		this.processQueryButton.TabIndex = 2;
		this.processQueryButton.Text = "Process Query";
		this.processQueryButton.Click += new System.EventHandler(this.processQueryButton_Click);
		// 
		// sendButton
		// 
		this.sendButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.sendButton.Location = new System.Drawing.Point(296, 8);
		this.sendButton.Name = "sendButton";
		this.sendButton.Size = new System.Drawing.Size(88, 23);
		this.sendButton.TabIndex = 1;
		this.sendButton.Text = "Send";
		this.sendButton.Click += new System.EventHandler(this.sendButton_Click);
		// 
		// customerIdTextBox
		// 
		this.customerIdTextBox.Location = new System.Drawing.Point(80, 8);
		this.customerIdTextBox.Name = "customerIdTextBox";
		this.customerIdTextBox.Size = new System.Drawing.Size(88, 20);
		this.customerIdTextBox.TabIndex = 0;
		this.customerIdTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(72, 23);
		this.label1.TabIndex = 3;
		this.label1.Text = "Customer ID:";
		// 
		// processResultButton
		// 
		this.processResultButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.processResultButton.Location = new System.Drawing.Point(296, 72);
		this.processResultButton.Name = "processResultButton";
		this.processResultButton.Size = new System.Drawing.Size(88, 23);
		this.processResultButton.TabIndex = 3;
		this.processResultButton.Text = "Process Result";
		this.processResultButton.Click += new System.EventHandler(this.processResultButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 176);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(376, 80);
		this.resultTextBox.TabIndex = 4;
		this.resultTextBox.Text = "";
		// 
		// MessageQueueQueryForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(392, 266);
		this.Controls.Add(this.processResultButton);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.customerIdTextBox);
		this.Controls.Add(this.sendButton);
		this.Controls.Add(this.processQueryButton);
		this.Name = "MessageQueueQueryForm";
		this.Text = "2.22 MessageQueueQueryForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void sendButton_Click(object sender, System.EventArgs e)
	{
		// create the query queue if it does not exist
		if(!MessageQueue.Exists(QUEUENAMEQUERY))
			MessageQueue.Create(QUEUENAMEQUERY);

		// create an object to access the query queue
		MessageQueue mq = new MessageQueue(QUEUENAMEQUERY);

		// send a message containing the user-enetered customer ID
		String msg = "CustomerId=" + customerIdTextBox.Text;
		mq.Send(msg);

		resultTextBox.Text = "Query sent.";
	}

	private void processQueryButton_Click(object sender, System.EventArgs e)
	{
		// create the query queue if it does not exist
		if(!MessageQueue.Exists(QUEUENAMEQUERY))
			MessageQueue.Create(QUEUENAMEQUERY);

		// create an object to access the query queue
		MessageQueue mq = new MessageQueue(QUEUENAMEQUERY);
		// set the formatter for (de)serialization of message bodies
		mq.Formatter = new XmlMessageFormatter(new Type[] {typeof(String)});

		// receive a message from the query queue
		System.Messaging.Message msg;
		try
		{
			msg = mq.Receive(new TimeSpan(0, 0, 1));
			resultTextBox.Text = "Query " + msg.Id + " received." + Environment.NewLine;
		}
		catch(MessageQueueException ex)
		{
			resultTextBox.Text = ex.Message;
			return;
		}

		// get the customer ID from the message body
		String customerId = ((String)msg.Body).Substring(11);
		// close the queue
		mq.Close();

		// create a DataAdapter to retrieve data for the specified customer
		String sqlText = "SELECT * FROM Customers WHERE CustomerID='" + customerId + "'";
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// fill the Customer table in the DataSet with customer data
		DataSet ds = new DataSet();
		da.Fill(ds, "Customers");

		// create the result queue if it does not exist
		if(!MessageQueue.Exists(QUEUENAMERESULT))
			MessageQueue.Create(QUEUENAMERESULT);

		// create an object to access the result queue
		mq = new MessageQueue(QUEUENAMERESULT);

		// send a message with the customer DataSet to the queue
		mq.Send(ds, customerId);

		resultTextBox.Text = "Response sent.";
	}

	private void processResultButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// create the result queue if it does not exist
		if(!MessageQueue.Exists(QUEUENAMERESULT))
			MessageQueue.Create(QUEUENAMERESULT);

		// create an object to access the result queue
		MessageQueue mq = new MessageQueue(QUEUENAMERESULT);
		// set the formatter for (de)serialization of message bodies
		mq.Formatter = new XmlMessageFormatter(new Type[] {typeof(DataSet)});

		// receive a message from the result queue
		System.Messaging.Message msg;
		try
		{
			msg = mq.Receive(new TimeSpan(0, 0, 1));
		}
		catch(MessageQueueException ex)
		{
			resultTextBox.Text = ex.Message;
			return;
		}

		// create the customer DataSet from the message body
		DataSet ds = (DataSet)msg.Body;
		
		// display the results of the query
		result.Append("QUERY RESULTS:" + Environment.NewLine);
		if (ds.Tables["Customers"].Rows.Count == 0)
			result.Append("Customer not found for ID = '" + msg.Label + "'.");
		else
			for(int i = 0; i < ds.Tables[0].Columns.Count; i++)
			{
				result.Append(ds.Tables[0].Columns[i].ColumnName + " = " + ds.Tables[0].Rows[0][i] + Environment.NewLine);
			}

		resultTextBox.Text = result.ToString();
	}
}