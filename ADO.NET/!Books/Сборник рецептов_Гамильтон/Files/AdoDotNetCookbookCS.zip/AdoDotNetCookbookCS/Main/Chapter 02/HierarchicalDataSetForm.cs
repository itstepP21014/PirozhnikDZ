using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class HierarchicalDataSetForm : System.Windows.Forms.Form
{
	private DataSet ds;

	private System.Windows.Forms.Button loadDataSetButton;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.RadioButton loadParentFirstRadioButton;
	private System.Windows.Forms.RadioButton loadChildFirstRadioButton;
	private System.Windows.Forms.CheckBox enforceConstraintsCheckBox;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public HierarchicalDataSetForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.loadDataSetButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.loadParentFirstRadioButton = new System.Windows.Forms.RadioButton();
		this.loadChildFirstRadioButton = new System.Windows.Forms.RadioButton();
		this.enforceConstraintsCheckBox = new System.Windows.Forms.CheckBox();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// loadDataSetButton
		// 
		this.loadDataSetButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.loadDataSetButton.Location = new System.Drawing.Point(394, 232);
		this.loadDataSetButton.Name = "loadDataSetButton";
		this.loadDataSetButton.Size = new System.Drawing.Size(88, 23);
		this.loadDataSetButton.TabIndex = 0;
		this.loadDataSetButton.Text = "Load DataSet";
		this.loadDataSetButton.Click += new System.EventHandler(this.loadDataSetButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 1;
		// 
		// loadParentFirstRadioButton
		// 
		this.loadParentFirstRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.loadParentFirstRadioButton.Checked = true;
		this.loadParentFirstRadioButton.Location = new System.Drawing.Point(8, 232);
		this.loadParentFirstRadioButton.Name = "loadParentFirstRadioButton";
		this.loadParentFirstRadioButton.Size = new System.Drawing.Size(112, 24);
		this.loadParentFirstRadioButton.TabIndex = 4;
		this.loadParentFirstRadioButton.TabStop = true;
		this.loadParentFirstRadioButton.Text = "Load Parent First";
		// 
		// loadChildFirstRadioButton
		// 
		this.loadChildFirstRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.loadChildFirstRadioButton.Location = new System.Drawing.Point(120, 232);
		this.loadChildFirstRadioButton.Name = "loadChildFirstRadioButton";
		this.loadChildFirstRadioButton.TabIndex = 5;
		this.loadChildFirstRadioButton.Text = "Load Child First";
		// 
		// enforceConstraintsCheckBox
		// 
		this.enforceConstraintsCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.enforceConstraintsCheckBox.Location = new System.Drawing.Point(240, 232);
		this.enforceConstraintsCheckBox.Name = "enforceConstraintsCheckBox";
		this.enforceConstraintsCheckBox.Size = new System.Drawing.Size(144, 24);
		this.enforceConstraintsCheckBox.TabIndex = 6;
		this.enforceConstraintsCheckBox.Text = "Enforce Constraints On";
		// 
		// HierarchicalDataSetForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.enforceConstraintsCheckBox);
		this.Controls.Add(this.loadChildFirstRadioButton);
		this.Controls.Add(this.loadParentFirstRadioButton);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.loadDataSetButton);
		this.Name = "HierarchicalDataSetForm";
		this.Text = "2.01 HierarchicalDataSetForm";
		this.Load += new System.EventHandler(this.HierarchicalDataSetForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void HierarchicalDataSetForm_Load(object sender, System.EventArgs e)
	{
		ds = new DataSet();

		// get the schema for the Orders table
		DataTable parentTable = new DataTable("Orders");
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.FillSchema(parentTable, SchemaType.Source);
		ds.Tables.Add(parentTable);

		// get the schema for the Order Details table
		DataTable childTable = new DataTable("Order Details");
		da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.FillSchema(childTable, SchemaType.Source);
		ds.Tables.Add(childTable);

		// add the relation between the tables
		DataRelation dr = new DataRelation("Order_OrderDetails_Relation",
			parentTable.Columns["OrderID"], childTable.Columns["OrderID"]);
		ds.Relations.Add(dr);

		// bind the default view of the Orders table with the grid
		dataGrid.DataSource = parentTable.DefaultView;		
	}

	private void loadDataSetButton_Click(object sender, System.EventArgs e)
	{
		// remove all data from the DataSet and refresh the grid
		ds.Clear();
		dataGrid.Refresh();

		// create parent and child data adapters
		SqlDataAdapter daParent = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlDataAdapter daChild = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// enforce constraints as specified by user
		ds.EnforceConstraints = (enforceConstraintsCheckBox.Checked);

		try
		{
			if (loadParentFirstRadioButton.Checked)
			{
				// load parent data first
				daParent.Fill(ds, "Orders");
				daChild.Fill(ds, "Order Details");
			}
			else
			{
				// load child data first
				daChild.Fill(ds, "Order Details");
				daParent.Fill(ds, "Orders");
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
			return;
		}

		ds.EnforceConstraints = true;
	}
}