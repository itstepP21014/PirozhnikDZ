using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class DataReaderRowCountForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DataReaderRowCountForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// DataReaderRowCountForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.goButton);
		this.Name = "DataReaderRowCountForm";
		this.Text = "2.07 DataReaderRowCountForm";
		this.ResumeLayout(false);

	}
	#endregion


	private void goButton_Click(object sender, System.EventArgs e)
	{
		// batch query to retrieve the COUNT of records and
		// all of the records in the Orders table as two result sets
		String sqlText = "SELECT COUNT(*) FROM Orders; " +
			"SELECT * FROM Orders;";

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		conn.Open();

		// create a DataReader on the first result set
		SqlDataReader dr = cmd.ExecuteReader();
		// get the count of records from the select count(*) statement
		dr.Read();
		resultTextBox.Text = "Orders table record count, using COUNT(*)= " + dr.GetInt32(0) + Environment.NewLine;

		// move to the data result set
		dr.NextResult();
		int count = 0;
		// iterate over the records in the DataReader
		while(dr.Read())
		{
			count++;

			// ... do something interesting with the data here
		}

		// close the DataReader and the connection
		dr.Close();

		resultTextBox.Text += "Orders table record count, " +
			"iterating over result set = " + count +
			Environment.NewLine;

		// create the stored procedure to use in the DataReader
		cmd = new SqlCommand("SP0207_GetOrders", conn);
		cmd.CommandType = CommandType.StoredProcedure;
		// create the output paramter to return @@ROWCOUNT
		cmd.Parameters.Add("@RowCount", SqlDbType.Int).Direction = ParameterDirection.Output;

		// create a DataReader for the result set returned by
		// the stored procedure
		dr = cmd.ExecuteReader();

		// ... process the data in the DataReader

		// close the DataReader
		dr.Close();
		// the output parameter containing the row count in now available

		resultTextBox.Text += "Orders table record count, " +
			"returning @@ROWCOUNT from stored procedure = " + cmd.Parameters["@RowCount"].Value;

		conn.Close();
	}
}