using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class UsingParameterizedQueriesForm : System.Windows.Forms.Form
{
	// table name constants
	private const String CUSTOMERS_TABLE	= "Customers";
	private const String ORDERS_TABLE		= "Orders";

	private System.Windows.Forms.DataGrid customerDataGrid;
	private System.Windows.Forms.DataGrid orderDataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public UsingParameterizedQueriesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.customerDataGrid = new System.Windows.Forms.DataGrid();
		this.orderDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.customerDataGrid)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.orderDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// customerDataGrid
		// 
		this.customerDataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.customerDataGrid.CaptionText = "Customers";
		this.customerDataGrid.DataMember = "";
		this.customerDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.customerDataGrid.Location = new System.Drawing.Point(8, 8);
		this.customerDataGrid.Name = "customerDataGrid";
		this.customerDataGrid.ReadOnly = true;
		this.customerDataGrid.Size = new System.Drawing.Size(426, 192);
		this.customerDataGrid.TabIndex = 0;
		this.customerDataGrid.CurrentCellChanged += new System.EventHandler(this.customerDataGrid_CurrentCellChanged);
		// 
		// orderDataGrid
		// 
		this.orderDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.orderDataGrid.CaptionText = "Orders";
		this.orderDataGrid.DataMember = "";
		this.orderDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.orderDataGrid.Location = new System.Drawing.Point(8, 216);
		this.orderDataGrid.Name = "orderDataGrid";
		this.orderDataGrid.ReadOnly = true;
		this.orderDataGrid.Size = new System.Drawing.Size(426, 192);
		this.orderDataGrid.TabIndex = 1;
		// 
		// UsingParameterizedQueriesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(442, 416);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.orderDataGrid,
																		this.customerDataGrid});
		this.Name = "UsingParameterizedQueriesForm";
		this.Text = "2.22 UsingParameterizedQueriesForm";
		this.Load += new System.EventHandler(this.UsingParameterizedQueriesForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.customerDataGrid)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.orderDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void UsingParameterizedQueriesForm_Load(object sender, System.EventArgs e)
	{
		String sqlText = "SELECT * FROM Customers";
	
		// retrieve table with all customers
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable(CUSTOMERS_TABLE);
		da.Fill(dt);

		// bind the default view of the Customers table to the customers grid
		customerDataGrid.DataSource = dt.DefaultView;
		// fire the CurrentCellChanged event to refresh the orders grid
		customerDataGrid_CurrentCellChanged(null, null);
	}

	private void customerDataGrid_CurrentCellChanged(object sender, System.EventArgs e)
	{
		// get the current row in the customers grid
		int row = customerDataGrid.CurrentRowIndex;
		// get the customer ID from the view
		String customerId = ((DataView)customerDataGrid.DataSource).Table.Rows[row][0].ToString();
		// retrieve the orders for the customer
		LoadOrderGrid(customerId);
	}

	private void LoadOrderGrid(String customerId)
	{
		String sqlText = "SELECT * FROM Orders WHERE CustomerID = @CustomerID";

		// create a connection, and parameterized command
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		// add the CustomerID parameter and set its value
		cmd.Parameters.Add("@CustomerID", SqlDbType.NChar, 5);
		cmd.Parameters["@CustomerID"].Value = customerId;

		// get the Orders result set for the Customer
		SqlDataAdapter da = new SqlDataAdapter(cmd);
		DataTable dt = new DataTable(ORDERS_TABLE);
		da.Fill(dt);

		// bind the default view of the orders table to the orders grid
		orderDataGrid.DataSource = dt.DefaultView;	
		// set the caption of the orders grid
		orderDataGrid.CaptionText = "Orders [CustomerID: " + customerId + "]";
	}
}