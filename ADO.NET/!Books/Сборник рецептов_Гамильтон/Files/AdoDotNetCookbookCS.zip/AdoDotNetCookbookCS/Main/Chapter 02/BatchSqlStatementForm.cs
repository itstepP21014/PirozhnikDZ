using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class BatchSqlStatementForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.DataGrid resultDataGrid;
	private System.Windows.Forms.RadioButton dataSetRadioButton;
	private System.Windows.Forms.RadioButton dataReaderRadioButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public BatchSqlStatementForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.resultDataGrid = new System.Windows.Forms.DataGrid();
		this.dataSetRadioButton = new System.Windows.Forms.RadioButton();
		this.dataReaderRadioButton = new System.Windows.Forms.RadioButton();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// resultDataGrid
		// 
		this.resultDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultDataGrid.DataMember = "";
		this.resultDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.resultDataGrid.Location = new System.Drawing.Point(8, 8);
		this.resultDataGrid.Name = "resultDataGrid";
		this.resultDataGrid.Size = new System.Drawing.Size(476, 216);
		this.resultDataGrid.TabIndex = 1;
		// 
		// dataSetRadioButton
		// 
		this.dataSetRadioButton.Checked = true;
		this.dataSetRadioButton.Location = new System.Drawing.Point(8, 232);
		this.dataSetRadioButton.Name = "dataSetRadioButton";
		this.dataSetRadioButton.Size = new System.Drawing.Size(64, 24);
		this.dataSetRadioButton.TabIndex = 2;
		this.dataSetRadioButton.TabStop = true;
		this.dataSetRadioButton.Text = "DataSet";
		this.dataSetRadioButton.CheckedChanged += new System.EventHandler(this.dataSetRadioButton_CheckedChanged);
		// 
		// dataReaderRadioButton
		// 
		this.dataReaderRadioButton.Location = new System.Drawing.Point(80, 232);
		this.dataReaderRadioButton.Name = "dataReaderRadioButton";
		this.dataReaderRadioButton.TabIndex = 3;
		this.dataReaderRadioButton.Text = "DataReader";
		this.dataReaderRadioButton.CheckedChanged += new System.EventHandler(this.dataReaderRadioButton_CheckedChanged);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
		this.resultTextBox.Size = new System.Drawing.Size(480, 216);
		this.resultTextBox.TabIndex = 4;
		this.resultTextBox.Text = "";
		this.resultTextBox.Visible = false;
		this.resultTextBox.WordWrap = false;
		// 
		// BatchSqlStatementForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.dataReaderRadioButton);
		this.Controls.Add(this.dataSetRadioButton);
		this.Controls.Add(this.resultDataGrid);
		this.Controls.Add(this.goButton);
		this.Name = "BatchSqlStatementForm";
		this.Text = "2.04 BatchSqlStatementForm";
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		// batch SQL query returning two result sets
		String sqlText = "select OrderID, CustomerID, EmployeeID, OrderDate, " +
			"RequiredDate, ShippedDate, ShipVia, Freight, ShipName, " +
			"ShipAddress, ShipCity, ShipRegion, ShipPostalCode, " +
			"ShipCountry " +
			"FROM Orders;" +
			"SELECT OrderID, ProductID, UnitPrice, Quantity, Discount " +
			"FROM [Order Details];";

		if (dataSetRadioButton.Checked)
		{
			SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);

			// map the automatically generated table names Table and Table1
			da.TableMappings.Add("Table", ORDERS_TABLE);
			da.TableMappings.Add("Table1", ORDERDETAILS_TABLE);

			// fill the DataSet with the results of the batch query
			DataSet ds = new DataSet();
			da.Fill(ds);

			// add a relation between the Order and Order Details tables
			ds.Relations.Add(new DataRelation(ORDERS_ORDERDETAILS_RELATION,
				ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
				ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
				true));

			// bind the default view of the Orders table to the grid
			resultDataGrid.DataSource = ds.Tables[ORDERS_TABLE];
		}
		else
		{
			StringBuilder sb = new StringBuilder();

			// create a new connection and command to fill the DataReader
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			SqlCommand cmd = new SqlCommand(sqlText, conn);
			conn.Open();
			
			// execute the batch query
			SqlDataReader dr = cmd.ExecuteReader();

			// process each result set in the DataReader
			int nResultSet = 0;
			do
			{
				sb.Append("RESULT SET: " + (++nResultSet) + Environment.NewLine);

				// iterate over the rows in the DataReader
				while(dr.Read())
				{
					// output each field in the DataReader row
					for(int i = 0; i < dr.FieldCount; i++)
						sb.Append(dr[i] + "; ");

					sb.Append(Environment.NewLine);
				}

				sb.Append(Environment.NewLine);
			} while(dr.NextResult());

			dr.Close();
			conn.Close();

			// display the results
			resultTextBox.Text = sb.ToString();
		}
	}

	private void dataSetRadioButton_CheckedChanged(object sender, System.EventArgs e)
	{
		// display the data grid for DataSet results
		resultDataGrid.Visible = true;
		resultTextBox.Visible = false;
	}

	private void dataReaderRadioButton_CheckedChanged(object sender, System.EventArgs e)
	{
		// display the text box for DataReader results
		resultDataGrid.Visible = false;
		resultTextBox.Visible = true;		
	}
}