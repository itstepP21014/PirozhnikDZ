using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class AccessDeletedRowsForm : System.Windows.Forms.Form
{
	private DataView dv;

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.RadioButton currentRadioButton;
	private System.Windows.Forms.RadioButton deletedRadioButton;
	private System.Windows.Forms.TextBox deletedTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AccessDeletedRowsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.currentRadioButton = new System.Windows.Forms.RadioButton();
		this.deletedRadioButton = new System.Windows.Forms.RadioButton();
		this.deletedTextBox = new System.Windows.Forms.TextBox();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 144);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 312);
		this.dataGrid.TabIndex = 0;
		// 
		// currentRadioButton
		// 
		this.currentRadioButton.Location = new System.Drawing.Point(8, 8);
		this.currentRadioButton.Name = "currentRadioButton";
		this.currentRadioButton.TabIndex = 1;
		this.currentRadioButton.Text = "Current Rows";
		this.currentRadioButton.CheckedChanged += new System.EventHandler(this.currentRadioButton_CheckedChanged);
		// 
		// deletedRadioButton
		// 
		this.deletedRadioButton.Location = new System.Drawing.Point(8, 32);
		this.deletedRadioButton.Name = "deletedRadioButton";
		this.deletedRadioButton.TabIndex = 2;
		this.deletedRadioButton.Text = "Deleted Rows";
		this.deletedRadioButton.CheckedChanged += new System.EventHandler(this.deletedRadioButton_CheckedChanged);
		// 
		// deletedTextBox
		// 
		this.deletedTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.deletedTextBox.Location = new System.Drawing.Point(8, 64);
		this.deletedTextBox.Multiline = true;
		this.deletedTextBox.Name = "deletedTextBox";
		this.deletedTextBox.ReadOnly = true;
		this.deletedTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.deletedTextBox.Size = new System.Drawing.Size(476, 72);
		this.deletedTextBox.TabIndex = 3;
		this.deletedTextBox.Text = "";
		// 
		// AccessDeletedRowsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 466);
		this.Controls.Add(this.deletedTextBox);
		this.Controls.Add(this.deletedRadioButton);
		this.Controls.Add(this.currentRadioButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "AccessDeletedRowsForm";
		this.Text = "2.06 AccessDeletedRowsForm";
		this.Load += new System.EventHandler(this.AccessDataSetDeletedRowsForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void AccessDataSetDeletedRowsForm_Load(object sender, System.EventArgs e)
	{
		// fill the Orders table
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable("Orders");
		da.Fill(dt);

		// define a view of just the Current rows 
		dv = new DataView(dt, null, null, DataViewRowState.CurrentRows);
		dataGrid.DataSource = dv;

		currentRadioButton.Checked = true;
	}

	private void currentRadioButton_CheckedChanged(object sender, System.EventArgs e)
	{
		// filter to include only current rows
		dv.RowStateFilter = DataViewRowState.CurrentRows;
		dataGrid.ReadOnly = false;

		deletedTextBox.Clear();
	}

	private void deletedRadioButton_CheckedChanged(object sender, System.EventArgs e)
	{
		// filter the view to include only deleted rows
		dv.RowStateFilter = DataViewRowState.Deleted;
		dataGrid.ReadOnly = true;

		// get the DataTable from the DataView
		DataTable dt = dv.Table;
		// filter using the DataTable RowState
		DataRow[] delRows = dt.Select(null, null, DataViewRowState.Deleted);

		StringBuilder sb = new StringBuilder("Deleted Records:" + Environment.NewLine);
		// iterate over the collection of deleted rows
		foreach(DataRow row in delRows)
			sb.Append("Order ID: " + row["OrderID", DataRowVersion.Original] + Environment.NewLine);
		
		deletedTextBox.Text = sb.ToString();
	}
}