using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class SpOutputValueDataReaderForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox outputValueTextBox;
	private System.Windows.Forms.Button goButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public SpOutputValueDataReaderForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.outputValueTextBox = new System.Windows.Forms.TextBox();
		this.goButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(9, 49);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(276, 208);
		this.resultTextBox.TabIndex = 7;
		this.resultTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(72, 16);
		this.label1.TabIndex = 6;
		this.label1.Text = "Output Value";
		// 
		// outputValueTextBox
		// 
		this.outputValueTextBox.Location = new System.Drawing.Point(88, 9);
		this.outputValueTextBox.Name = "outputValueTextBox";
		this.outputValueTextBox.TabIndex = 5;
		this.outputValueTextBox.Text = "1";
		// 
		// goButton
		// 
		this.goButton.Location = new System.Drawing.Point(209, 9);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 4;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// SpOutputValueDataReaderForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox,
																		this.label1,
																		this.outputValueTextBox,
																		this.goButton});
		this.Name = "SpOutputValueDataReaderForm";
		this.Text = "2.09 SpOutputValueDataReaderForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		
		// create the command
		SqlCommand cmd = new SqlCommand("SP0209_OutputValueWithDataReader", conn);
		cmd.CommandType = CommandType.StoredProcedure;

		// define the input parameter for the command
		cmd.Parameters.Add("@ValueIn", SqlDbType.Int);
		// set the input parameter value
		cmd.Parameters[0].Value = Convert.ToInt32(outputValueTextBox.Text);

		// define the output parameter for the command
		SqlParameter outParam = cmd.Parameters.Add("@ValueOut", SqlDbType.Int);
		outParam.Direction = ParameterDirection.Output;

		result.Append("Before execution, output value = " + outParam.Value + Environment.NewLine);

		// open the connection and create the DataReader 
		conn.Open();
		SqlDataReader dr = cmd.ExecuteReader();

		result.Append("After execution, output value = " + outParam.Value + Environment.NewLine);

		// iterate over the records for the DataReader
		int rowCount = 0;
		while (dr.Read())
		{
			rowCount++;
		
			// code to process result set in DataReader
		}

		result.Append("After reading all " + rowCount + " rows, output value = " + outParam.Value + Environment.NewLine);

		// close the DataReader
		dr.Close();
		result.Append("After DataReader.Close(), output value = " + outParam.Value + Environment.NewLine);

		// close the connection
		conn.Close();

		resultTextBox.Text = result.ToString();
	}
}
