using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class SpReturnValueDataReaderForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.TextBox returnValueTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public SpReturnValueDataReaderForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.returnValueTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Location = new System.Drawing.Point(208, 8);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// returnValueTextBox
		// 
		this.returnValueTextBox.Location = new System.Drawing.Point(88, 8);
		this.returnValueTextBox.Name = "returnValueTextBox";
		this.returnValueTextBox.TabIndex = 1;
		this.returnValueTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(72, 16);
		this.label1.TabIndex = 2;
		this.label1.Text = "Return Value";
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 48);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(276, 208);
		this.resultTextBox.TabIndex = 3;
		this.resultTextBox.Text = "";
		// 
		// SpReturnValueDataReaderForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox,
																		this.label1,
																		this.returnValueTextBox,
																		this.goButton});
		this.Name = "SpReturnValueDataReaderForm";
		this.Text = "2.12 SpReturnValueDataReaderForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		
		// create the command
		SqlCommand cmd = new SqlCommand("SP0212_ReturnValueWithDataReader", conn);
		cmd.CommandType = CommandType.StoredProcedure;

		// define the input parameter for the command
		cmd.Parameters.Add("@ValueIn", SqlDbType.Int);
		// set the input parameter value
		cmd.Parameters["@ValueIn"].Value = Convert.ToInt32(returnValueTextBox.Text);

		// define the return parameter for the command
		SqlParameter retParam = cmd.Parameters.Add("@ReturnValue", SqlDbType.Int);
		retParam.Direction = ParameterDirection.ReturnValue;

		result.Append("Before execution, return value = " + retParam.Value + Environment.NewLine);

		// open the connection and create the DataReader 
		conn.Open();
		SqlDataReader reader = cmd.ExecuteReader();

		result.Append("After execution, return value = " + retParam.Value + Environment.NewLine);

		// iterate over the records for the DataReader
		int rowCount = 0;
		while (reader.Read())
		{
			rowCount++;
		
			// code to process result set in DataReader
		}

		result.Append("After reading all " + rowCount + " rows, return value = " + retParam.Value + Environment.NewLine);

		// close the DataReader
		reader.Close();
		result.Append("After DataReader.Close(), return value = " + retParam.Value + Environment.NewLine);

		// close the connection
		conn.Close();
		result.Append("After Connection.Close(), return value = " + retParam.Value);

		resultTextBox.Text = result.ToString();
	}
}