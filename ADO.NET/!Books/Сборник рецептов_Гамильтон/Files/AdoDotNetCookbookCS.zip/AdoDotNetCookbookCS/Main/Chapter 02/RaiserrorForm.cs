using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class RaiserrorForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox severityTextBox;
	private System.Windows.Forms.TextBox stateTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Button raiseErrorButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public RaiserrorForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.severityTextBox = new System.Windows.Forms.TextBox();
		this.stateTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.raiseErrorButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// severityTextBox
		// 
		this.severityTextBox.Location = new System.Drawing.Point(96, 8);
		this.severityTextBox.Name = "severityTextBox";
		this.severityTextBox.TabIndex = 0;
		this.severityTextBox.Text = "";
		// 
		// stateTextBox
		// 
		this.stateTextBox.Location = new System.Drawing.Point(96, 32);
		this.stateTextBox.Name = "stateTextBox";
		this.stateTextBox.TabIndex = 1;
		this.stateTextBox.Text = "1";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(80, 16);
		this.label1.TabIndex = 2;
		this.label1.Text = "Severity (0-25)";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 36);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(80, 16);
		this.label2.TabIndex = 3;
		this.label2.Text = "State";
		// 
		// raiseErrorButton
		// 
		this.raiseErrorButton.Location = new System.Drawing.Point(208, 8);
		this.raiseErrorButton.Name = "raiseErrorButton";
		this.raiseErrorButton.TabIndex = 4;
		this.raiseErrorButton.Text = "Raise Error";
		this.raiseErrorButton.Click += new System.EventHandler(this.raiseErrorButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 72);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(276, 184);
		this.resultTextBox.TabIndex = 5;
		this.resultTextBox.Text = "";
		// 
		// RaiserrorForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox,
																		this.raiseErrorButton,
																		this.label2,
																		this.label1,
																		this.stateTextBox,
																		this.severityTextBox});
		this.Name = "RaiserrorForm";
		this.Text = "2.10 RaiserrorForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void raiseErrorButton_Click(object sender, System.EventArgs e)
	{
		resultTextBox.Text =
			"Severity: " + severityTextBox.Text + Environment.NewLine +
			"State: " + stateTextBox.Text + Environment.NewLine + Environment.NewLine;

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// attach handler for SqlInfoMessage events
		conn.InfoMessage += new SqlInfoMessageEventHandler(conn_InfoMessage);
		
		// define a stored procedure command and the parameters
		SqlCommand cmd = new SqlCommand("SP0210_Raiserror", conn);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@Severity", SqlDbType.Int);
		cmd.Parameters.Add("@State", SqlDbType.Int);
		// set the value for the stored procedure parameters
		cmd.Parameters["@Severity"].Value = severityTextBox.Text;
		cmd.Parameters["@State"].Value = stateTextBox.Text;

		// open the connection
		conn.Open();
		try
		{
			// try to execute the stored procedure
			cmd.ExecuteNonQuery();
		}
		catch(System.Data.SqlClient.SqlException ex)
		{
			// catch SqlException errors
			resultTextBox.Text += "ERROR: " + ex.Message;
		}
		catch(Exception ex)
		{
			// catch other errors
			resultTextBox.Text += "OTHER ERROR: " + ex.Message;
		}
		finally
		{
			// close the connection
			conn.Close();
		}
	}

	private void conn_InfoMessage(object sender, SqlInfoMessageEventArgs e)
	{
		resultTextBox.Text += "MESSAGE: " + e.Message;
	}
}