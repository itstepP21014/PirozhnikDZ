using System;
using System.Configuration;

using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

public class MappingsForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public MappingsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 1;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 2;
		// 
		// MappingsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.dataGrid,
																		this.goButton});
		this.Name = "MappingsForm";
		this.Text = "2.16 MappingsForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		// create the DataAdapter
		String sqlText = "SELECT CategoryID, CategoryName, Description " +
			"FROM Categories";
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// create the table mapping to map the default table name 'Table'
		DataTableMapping dtm = da.TableMappings.Add("Table", "tblmapCategories");
		// create the column mappings for the Categories table
		dtm.ColumnMappings.Add("CategoryID", "colmapCategoryID");
		dtm.ColumnMappings.Add("CategoryName", "colmapCategoryName");
		dtm.ColumnMappings.Add("Description", "colmapDescription");

		// create the DataSet and fill
		DataSet ds = new DataSet();
		da.Fill(ds);

		// retrieve and display the mapped name of the table as grid caption
		dataGrid.CaptionText = "TableName: " + ds.Tables[0].ToString();

		// bind the default view of the Categories table to the grid
		dataGrid.DataSource = ds.Tables["tblmapCategories"].DefaultView;
	}
}