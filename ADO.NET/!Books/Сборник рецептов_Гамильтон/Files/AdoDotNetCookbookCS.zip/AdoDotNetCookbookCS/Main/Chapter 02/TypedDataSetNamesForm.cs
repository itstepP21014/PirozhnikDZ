using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class TypedDataSetNamesForm : System.Windows.Forms.Form
{
	// table name constants
	private const String CATEGORIES_TABLE	= "Categories";

	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.TextBox textBox1;
	private System.Windows.Forms.RadioButton annotatedRadioButton;
	private System.Windows.Forms.RadioButton defaultRadioButton;
	private System.Windows.Forms.Button goButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public TypedDataSetNamesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.textBox1 = new System.Windows.Forms.TextBox();
		this.annotatedRadioButton = new System.Windows.Forms.RadioButton();
		this.defaultRadioButton = new System.Windows.Forms.RadioButton();
		this.goButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 40);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 2;
		this.resultTextBox.Text = "";
		// 
		// textBox1
		// 
		this.textBox1.Name = "textBox1";
		this.textBox1.TabIndex = 0;
		this.textBox1.Text = "";
		// 
		// annotatedRadioButton
		// 
		this.annotatedRadioButton.Location = new System.Drawing.Point(80, 8);
		this.annotatedRadioButton.Name = "annotatedRadioButton";
		this.annotatedRadioButton.Size = new System.Drawing.Size(88, 24);
		this.annotatedRadioButton.TabIndex = 4;
		this.annotatedRadioButton.Text = "Annotated";
		// 
		// defaultRadioButton
		// 
		this.defaultRadioButton.Checked = true;
		this.defaultRadioButton.Location = new System.Drawing.Point(8, 8);
		this.defaultRadioButton.Name = "defaultRadioButton";
		this.defaultRadioButton.Size = new System.Drawing.Size(64, 24);
		this.defaultRadioButton.TabIndex = 3;
		this.defaultRadioButton.TabStop = true;
		this.defaultRadioButton.Text = "Default";
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 8);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 5;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// TypedDataSetNamesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.annotatedRadioButton,
																		this.defaultRadioButton,
																		this.goButton,
																		this.resultTextBox});
		this.Name = "TypedDataSetNamesForm";
		this.Text = "2.18 TypedDataSetNamesForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// create the DataAdapter
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Categories", ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		if (annotatedRadioButton.Checked)
		{
			// create the typed DataSet with name annotations
			CategoriesDS_AnnotatedName ds = new CategoriesDS_AnnotatedName();
			// fill the Categories table within DataSet
			da.Fill(ds, CATEGORIES_TABLE);

			result.Append("Annotated Names" + Environment.NewLine + Environment.NewLine);
			// iterate over the rows collection and display columns
			// note that the row collection is Categorys and that each row is a Category
			foreach(CategoriesDS_AnnotatedName.Category row in ds.Categorys)
			{
				// note that the CategoryName field is referred simply as Name
				result.Append(row.CategoryID + "\t" + row.Name + "\t" + row.Description + Environment.NewLine);
			}
		}
		else
		{
			// create the typed DataSet without name annotations
			CategoriesDS ds = new CategoriesDS();
			da.Fill(ds, CATEGORIES_TABLE);

			result.Append("Default" + Environment.NewLine + Environment.NewLine);
			// iterate over the rows collection and display columns
			foreach(CategoriesDS.CategoriesRow row in ds.Categories)
			{
				result.Append(row.CategoryID + "\t" + row.CategoryName + "\t" + row.Description + Environment.NewLine);
			}
		}

		resultTextBox.Text = result.ToString();		
	}
}