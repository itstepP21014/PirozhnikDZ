using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class LookupColumnsForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";
	private const String CUSTOMERID_FIELD	= "CustomerID";

	private const String QUANTITY_FIELD		= "Quantity";

	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.DataGrid resultDataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public LookupColumnsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.resultDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(458, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// resultDataGrid
		// 
		this.resultDataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultDataGrid.DataMember = "";
		this.resultDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.resultDataGrid.Location = new System.Drawing.Point(8, 8);
		this.resultDataGrid.Name = "resultDataGrid";
		this.resultDataGrid.Size = new System.Drawing.Size(526, 216);
		this.resultDataGrid.TabIndex = 1;
		// 
		// LookupColumnsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(542, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultDataGrid,
																		this.goButton});
		this.Name = "LookupColumnsForm";
		this.Text = "2.17 LookupColumnsForm";
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		DataSet ds = new DataSet();

		// fill the Orders table and add it to the DataSet
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable ordersTable = new DataTable(ORDERS_TABLE);
		da.Fill(ordersTable);
		ds.Tables.Add(ordersTable);

		// fill the OrderDetails table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderDetailsTable = new DataTable(ORDERDETAILS_TABLE);
		da.Fill(orderDetailsTable);
		ds.Tables.Add(orderDetailsTable);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ordersTable.Columns[ORDERID_FIELD],
			orderDetailsTable.Columns[ORDERID_FIELD],
			true);

		// add a column to Orders for the total items in all Order Detail rows
		ordersTable.Columns.Add("TotalQuantity", typeof(int),
			"Sum(Child." + QUANTITY_FIELD + ")");

		// add a column to Order Details getting CustomerID from Order parent
		orderDetailsTable.Columns.Add(CUSTOMERID_FIELD, typeof(string),
			"Parent(" + ORDERS_ORDERDETAILS_RELATION + ")." + CUSTOMERID_FIELD);

		// bind the default view of the Order Details table to the grid
		resultDataGrid.DataSource = ordersTable.DefaultView;
	}
}