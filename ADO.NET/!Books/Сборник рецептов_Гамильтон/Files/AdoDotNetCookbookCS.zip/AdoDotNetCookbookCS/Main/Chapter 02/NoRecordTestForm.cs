using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class NoRecordTestForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";

	private System.Windows.Forms.Button runTestButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public NoRecordTestForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.runTestButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// runTestButton
		// 
		this.runTestButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.runTestButton.Location = new System.Drawing.Point(208, 232);
		this.runTestButton.Name = "runTestButton";
		this.runTestButton.TabIndex = 0;
		this.runTestButton.Text = "Run Test";
		this.runTestButton.Click += new System.EventHandler(this.runTestButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(276, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// NoRecordTestForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox,
																		this.runTestButton});
		this.Name = "NoRecordTestForm";
		this.Text = "2.11 NoRecordTestForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void runTestButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		// fill the Orders DataTable
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.Fill(orderTable);

		// test Orders DataTable for records
		bool tableHasRecords = orderTable.Rows.Count > 0;
		result.Append("DataTable " + ORDERS_TABLE + ": Has records = " +
			tableHasRecords + Environment.NewLine);

		// create the Orders DataReader
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand("SELECT * FROM ORDERS", conn);
		conn.Open();
		SqlDataReader orderReader = cmd.ExecuteReader();

		// test Orders DataReader for records
		result.Append("DataReader " + ORDERS_TABLE + ": Has records = " +
			orderReader.HasRows + Environment.NewLine);

		// test Orders DataReader for records
		bool readerHasRecords = orderReader.Read();
		result.Append("DataReader " + ORDERS_TABLE + ": Has records = " +
			readerHasRecords + Environment.NewLine);
		
		orderReader.Close();
		conn.Close();

		resultTextBox.Text = result.ToString();
	}
}