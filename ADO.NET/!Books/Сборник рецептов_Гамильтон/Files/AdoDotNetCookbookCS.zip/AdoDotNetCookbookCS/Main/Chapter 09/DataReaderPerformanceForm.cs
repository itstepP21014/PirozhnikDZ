using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class DataReaderPerformanceForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.RadioButton typedAccessorRadioButton;
	private System.Windows.Forms.RadioButton ordinalRadioButton;
	private System.Windows.Forms.RadioButton columnNameRadioButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DataReaderPerformanceForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.typedAccessorRadioButton = new System.Windows.Forms.RadioButton();
		this.ordinalRadioButton = new System.Windows.Forms.RadioButton();
		this.columnNameRadioButton = new System.Windows.Forms.RadioButton();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 8);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 96);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 160);
		this.resultTextBox.TabIndex = 2;
		this.resultTextBox.Text = "";
		// 
		// typedAccessorRadioButton
		// 
		this.typedAccessorRadioButton.Checked = true;
		this.typedAccessorRadioButton.Location = new System.Drawing.Point(8, 8);
		this.typedAccessorRadioButton.Name = "typedAccessorRadioButton";
		this.typedAccessorRadioButton.TabIndex = 3;
		this.typedAccessorRadioButton.TabStop = true;
		this.typedAccessorRadioButton.Text = "Typed Accessor";
		// 
		// ordinalRadioButton
		// 
		this.ordinalRadioButton.Location = new System.Drawing.Point(8, 32);
		this.ordinalRadioButton.Name = "ordinalRadioButton";
		this.ordinalRadioButton.TabIndex = 4;
		this.ordinalRadioButton.Text = "Ordinal";
		// 
		// columnNameRadioButton
		// 
		this.columnNameRadioButton.Location = new System.Drawing.Point(8, 56);
		this.columnNameRadioButton.Name = "columnNameRadioButton";
		this.columnNameRadioButton.TabIndex = 5;
		this.columnNameRadioButton.Text = "Column Name";
		// 
		// DataReaderPerformanceForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.columnNameRadioButton,
																		this.ordinalRadioButton,
																		this.typedAccessorRadioButton,
																		this.resultTextBox,
																		this.goButton});
		this.Name = "DataReaderPerformanceForm";
		this.Text = "9.06 DataReaderPerformanceForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		Cursor.Current = Cursors.WaitCursor;

		int orderId;
		String customerId;
		int employeeId;
		DateTime orderDate;
		DateTime requiredDate;
		DateTime shippedDate;
		int shipVia;
		Decimal freight;
		String shipName;
		String shipAddress;
		String shipCity;
		String shipRegion;
		String shipPostalCode;
		String shipCountry;

		String sqlText = "SELECT OrderID, CustomerID, EmployeeID, " +
			"OrderDate, RequiredDate, ShippedDate, " +
			"ShipVia, Freight, ShipName, ShipAddress, ShipCity, " +
			"ShipRegion, ShipPostalCode, ShipCountry " +
			"FROM Orders";

		// create the connection and the command
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);

		String accessMethod = typedAccessorRadioButton.Checked ? "Typed accessor":
			ordinalRadioButton.Checked ? "Ordinal":"Column name";
		int startTick = 0;
		int elapsedTick = 0;

		conn.Open();
		for(int i = 1; i < 100; i++)
		{
			// create the DataReader and retrieve all fields for each
			// record in the DataReader according to user request
			SqlDataReader dr = cmd.ExecuteReader();

			if (typedAccessorRadioButton.Checked)
			{
				startTick = Environment.TickCount;
				while (dr.Read())
				{
					orderId = dr.GetInt32(0);
					if(!dr.IsDBNull(1))
						customerId = dr.GetString(1);
					if(!dr.IsDBNull(2))
						employeeId = dr.GetInt32(2);
					if(!dr.IsDBNull(3))
						orderDate = dr.GetDateTime(3);
					if(!dr.IsDBNull(4))
						requiredDate = dr.GetDateTime(4);
					if(!dr.IsDBNull(5))
						shippedDate = dr.GetDateTime(5);
					if(!dr.IsDBNull(6))
						shipVia = dr.GetInt32(6);
					if(!dr.IsDBNull(7))
						freight = dr.GetDecimal(7);
					if(!dr.IsDBNull(8))
						shipName = dr.GetString(8);
					if(!dr.IsDBNull(9))
						shipAddress = dr.GetString(9);
					if(!dr.IsDBNull(10))
						shipCity = dr.GetString(10);
					if(!dr.IsDBNull(11))
						shipRegion = dr.GetString(11);
					if(!dr.IsDBNull(12))
						shipPostalCode = dr.GetString(12);
					if(!dr.IsDBNull(13))
						shipCountry = dr.GetString(13);
				}
				elapsedTick += Environment.TickCount-startTick;
			}

			if (ordinalRadioButton.Checked)
			{
				startTick = Environment.TickCount;
				while (dr.Read())
				{
					if (!dr.IsDBNull(0))
						orderId = Convert.ToInt32(dr[0]);
					if (!dr.IsDBNull(1))
						customerId = Convert.ToString(dr[1]);
					if (!dr.IsDBNull(2))
						employeeId = Convert.ToInt32(dr[2]);
					if (!dr.IsDBNull(3))
						orderDate = Convert.ToDateTime(dr[3]);
					if (!dr.IsDBNull(4))
						requiredDate = Convert.ToDateTime(dr[4]);
					if (!dr.IsDBNull(5))
						shippedDate = Convert.ToDateTime(dr[5]);
					if (!dr.IsDBNull(6))
						shipVia = Convert.ToInt32(dr[6]);
					if (!dr.IsDBNull(7))
						freight = Convert.ToDecimal(dr[7]);
					if (!dr.IsDBNull(8))
						shipName = Convert.ToString(dr[8]);
					if (!dr.IsDBNull(9))
						shipAddress = Convert.ToString(dr[9]);
					if (!dr.IsDBNull(10))
						shipCity = Convert.ToString(dr[10]);
					if (!dr.IsDBNull(11))
						shipRegion = Convert.ToString(dr[11]);
					if (!dr.IsDBNull(12))
						shipPostalCode = Convert.ToString(dr[12]);
					if (!dr.IsDBNull(13))
						shipCountry = Convert.ToString(dr[13]);
				}
				elapsedTick += Environment.TickCount-startTick;
			}

			if (columnNameRadioButton.Checked)
			{
				startTick = Environment.TickCount;
				while (dr.Read())
				{
					if (dr["OrderID"] != DBNull.Value)
						orderId = Convert.ToInt32(dr["OrderID"]);
					if (dr["CustomerID"] != DBNull.Value)
						customerId = Convert.ToString(dr["CustomerID"]);
					if (dr["EmployeeID"] != DBNull.Value)
						employeeId = Convert.ToInt32(dr["EmployeeID"]);
					if (dr["OrderDate"] != DBNull.Value)
						orderDate = Convert.ToDateTime(dr["OrderDate"]);
					if (dr["RequiredDate"] != DBNull.Value)
						requiredDate = Convert.ToDateTime(dr["RequiredDate"]);
					if (dr["ShippedDate"] != DBNull.Value)
						shippedDate = Convert.ToDateTime(dr["ShippedDate"]);
					if (dr["ShipVia"] != DBNull.Value)
						shipVia = Convert.ToInt32(dr["ShipVia"]);
					if (dr["Freight"] != DBNull.Value)
						freight = Convert.ToDecimal(dr["Freight"]);
					if (dr["ShipName"] != DBNull.Value)
						shipName = Convert.ToString(dr["ShipName"]);
					if (dr["ShipAddress"] != DBNull.Value)
						shipAddress = Convert.ToString(dr["ShipAddress"]);
					if (dr["ShipCity"] != DBNull.Value)
						shipCity = Convert.ToString(dr["ShipCity"]);
					if (dr["ShipRegion"] != DBNull.Value)
						shipRegion = Convert.ToString(dr["ShipRegion"]);
					if (dr["ShipPostalCode"] != DBNull.Value)
						shipPostalCode = Convert.ToString(dr["ShipPostalCode"]);
					if (dr["ShipCountry"] != DBNull.Value)
						shipCountry = Convert.ToString(dr["ShipCountry"]);
				}
				elapsedTick += Environment.TickCount-startTick;
			}

			dr.Close();
		}

		resultTextBox.Text += "Access method: " + accessMethod +
			"; Elapsed time: " + elapsedTick + " ticks." + Environment.NewLine;

		conn.Close();

		Cursor.Current = Cursors.Default;
	}
}