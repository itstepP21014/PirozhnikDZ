using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class CustomAdapterBatchUpdateForm : System.Windows.Forms.Form
{
	private const String CATEGORIES_TABLE	= "Categories";

	private const String CATEGORYID_FIELD	= "CategoryID";

	private DataTable dt;
	private SqlDataAdapter da;
	private SqlCommandBuilder cb;
	private StringBuilder sb;

	private System.Windows.Forms.Button updateButton;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public CustomAdapterBatchUpdateForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.updateButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// updateButton
		// 
		this.updateButton.Location = new System.Drawing.Point(408, 9);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 4;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 41);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 3;
		// 
		// CustomAdapterBatchUpdateForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.updateButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "CustomAdapterBatchUpdateForm";
		this.Text = "9.13 CustomAdapterBatchUpdateForm";
		this.Load += new System.EventHandler(this.CustomAdapterBatchUpdateForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void CustomAdapterBatchUpdateForm_Load(object sender, System.EventArgs e)
	{
		String sqlText = "SELECT CategoryID, CategoryName, Description " +
			"FROM Categories";

		// fill the categories table for editing
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// CommandBuilder supplies updating logic
		cb = new SqlCommandBuilder(da);
		// handle the RowUpdating event to batch the update
		da.RowUpdating += new SqlRowUpdatingEventHandler(da_RowUpdating);
		// create table and fill with orders schema and data
		dt = new DataTable(CATEGORIES_TABLE);
		da.FillSchema(dt, SchemaType.Source);
		// set up the autoincrement column
		dt.Columns[CATEGORYID_FIELD].AutoIncrementSeed = -1;
		dt.Columns[CATEGORYID_FIELD].AutoIncrementStep = -1;
		// fill the DataSet
		da.Fill(dt);

		// bind the default view of the table to the grid
		dataGrid.DataSource = dt.DefaultView;
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		// create a new SQL statement for all updates
		sb = new StringBuilder();

		// update the data source
		da.Update(dt);

		if (sb.Length >0)
		{
			// create a connection command with the aggregate update command
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			SqlCommand cmd = new SqlCommand(sb.ToString(), conn);
			// execute the update command
			conn.Open();
			cmd.ExecuteScalar();
			conn.Close();

			// refresh the DataTable
			dt.Clear();
			da.Fill(dt);
		}
	}

	private void da_RowUpdating(object sender, SqlRowUpdatingEventArgs e)
	{
		// get the command for the current row update
		StringBuilder sqlText = new StringBuilder(e.Command.CommandText.ToString());
		// replace the parameters with values
		for(int i = e.Command.Parameters.Count - 1; i >= 0; i--)
		{
			SqlParameter parm = e.Command.Parameters[i];
			if(parm.SqlDbType == SqlDbType.NVarChar || parm.SqlDbType == SqlDbType.NText)
				// quotes around the CategoryName and Description fields
				sqlText.Replace(parm.ParameterName, "'" + parm.Value.ToString() + "'");
			else
				sqlText.Replace(parm.ParameterName, parm.Value.ToString());
		}
		// add the row command to the aggregate update command
		sb.Append(sqlText.ToString() + ";");

		// skip the DataAdapter update of the row
		e.Status = UpdateStatus.SkipCurrentRow;
	}
}