using System;
using System.Configuration;

using System.Threading;

using System.Runtime.Remoting.Messaging;

using System.Data;
using System.Data.SqlClient;

public class AsynchronousFillForm : System.Windows.Forms.Form
{
	private delegate void BindDataSetToDataGridDelegate(DataSet ds);

	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";
	private const String ORDERDATE_FIELD	= "OrderDate";

	private bool isWorking = false;

	private System.Windows.Forms.TextBox statusTextBox;
	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.DataGrid resultDataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AsynchronousFillForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.statusTextBox = new System.Windows.Forms.TextBox();
		this.goButton = new System.Windows.Forms.Button();
		this.resultDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// statusTextBox
		// 
		this.statusTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.statusTextBox.Location = new System.Drawing.Point(8, 8);
		this.statusTextBox.Multiline = true;
		this.statusTextBox.Name = "statusTextBox";
		this.statusTextBox.ReadOnly = true;
		this.statusTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.statusTextBox.Size = new System.Drawing.Size(392, 64);
		this.statusTextBox.TabIndex = 0;
		this.statusTextBox.Text = "";
		// 
		// goButton
		// 
		this.goButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.goButton.Location = new System.Drawing.Point(408, 8);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 1;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// resultDataGrid
		// 
		this.resultDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultDataGrid.DataMember = "";
		this.resultDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.resultDataGrid.Location = new System.Drawing.Point(8, 80);
		this.resultDataGrid.Name = "resultDataGrid";
		this.resultDataGrid.Size = new System.Drawing.Size(476, 176);
		this.resultDataGrid.TabIndex = 2;
		// 
		// AsynchronousFillForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.resultDataGrid);
		this.Controls.Add(this.goButton);
		this.Controls.Add(this.statusTextBox);
		this.Name = "AsynchronousFillForm";
		this.Text = "9.01 AsynchronousFillForm";
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		// Check if the DataSet is already being filled
		if (!isWorking)
		{
			isWorking = true;

			// clear the data grid
			resultDataGrid.DataSource = null;
			
			// create and start a new thread to fill the DataSet
			Thread thread = new Thread(new ThreadStart(AsyncFillDataSet));
			thread.Start();
		}
		else
		{
			// DataSet already being filled � display a message
			statusTextBox.Text += "DataSet still filling ..." + Environment.NewLine;
		}
	}

	private void AsyncFillDataSet()
	{
		statusTextBox.Text = "Filling DataSet ..." + Environment.NewLine;

		DataSet ds = new DataSet("Source");
		
		SqlDataAdapter da;

		// fill the Order table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.FillSchema(orderTable, SchemaType.Source);
		da.Fill(orderTable);
		ds.Tables.Add(orderTable);

		// fill the OrderDetails table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderDetailTable = new DataTable(ORDERDETAILS_TABLE);
		da.FillSchema(orderDetailTable, SchemaType.Source);
		da.Fill(orderDetailTable);
		ds.Tables.Add(orderDetailTable);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
			ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
			true);

		statusTextBox.Text += "DataSet Fill complete." + Environment.NewLine;

		// call the BindDataSetToDataGrid method asynchronously
		// on the Form's thread
		this.BeginInvoke(new BindDataSetToDataGridDelegate(BindDataSetToDataGrid), new object[] {ds});

		// set flag indicating that the async fill is complete
		isWorking = false;
	}

	private void BindDataSetToDataGrid(DataSet ds)
	{
		// bind the default view of the Orders table to the data grid
		resultDataGrid.DataSource = ds.Tables[ORDERS_TABLE].DefaultView;
	}	
}