using System;
using System.Configuration;

using System.Threading;

using System.Data;
using System.Data.SqlClient;

public class AsynchronousFillCancelForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";
	private const String ORDERDATE_FIELD	= "OrderDate";

	private Thread thread;

	private System.Windows.Forms.TextBox statusTextBox;
	private System.Windows.Forms.Button startButton;
	private System.Windows.Forms.Button cancelButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AsynchronousFillCancelForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.startButton = new System.Windows.Forms.Button();
		this.cancelButton = new System.Windows.Forms.Button();
		this.statusTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// startButton
		// 
		this.startButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.startButton.Location = new System.Drawing.Point(328, 232);
		this.startButton.Name = "startButton";
		this.startButton.TabIndex = 0;
		this.startButton.Text = "Start";
		this.startButton.Click += new System.EventHandler(this.startButton_Click);
		// 
		// cancelButton
		// 
		this.cancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.cancelButton.Location = new System.Drawing.Point(408, 232);
		this.cancelButton.Name = "cancelButton";
		this.cancelButton.TabIndex = 1;
		this.cancelButton.Text = "Cancel";
		this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
		// 
		// statusTextBox
		// 
		this.statusTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.statusTextBox.Location = new System.Drawing.Point(8, 8);
		this.statusTextBox.Multiline = true;
		this.statusTextBox.Name = "statusTextBox";
		this.statusTextBox.ReadOnly = true;
		this.statusTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.statusTextBox.Size = new System.Drawing.Size(476, 216);
		this.statusTextBox.TabIndex = 2;
		this.statusTextBox.TabStop = false;
		this.statusTextBox.Text = "";
		// 
		// AsynchronousFillCancelForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.statusTextBox);
		this.Controls.Add(this.cancelButton);
		this.Controls.Add(this.startButton);
		this.Name = "AsynchronousFillCancelForm";
		this.Text = "9.02 AsynchronousFillCancelForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void startButton_Click(object sender, System.EventArgs e)
	{
		// check if a new thread can be created
		if (thread == null ||
			(thread.ThreadState & (ThreadState.Unstarted | ThreadState.Background)) == 0)
		{
			// create and start a new thread to fill the DataSet
			thread = new Thread(new ThreadStart(AsyncFillDataSet));
			thread.IsBackground = true;
			thread.Start();
		}
		else
		{
			// DataSet already being filled � display a message
			statusTextBox.Text += "DataSet still filling ..." + Environment.NewLine;
			statusTextBox.Refresh();
		}
	}

	private void cancelButton_Click(object sender, System.EventArgs e)
	{
		// check if the thread is running and an abort has not been requested
		if (thread != null &&
			(thread.ThreadState & (ThreadState.Stopped | ThreadState.Aborted |
			ThreadState.Unstarted | ThreadState.AbortRequested)) == 0)
		{
			try
			{
				// abort the thread
				statusTextBox.Text += "Stopping thread ..." + Environment.NewLine;
				statusTextBox.Refresh();
				thread.Abort();
				thread.Join();
				statusTextBox.Text += "Thread stopped." + Environment.NewLine;
			}
			catch (Exception ex)
			{
				statusTextBox.Text += ex.Message + Environment.NewLine;
			}
		}
		else
		{
			statusTextBox.Text += "Nothing to stop." + Environment.NewLine;
		}
	}

	private void AsyncFillDataSet()
	{
		try
		{
			statusTextBox.Text = "Filling DataSet ..." + Environment.NewLine;
			statusTextBox.Refresh();

			DataSet ds = new DataSet("Source");
			
			SqlDataAdapter da;

			// fill the Order table and add it to the DataSet
			da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			DataTable orderTable = new DataTable(ORDERS_TABLE);
				da.FillSchema(orderTable, SchemaType.Source);
			da.Fill(orderTable);
			ds.Tables.Add(orderTable);

			// fill the OrderDetails table and add it to the DataSet
			da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			DataTable orderDetailTable = new DataTable(ORDERDETAILS_TABLE);
			da.FillSchema(orderDetailTable, SchemaType.Source);
			da.Fill(orderDetailTable);
			ds.Tables.Add(orderDetailTable);

			// create a relation between the tables
			ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
				ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
				ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
				true);

			statusTextBox.Text += "DataSet fill complete." + Environment.NewLine;
		}
		catch (ThreadAbortException ex)
		{
			// exception indicating that thread has been aborted
			statusTextBox.Text += "AsyncFillDataSet(): " + ex.Message + Environment.NewLine;
		}
	}
}