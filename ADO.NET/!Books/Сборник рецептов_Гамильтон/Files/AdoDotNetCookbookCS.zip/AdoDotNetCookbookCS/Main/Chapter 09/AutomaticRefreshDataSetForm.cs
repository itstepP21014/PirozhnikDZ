using System;
using System.Configuration;

using System.Threading;

using System.Data;
using System.Data.SqlClient;

public class AutomaticRefreshDataSetForm : System.Windows.Forms.Form
{
	private const String CATEGORIES_TABLE				= "Categories";

	private const int DATAREFRESH_SECONDS				= 15;
	private const int DATASETCHECKREFRESHINTERVAL_MS	= 1000;

	private DataTable dt, dtRefresh;
	private SqlDataAdapter da, daRefresh;

	private System.Threading.Timer timer;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button updateButton;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.DataGrid refreshDataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.IContainer components = null;

	public AutomaticRefreshDataSetForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.refreshDataGrid = new System.Windows.Forms.DataGrid();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.updateButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.refreshDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.CaptionText = "Edit Grid";
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 104);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 168);
		this.dataGrid.TabIndex = 0;
		// 
		// refreshDataGrid
		// 
		this.refreshDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.refreshDataGrid.CaptionText = "Timed Refresh Grid";
		this.refreshDataGrid.DataMember = "";
		this.refreshDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.refreshDataGrid.Location = new System.Drawing.Point(8, 288);
		this.refreshDataGrid.Name = "refreshDataGrid";
		this.refreshDataGrid.ReadOnly = true;
		this.refreshDataGrid.Size = new System.Drawing.Size(476, 168);
		this.refreshDataGrid.TabIndex = 3;
		// 
		// resultTextBox
		// 
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(376, 80);
		this.resultTextBox.TabIndex = 2;
		this.resultTextBox.Text = "";
		// 
		// updateButton
		// 
		this.updateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.updateButton.Location = new System.Drawing.Point(408, 8);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 1;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// AutomaticRefreshDataSetForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 466);
		this.Controls.Add(this.updateButton);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.refreshDataGrid);
		this.Controls.Add(this.dataGrid);
		this.Name = "AutomaticRefreshDataSetForm";
		this.Text = "9.14 AutomaticRefreshDataSetForm";
		this.Load += new System.EventHandler(this.AutomaticRefreshDataSetForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.refreshDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void AutomaticRefreshDataSetForm_Load(object sender, System.EventArgs e)
	{
		String sqlText = "SELECT CategoryID, CategoryName, Description FROM Categories";

		// fill the categories table for editing
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommandBuilder cd = new SqlCommandBuilder(da);
		dt = new DataTable(CATEGORIES_TABLE);
		da.FillSchema(dt, SchemaType.Source);
		da.Fill(dt);

		// bind the default view of the table to the grid
		dataGrid.DataSource = dt.DefaultView;

		// fill the auto-refresh categories table
		daRefresh = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		dtRefresh = new DataTable(CATEGORIES_TABLE);
		daRefresh.FillSchema(dtRefresh, SchemaType.Source);
		daRefresh.Fill(dtRefresh);

		// bind the default view of the table to the grid
		refreshDataGrid.DataSource = dtRefresh.DefaultView;

		// set the refresh time for the data
		dtRefresh.ExtendedProperties["RefreshTime"] = DateTime.Now.AddSeconds(DATAREFRESH_SECONDS).ToString();
		// start the timer
		timer = new System.Threading.Timer(new TimerCallback(CheckRefreshDatabase), null, DATASETCHECKREFRESHINTERVAL_MS, DATASETCHECKREFRESHINTERVAL_MS);
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		// update the categories edited to the data source
		da.Update(dt);
	}

	private void CheckRefreshDatabase(Object state)
	{
		DateTime now = DateTime.Now;
		// check if the specified number of seconds have elapsed
		if (Convert.ToDateTime(dtRefresh.ExtendedProperties["RefreshTime"].ToString()) < now)
		{
			// refresh the table
			daRefresh.Fill(dtRefresh);
			// update the next refresh time
			dtRefresh.ExtendedProperties["RefreshTime"] = now.AddSeconds(DATAREFRESH_SECONDS).ToString();

			resultTextBox.Text = "Table refreshed (" + now.ToString("T") +
				")" + Environment.NewLine + resultTextBox.Text;
		}
	}
}