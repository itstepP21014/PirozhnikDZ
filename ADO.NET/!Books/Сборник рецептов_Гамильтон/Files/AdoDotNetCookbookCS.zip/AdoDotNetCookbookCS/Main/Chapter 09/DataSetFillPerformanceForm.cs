using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class DataSetFillPerformanceForm : System.Windows.Forms.Form
{
	// table name constants
	public const String ORDERS_TABLE				= "Orders";
	public const String ORDERDETAILS_TABLE			= "OrderDetails";

	// field name constants for Orders table
	public const String ORDERID_FIELD				= "OrderID";
	public const String CUSTOMERID_FIELD			= "CustomerID";
	public const String EMPLOYEEID_FIELD			= "EmployeeID";
	public const String ORDERDATE_FIELD				= "OrderDate";
	public const String REQUIREDDATE_FIELD			= "RequiredDate";
	public const String SHIPPEDDDATE_FIELD			= "ShippedDate";
	public const String SHIPVIA_FIELD				= "ShipVia";
	public const String FREIGHT_FIELD				= "Freight";
	public const String SHIPNAME_FIELD				= "ShipName";
	public const String SHIPADDRESS_FIELD			= "ShipAddress";
	public const String SHIPCITY_FIELD				= "ShipCity";
	public const String SHIPREGION_FIELD			= "ShipRegion";
	public const String SHIPPOSTALCODE_FIELD		= "ShipPostalCode";
	public const String SHIPCOUNTRY_FIELD			= "ShipCountry";

	// field name constants for OrderDetails table
	public const String PRODUCTID_FIELD				= "ProductID";
	public const String UNITPRICE_FIELD				= "UnitPrice";
	public const String QUANTITY_FIELD				= "Quantity";
	public const String DISCOUNT_FIELD				= "Discount";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	private System.Windows.Forms.Button buttonGo;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.CheckBox enforceConstraintsOffCheckBox;
	private System.Windows.Forms.CheckBox loadDataCheckBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DataSetFillPerformanceForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.buttonGo = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.enforceConstraintsOffCheckBox = new System.Windows.Forms.CheckBox();
		this.loadDataCheckBox = new System.Windows.Forms.CheckBox();
		this.SuspendLayout();
		// 
		// buttonGo
		// 
		this.buttonGo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.buttonGo.Location = new System.Drawing.Point(408, 8);
		this.buttonGo.Name = "buttonGo";
		this.buttonGo.TabIndex = 0;
		this.buttonGo.Text = "Go";
		this.buttonGo.Click += new System.EventHandler(this.buttonGo_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 40);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// enforceConstraintsOffCheckBox
		// 
		this.enforceConstraintsOffCheckBox.Location = new System.Drawing.Point(8, 8);
		this.enforceConstraintsOffCheckBox.Name = "enforceConstraintsOffCheckBox";
		this.enforceConstraintsOffCheckBox.Size = new System.Drawing.Size(144, 24);
		this.enforceConstraintsOffCheckBox.TabIndex = 2;
		this.enforceConstraintsOffCheckBox.Text = "EnforceConstraints off";
		// 
		// loadDataCheckBox
		// 
		this.loadDataCheckBox.Location = new System.Drawing.Point(168, 8);
		this.loadDataCheckBox.Name = "loadDataCheckBox";
		this.loadDataCheckBox.Size = new System.Drawing.Size(184, 24);
		this.loadDataCheckBox.TabIndex = 3;
		this.loadDataCheckBox.Text = "BeginLoadData / EndLoadData";
		// 
		// DataSetFillPerformanceForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.loadDataCheckBox);
		this.Controls.Add(this.enforceConstraintsOffCheckBox);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.buttonGo);
		this.Name = "DataSetFillPerformanceForm";
		this.Text = "9.09 DataSetFillPerformanceForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void buttonGo_Click(object sender, System.EventArgs e)
	{
		Cursor.Current = Cursors.WaitCursor;

		int startTick = 0;
		int totalTick = 0;

		for(int i = 0; i <= 10; i++)
		{
			// create and fill the DataSet counting elapsed ticks
			DataSet ds = CreateDataSet();

			if (enforceConstraintsOffCheckBox.Checked)
				ds.EnforceConstraints = false;
			
			SqlDataAdapter da;

			// fill the Order table in the DataSet
			da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			if (loadDataCheckBox.Checked)
				ds.Tables[ORDERS_TABLE].BeginLoadData();

			startTick = Environment.TickCount;
			da.Fill(ds, ORDERS_TABLE);
			totalTick += Environment.TickCount - startTick;

			if (loadDataCheckBox.Checked)
				ds.Tables[ORDERS_TABLE].EndLoadData();

			// fill the OrderDetails table in the DataSet
			da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			if (loadDataCheckBox.Checked)
				ds.Tables[ORDERDETAILS_TABLE].BeginLoadData();

			startTick = Environment.TickCount;
			da.Fill(ds, ORDERDETAILS_TABLE);
			totalTick += Environment.TickCount - startTick;

			if (loadDataCheckBox.Checked)
				ds.Tables[ORDERDETAILS_TABLE].EndLoadData();

			if (enforceConstraintsOffCheckBox.Checked)
				ds.EnforceConstraints = true;
		}

		resultTextBox.Text +=
			"Ticks = " + totalTick + "; " +
			"Enforce constraints = " + !enforceConstraintsOffCheckBox.Checked + "; " +
			"BeginLoadData/EndLoadData = " + loadDataCheckBox.Checked + 
			Environment.NewLine;

		Cursor.Current = Cursors.Default;
	}

	private DataSet CreateDataSet()
	{
		DataSet ds = new DataSet();

		// create the Orders table
		DataTable dtOrders = new DataTable(ORDERS_TABLE);
		DataColumnCollection cols = dtOrders.Columns;

		// add the identity field
		DataColumn col = cols.Add(ORDERID_FIELD, typeof(System.Int32));            
		col.AllowDBNull = false;
		col.AutoIncrement = true;
		col.AutoIncrementSeed = -1;
		col.AutoIncrementStep = -1;
		// add the other fields
		cols.Add(CUSTOMERID_FIELD, typeof(System.String)).MaxLength=5;  
		cols.Add(EMPLOYEEID_FIELD, typeof(System.Int32));  
		cols.Add(ORDERDATE_FIELD, typeof(System.DateTime));  
		cols.Add(REQUIREDDATE_FIELD, typeof(System.DateTime));  
		cols.Add(SHIPPEDDDATE_FIELD, typeof(System.DateTime));  
		cols.Add(SHIPVIA_FIELD, typeof(System.Int32));  
		cols.Add(FREIGHT_FIELD, typeof(System.Decimal));  
		cols.Add(SHIPNAME_FIELD, typeof(System.String)).MaxLength = 40;  
		cols.Add(SHIPADDRESS_FIELD, typeof(System.String)).MaxLength = 60;  
		cols.Add(SHIPCITY_FIELD, typeof(System.String)).MaxLength = 15;  
		cols.Add(SHIPREGION_FIELD, typeof(System.String)).MaxLength = 15;  
		cols.Add(SHIPPOSTALCODE_FIELD, typeof(System.String)).MaxLength = 10;  
		cols.Add(SHIPCOUNTRY_FIELD, typeof(System.String)).MaxLength = 15;  
		// set the primary key
		dtOrders.PrimaryKey = new DataColumn[] {cols[ORDERID_FIELD]};
		// add the Orders table to the DataSet
		ds.Tables.Add(dtOrders);

		// create the OrderDetails table
		DataTable dtOrderDetails = new DataTable(ORDERDETAILS_TABLE);
		cols = dtOrderDetails.Columns;

		// add the PK fields
		cols.Add(ORDERID_FIELD, typeof(System.Int32)).AllowDBNull = false;  
		cols.Add(PRODUCTID_FIELD, typeof(System.Int32)).AllowDBNull = false;
		// add the other fields
		cols.Add(UNITPRICE_FIELD, typeof(System.Decimal)).AllowDBNull = false;  
		cols.Add(QUANTITY_FIELD, typeof(System.Int16)).AllowDBNull = false;  
		cols.Add(DISCOUNT_FIELD, typeof(System.Single)).AllowDBNull = false;  
		//set the primary key
		dtOrderDetails.PrimaryKey = new DataColumn[]
			{
				cols[ORDERID_FIELD],
				cols[PRODUCTID_FIELD]
			};
		// add the OrderDetails table to the DataSet
		ds.Tables.Add(dtOrderDetails);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			dtOrders.Columns[ORDERID_FIELD],
			dtOrderDetails.Columns[ORDERID_FIELD],
			true);

		return ds;
	}
}