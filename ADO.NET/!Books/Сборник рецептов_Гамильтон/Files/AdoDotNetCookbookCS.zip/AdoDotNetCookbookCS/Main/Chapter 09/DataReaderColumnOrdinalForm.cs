using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class DataReaderColumnOrdinalForm : System.Windows.Forms.Form
{
	private int co_OrderId;
	private int co_CustomerId;
	private int co_EmployeeId;
	private int co_OrderDate;
	private int co_RequiredDate;
	private int co_ShippedDate;
	private int co_ShipVia;
	private int co_Freight;
	private int co_ShipName;
	private int co_ShipAddress;
	private int co_ShipCity;
	private int co_ShipRegion;
	private int co_ShipPostalCode;
	private int co_ShipCountry;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button goButton;


	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DataReaderColumnOrdinalForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.goButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 0;
		this.resultTextBox.Text = "";
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 1;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// DataReaderColumnOrdinalForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.goButton,
																		this.resultTextBox});
		this.Name = "DataReaderColumnOrdinalForm";
		this.Text = "9.07 DataReaderColumnOrdinalForm";
		this.Load += new System.EventHandler(this.DataReaderColumnOrdinalForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void DataReaderColumnOrdinalForm_Load(object sender, System.EventArgs e)
	{
		String sqlText = "SELECT * FROM Orders";

		// create the connection and command
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		conn.Open();

		// create the DataReader to retrieve ordinals
		SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SchemaOnly);

		// retrieve the column ordinals for each field
		co_OrderId = dr.GetOrdinal("OrderID");
		co_CustomerId = dr.GetOrdinal("CustomerID");
		co_EmployeeId = dr.GetOrdinal("EmployeeID");
		co_OrderDate = dr.GetOrdinal("OrderDate");
		co_RequiredDate = dr.GetOrdinal("RequiredDate");
		co_ShippedDate = dr.GetOrdinal("ShippedDate");
		co_ShipVia = dr.GetOrdinal("ShipVia");
		co_Freight = dr.GetOrdinal("Freight");
		co_ShipName = dr.GetOrdinal("ShipName");
		co_ShipAddress = dr.GetOrdinal("ShipAddress");
		co_ShipCity = dr.GetOrdinal("ShipCity");
		co_ShipRegion = dr.GetOrdinal("ShipRegion");
		co_ShipPostalCode = dr.GetOrdinal("ShipPostalCode");
		co_ShipCountry = dr.GetOrdinal("ShipCountry");

		// close the DataReader and connection
		dr.Close();
		conn.Close();
	}

	private void goButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder sb = new StringBuilder();

		String sqlText = "SELECT TOP 5 * FROM Orders";

		// create the connection and command
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		conn.Open();
		
		// create the DataReader to retrieve data
		SqlDataReader dr = cmd.ExecuteReader();

		// iterate over the records in the DataReader
		while(dr.Read())
		{
			// access the fields based on their column ordinals
			sb.Append(
				// index-based access
				"OrderID: " + dr[co_OrderId] + Environment.NewLine +
				// non-specific accessor
				"CustomerID: " + dr.GetString(co_CustomerId) + Environment.NewLine +
				// provider-specific accessor
				"OrderDate: " + dr.GetSqlDateTime(co_OrderDate) + Environment.NewLine +
				// non-specific accessor with NULL
				"ShipRegion (non-specific): " + (dr.IsDBNull(co_ShipRegion) ? "null" : dr.GetString(co_ShipRegion)).ToString() + Environment.NewLine +
				// provider-specific accessor with NULL
				"ShipRegion (Sql-specific): " + (dr.GetSqlString(co_ShipRegion).IsNull ? "null" :
				dr.GetSqlString(co_ShipRegion)).ToString() + Environment.NewLine + Environment.NewLine);
		}

		// close the DataReader and connection
		dr.Close();
		conn.Close();

		resultTextBox.Text = sb.ToString();
	}
}