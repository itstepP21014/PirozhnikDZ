using System;
using System.Configuration;
using System.Drawing;
using System.Windows.Forms;
using System.Text;
using System.IO;

using System.Data;
using System.Data.OracleClient;

public class ReadWriteBinaryDataFromOracleForm : System.Windows.Forms.Form
{
	private OpenFileDialog ofd;

	private const String TABLENAME			= "TBL0912";

	private const String ID_FIELD			= "ID";
	private const String BLOBFIELD_FIELD	= "BLOBFIELD";
	private const String CLOBFIELD_FIELD	= "CLOBFIELD";
	private const String NCLOBFIELD_FIELD	= "NCLOBFIELD";

	private System.Windows.Forms.TextBox idTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Button readButton;
	private System.Windows.Forms.Button writeButton;
	private System.Windows.Forms.PictureBox blobPictureBox;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.Label label4;
	private System.Windows.Forms.TextBox clobTextBox;
	private System.Windows.Forms.TextBox nclobTextBox;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ReadWriteBinaryDataFromOracleForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		ofd = new OpenFileDialog();
		ofd.InitialDirectory=System.IO.Path.GetTempPath();
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.idTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.readButton = new System.Windows.Forms.Button();
		this.writeButton = new System.Windows.Forms.Button();
		this.blobPictureBox = new System.Windows.Forms.PictureBox();
		this.label2 = new System.Windows.Forms.Label();
		this.clobTextBox = new System.Windows.Forms.TextBox();
		this.nclobTextBox = new System.Windows.Forms.TextBox();
		this.label3 = new System.Windows.Forms.Label();
		this.label4 = new System.Windows.Forms.Label();
		this.SuspendLayout();
		// 
		// idTextBox
		// 
		this.idTextBox.Location = new System.Drawing.Point(32, 8);
		this.idTextBox.Name = "idTextBox";
		this.idTextBox.TabIndex = 0;
		this.idTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(24, 23);
		this.label1.TabIndex = 1;
		this.label1.Text = "ID:";
		// 
		// readButton
		// 
		this.readButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.readButton.Location = new System.Drawing.Point(408, 8);
		this.readButton.Name = "readButton";
		this.readButton.TabIndex = 2;
		this.readButton.Text = "Read";
		this.readButton.Click += new System.EventHandler(this.readButton_Click);
		// 
		// writeButton
		// 
		this.writeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.writeButton.Location = new System.Drawing.Point(408, 40);
		this.writeButton.Name = "writeButton";
		this.writeButton.TabIndex = 3;
		this.writeButton.Text = "Write";
		this.writeButton.Click += new System.EventHandler(this.writeButton_Click);
		// 
		// blobPictureBox
		// 
		this.blobPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
		this.blobPictureBox.Location = new System.Drawing.Point(8, 104);
		this.blobPictureBox.Name = "blobPictureBox";
		this.blobPictureBox.Size = new System.Drawing.Size(150, 150);
		this.blobPictureBox.TabIndex = 4;
		this.blobPictureBox.TabStop = false;
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 88);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(100, 16);
		this.label2.TabIndex = 5;
		this.label2.Text = "BLOB:";
		// 
		// clobTextBox
		// 
		this.clobTextBox.Location = new System.Drawing.Point(176, 104);
		this.clobTextBox.Multiline = true;
		this.clobTextBox.Name = "clobTextBox";
		this.clobTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.clobTextBox.Size = new System.Drawing.Size(308, 64);
		this.clobTextBox.TabIndex = 6;
		this.clobTextBox.Text = "";
		// 
		// nclobTextBox
		// 
		this.nclobTextBox.Location = new System.Drawing.Point(176, 192);
		this.nclobTextBox.Multiline = true;
		this.nclobTextBox.Name = "nclobTextBox";
		this.nclobTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.nclobTextBox.Size = new System.Drawing.Size(308, 64);
		this.nclobTextBox.TabIndex = 7;
		this.nclobTextBox.Text = "";
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(176, 88);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(100, 16);
		this.label3.TabIndex = 8;
		this.label3.Text = "CLOB:";
		// 
		// label4
		// 
		this.label4.Location = new System.Drawing.Point(176, 176);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(100, 16);
		this.label4.TabIndex = 9;
		this.label4.Text = "NCLOB:";
		// 
		// ReadWriteBinaryDataFromOracleForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.label4);
		this.Controls.Add(this.label3);
		this.Controls.Add(this.nclobTextBox);
		this.Controls.Add(this.clobTextBox);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.blobPictureBox);
		this.Controls.Add(this.writeButton);
		this.Controls.Add(this.readButton);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.idTextBox);
		this.Name = "ReadWriteBinaryDataFromOracleForm";
		this.Text = "9.12 ReadWriteBinaryDataFromOracleForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void readButton_Click(object sender, System.EventArgs e)
	{
		// clear the controls
		blobPictureBox.Image = null;
		clobTextBox.Clear();
		nclobTextBox.Clear();

		String sqlText = "SELECT * FROM " + TABLENAME + " WHERE ID = " + idTextBox.Text;

		// create the connection and command
		OracleConnection conn = new OracleConnection(ConfigurationSettings.AppSettings["Oracle_ConnectString"]);
		OracleCommand cmd = new OracleCommand(sqlText, conn);
		conn.Open();
		
		// create the DataReader
		OracleDataReader dr = cmd.ExecuteReader();
		// iterate over the collection of rows in the DataReader
		if(dr.Read())
		{
			// retrieve the BLOB into a stream
			Byte[] blob = null;
			if(!dr.IsDBNull(1))
				blob = (Byte[])dr.GetOracleLob(1).Value;
			MemoryStream ms = new MemoryStream(blob);
			// display the BLOB in the PictureBox
			blobPictureBox.Image = Image.FromStream(ms);
			ms.Close();

			// get the CLOB
			if(!dr.IsDBNull(2))
				clobTextBox.Text = dr.GetOracleLob(2).Value.ToString();

			// get the NCLOB
			if(!dr.IsDBNull(3))
				nclobTextBox.Text = dr.GetOracleLob(3).Value.ToString();
		}
		else
		{
			MessageBox.Show("No record found.", "Access Oracle LOB Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}

		dr.Close();
		conn.Close();
	}

	private void writeButton_Click(object sender, System.EventArgs e)
	{
		// get the user supplied ID
		int id;
		try
		{
			id = Convert.ToInt32(idTextBox.Text);
		}
		catch(System.Exception ex)
		{
			MessageBox.Show(ex.Message, "Access Oracle LOB Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			return;
		}

		// save the BLOB, CLOB, and NCLOB
		if (ofd.ShowDialog() == DialogResult.OK)
		{
			// get a BLOB from a user specified file
			FileStream fs = new FileStream(ofd.FileName, FileMode.OpenOrCreate, FileAccess.Read);
			Byte[] blob = new Byte[fs.Length];
			fs.Read(blob, 0, blob.Length);
			fs.Close();

			// create a DataAdapter and table
			OracleDataAdapter da = new OracleDataAdapter("SELECT * FROM " + TABLENAME, ConfigurationSettings.AppSettings["Oracle_ConnectString"]);
			DataTable table = new DataTable();
			// just get the schema
			da.FillSchema(table, SchemaType.Source);
			OracleCommandBuilder cb = new OracleCommandBuilder(da);

			// create a row containing the new BLOB, CLOB, and NCLOB data
			DataRow row = table.NewRow();
			row[ID_FIELD] = id;
			row[BLOBFIELD_FIELD] = blob;
			if(clobTextBox.TextLength > 0)
				row[CLOBFIELD_FIELD] = clobTextBox.Text;
			if(nclobTextBox.TextLength > 0)
				row[NCLOBFIELD_FIELD] = nclobTextBox.Text;
			// add the row to the table
			table.Rows.Add(row);

			// update the Oracle database using the DataAdapter
			try
			{
				da.Update(table);
			}
			catch(System.Exception ex)
			{
				MessageBox.Show(ex.Message, "Access Oracle LOB Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}

			MessageBox.Show("Record successfully created.", "Access Oracle LOB Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
	}
}