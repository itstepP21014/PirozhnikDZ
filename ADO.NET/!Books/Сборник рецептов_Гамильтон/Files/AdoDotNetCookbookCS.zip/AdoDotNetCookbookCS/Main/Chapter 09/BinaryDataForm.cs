using System;
using System.Configuration;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

using System.Data;
using System.Data.SqlClient;

public class BinaryDataForm : System.Windows.Forms.Form
{
	private const String TABLENAME = "TBL0911";

	private DataSet ds;
	private SqlDataAdapter da;

	private BindingManagerBase bm;
	private Byte[] image;

	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.Button updateButton;
	private System.Windows.Forms.Button moveLastButton;
	private System.Windows.Forms.Button moveNextButton;
	private System.Windows.Forms.Button movePreviousButton;
	private System.Windows.Forms.Button moveFirstButton;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox descriptionTextBox;
	private System.Windows.Forms.TextBox idTextBox;
	private System.Windows.Forms.Button selectImageButton;
	private System.Windows.Forms.PictureBox imagePictureBox;
	private System.Windows.Forms.Button clearImageButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public BinaryDataForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.label3 = new System.Windows.Forms.Label();
		this.updateButton = new System.Windows.Forms.Button();
		this.moveLastButton = new System.Windows.Forms.Button();
		this.moveNextButton = new System.Windows.Forms.Button();
		this.movePreviousButton = new System.Windows.Forms.Button();
		this.moveFirstButton = new System.Windows.Forms.Button();
		this.label1 = new System.Windows.Forms.Label();
		this.descriptionTextBox = new System.Windows.Forms.TextBox();
		this.idTextBox = new System.Windows.Forms.TextBox();
		this.imagePictureBox = new System.Windows.Forms.PictureBox();
		this.selectImageButton = new System.Windows.Forms.Button();
		this.clearImageButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(8, 32);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(88, 23);
		this.label3.TabIndex = 33;
		this.label3.Text = "Description:";
		// 
		// updateButton
		// 
		this.updateButton.Location = new System.Drawing.Point(184, 184);
		this.updateButton.Name = "updateButton";
		this.updateButton.Size = new System.Drawing.Size(80, 23);
		this.updateButton.TabIndex = 3;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// moveLastButton
		// 
		this.moveLastButton.Location = new System.Drawing.Point(128, 184);
		this.moveLastButton.Name = "moveLastButton";
		this.moveLastButton.Size = new System.Drawing.Size(32, 23);
		this.moveLastButton.TabIndex = 7;
		this.moveLastButton.Text = ">>";
		this.moveLastButton.Click += new System.EventHandler(this.moveLastButton_Click);
		// 
		// moveNextButton
		// 
		this.moveNextButton.Location = new System.Drawing.Point(88, 184);
		this.moveNextButton.Name = "moveNextButton";
		this.moveNextButton.Size = new System.Drawing.Size(32, 23);
		this.moveNextButton.TabIndex = 6;
		this.moveNextButton.Text = ">";
		this.moveNextButton.Click += new System.EventHandler(this.moveNextButton_Click);
		// 
		// movePreviousButton
		// 
		this.movePreviousButton.Location = new System.Drawing.Point(48, 184);
		this.movePreviousButton.Name = "movePreviousButton";
		this.movePreviousButton.Size = new System.Drawing.Size(32, 23);
		this.movePreviousButton.TabIndex = 5;
		this.movePreviousButton.Text = "<";
		this.movePreviousButton.Click += new System.EventHandler(this.movePreviousButton_Click);
		// 
		// moveFirstButton
		// 
		this.moveFirstButton.Location = new System.Drawing.Point(8, 184);
		this.moveFirstButton.Name = "moveFirstButton";
		this.moveFirstButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
		this.moveFirstButton.Size = new System.Drawing.Size(32, 23);
		this.moveFirstButton.TabIndex = 4;
		this.moveFirstButton.Text = ">>";
		this.moveFirstButton.Click += new System.EventHandler(this.moveFirstButton_Click);
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(88, 23);
		this.label1.TabIndex = 27;
		this.label1.Text = "ID:";
		// 
		// descriptionTextBox
		// 
		this.descriptionTextBox.Location = new System.Drawing.Point(104, 32);
		this.descriptionTextBox.Name = "descriptionTextBox";
		this.descriptionTextBox.Size = new System.Drawing.Size(160, 20);
		this.descriptionTextBox.TabIndex = 0;
		this.descriptionTextBox.Text = "";
		// 
		// idTextBox
		// 
		this.idTextBox.Location = new System.Drawing.Point(104, 8);
		this.idTextBox.Name = "idTextBox";
		this.idTextBox.ReadOnly = true;
		this.idTextBox.TabIndex = 25;
		this.idTextBox.Text = "";
		// 
		// imagePictureBox
		// 
		this.imagePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
		this.imagePictureBox.Location = new System.Drawing.Point(280, 8);
		this.imagePictureBox.Name = "imagePictureBox";
		this.imagePictureBox.Size = new System.Drawing.Size(200, 200);
		this.imagePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
		this.imagePictureBox.TabIndex = 34;
		this.imagePictureBox.TabStop = false;
		// 
		// selectImageButton
		// 
		this.selectImageButton.Location = new System.Drawing.Point(184, 80);
		this.selectImageButton.Name = "selectImageButton";
		this.selectImageButton.Size = new System.Drawing.Size(80, 23);
		this.selectImageButton.TabIndex = 1;
		this.selectImageButton.Text = "Select Image";
		this.selectImageButton.Click += new System.EventHandler(this.selectImageButton_Click);
		// 
		// clearImageButton
		// 
		this.clearImageButton.Location = new System.Drawing.Point(184, 112);
		this.clearImageButton.Name = "clearImageButton";
		this.clearImageButton.Size = new System.Drawing.Size(80, 23);
		this.clearImageButton.TabIndex = 2;
		this.clearImageButton.Text = "Clear Image";
		this.clearImageButton.Click += new System.EventHandler(this.clearImageButton_Click);
		// 
		// BinaryDataForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(488, 214);
		this.Controls.Add(this.clearImageButton);
		this.Controls.Add(this.selectImageButton);
		this.Controls.Add(this.imagePictureBox);
		this.Controls.Add(this.label3);
		this.Controls.Add(this.updateButton);
		this.Controls.Add(this.moveLastButton);
		this.Controls.Add(this.moveNextButton);
		this.Controls.Add(this.movePreviousButton);
		this.Controls.Add(this.moveFirstButton);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.descriptionTextBox);
		this.Controls.Add(this.idTextBox);
		this.Name = "BinaryDataForm";
		this.Text = "9.11 BinaryDataForm";
		this.Load += new System.EventHandler(this.BinaryDataForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void BinaryDataForm_Load(object sender, System.EventArgs e)
	{
		// create the DataSet
		ds = new DataSet();

		// define select and update commands for the DataAdapter
		String selectCommand = "SELECT Id, Description FROM " + TABLENAME;
		String updateCommand = "UPDATE " + TABLENAME + " " +
			"SET Description = @Description " +
			"WHERE Id = @Id";

		// create the DataAdapter
		da = new SqlDataAdapter(selectCommand, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.UpdateCommand = new SqlCommand(updateCommand, da.SelectCommand.Connection);
		da.UpdateCommand.CommandType = CommandType.Text;
		da.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		da.UpdateCommand.Parameters.Add("@Description", SqlDbType.NVarChar, 50, "Description");
		// fill the schema and the data from the table
		da.FillSchema(ds, SchemaType.Source, TABLENAME);
		da.Fill(ds, TABLENAME);

		// bind all of the controls to the DataSet
		idTextBox.DataBindings.Add("Text", ds, TABLENAME + ".Id");
		descriptionTextBox.DataBindings.Add("Text", ds, TABLENAME +  ".Description");

		// get the binding manager base for the parent table
		bm = BindingContext[ds, TABLENAME];
		// handler to update the correct image in response to
		// each record reposition
		bm.PositionChanged += new EventHandler(bm_PositionChanged);
		// update the display for the first record
		bm_PositionChanged(null, null);	
	}

	private void bm_PositionChanged(Object sender, EventArgs e)
	{
		// handler for the binding manager record change

		// clear the image and picture box
		image = null;
		imagePictureBox.Image = null;

		// get the ID for the record from the binding manager
		int Id = (int)ds.Tables[TABLENAME].Rows[bm.Position]["ID"];

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// create the command to retrieve the image from the database
		String sqlText = "SELECT BlobData FROM " + TABLENAME + " WHERE Id = " + Id;
		SqlCommand cmd = new SqlCommand(sqlText, conn);

		// retrieve the image to a stream
		conn.Open();
		try
		{
			int bufferSize = 100;
			byte[] outbyte = new byte[bufferSize];
			long retVal = 0;
			long startIndex = 0;

			SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SequentialAccess);
			dr.Read();

			// check to see if the field is DBNull
			if (!dr.IsDBNull(0))
			{
				// create the memory stream to hold the output
				MemoryStream ms = new MemoryStream();

				// read the bytes into outbyte
				retVal = dr.GetBytes(0, startIndex, outbyte, 0, bufferSize);

				// keep reading while there are more bytes beyond the buffer
				while (retVal == bufferSize)
				{
					// write the bytes to the memory stream
					ms.Write(outbyte, 0, outbyte.Length);

					// update the start index and fill the buffer again
					startIndex += bufferSize;
					retVal = dr.GetBytes(0, startIndex, outbyte, 0, bufferSize);
				}

				// write the bytes remaining in the buffer
				ms.Write(outbyte, 0, (int)retVal - 1);
				// transfer the memory stream to the image
				image = ms.ToArray();
			}
		}
		catch (System.InvalidCastException)
		{
			// image is null or invalid in the database - ignore
		}
		finally
		{
			conn.Close();
		}

		if (image != null)
		{
			// load the image into a stream
			MemoryStream ms = new MemoryStream(image);
			try
			{
				// set the PictureBox image to the value of the stream
				imagePictureBox.Image = Image.FromStream(ms);
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}

			// close the stream
			ms.Close();
		}
	}

	private void selectImageButton_Click(object sender, System.EventArgs e)
	{
		// create the file dialog to select image
		OpenFileDialog ofd = new OpenFileDialog();
		ofd.InitialDirectory = System.IO.Path.GetTempPath();
		ofd.Filter = "Bitmap Files (*.bmp)|*.bmp|JPEG files (*.jpg)|*.jpg|All files (*.*)|*.*";
		ofd.FilterIndex = 2;

		if (ofd.ShowDialog() == DialogResult.OK)
		{
			//read image into file stream, and from there into Byte array.
			FileStream fs =  new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read);
			image = new Byte[fs.Length];
			fs.Read(image, 0, image.Length);
			try
			{
				// set the PictureBox image from the stream
				imagePictureBox.Image = Image.FromStream(fs);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
				image = null;
			}
			fs.Close();
		}
	}

	private void clearImageButton_Click(object sender, System.EventArgs e)
	{
		// clear the image and picture box
		image = null;
		imagePictureBox.Image = null;
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		// update the data and image to the database

		// get the ID for the record from the binding manager
		int Id = (int)ds.Tables[TABLENAME].Rows[bm.Position]["ID"];
		String sqlWrite = "UPDATE " + TABLENAME + " SET BlobData = @BlobData WHERE ID = " + Id;

		// create the connection and command
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmdWrite = new SqlCommand(sqlWrite, conn);

		// create parameter for insert command
		SqlParameter prm;
		if(image != null)
		{
			// add a parameter for the image binary data
			prm = new  SqlParameter("@BlobData", SqlDbType.VarBinary, image.Length, ParameterDirection.Input, false, 
				0, 0, null, DataRowVersion.Current, image);
		}
		else
		{
			// add a parameter for a null image
			prm = new  SqlParameter("@BlobData", SqlDbType.VarBinary, 0, ParameterDirection.Input, false, 
				0, 0, null, DataRowVersion.Current, System.DBNull.Value);
		}

		// add the parameter to the command
		cmdWrite.Parameters.Add(prm);

		// execute the command to update the image in the database
		conn.Open();
		cmdWrite.ExecuteNonQuery();
		conn.Close();
		
		// end the binding manager edit
		bm.EndCurrentEdit();
		// use the DataAdapter to update the table data
		da.Update(ds.Tables[TABLENAME]);
	}

	private void moveFirstButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = 0;
	}

	private void movePreviousButton_Click(object sender, System.EventArgs e)
	{
		bm.Position -= 1;
	}

	private void moveNextButton_Click(object sender, System.EventArgs e)
	{
		bm.Position += 1;
	}

	private void moveLastButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = bm.Count - 1;
	}
}