using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class ImprovePagingPerformanceForm : System.Windows.Forms.Form
{
	private SqlDataAdapter da;
	private DataTable table;

	// stored procedure name constants
	public const String PAGING_SP		= "SP0904_PageOrders";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";

	private int currentPage;
	private int firstOrderId;
	private int lastOrderId;

	private System.Windows.Forms.Button previousButton;
	private System.Windows.Forms.Button nextButton;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button firstButton;
	private System.Windows.Forms.Button lastButton;
	private System.Windows.Forms.TextBox gotoPageTextBox;
	private System.Windows.Forms.Button gotoPageButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ImprovePagingPerformanceForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.previousButton = new System.Windows.Forms.Button();
		this.nextButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.firstButton = new System.Windows.Forms.Button();
		this.lastButton = new System.Windows.Forms.Button();
		this.gotoPageTextBox = new System.Windows.Forms.TextBox();
		this.gotoPageButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// previousButton
		// 
		this.previousButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
		this.previousButton.Location = new System.Drawing.Point(64, 332);
		this.previousButton.Name = "previousButton";
		this.previousButton.Size = new System.Drawing.Size(48, 23);
		this.previousButton.TabIndex = 0;
		this.previousButton.Text = "<";
		this.previousButton.Click += new System.EventHandler(this.previousButton_Click);
		// 
		// nextButton
		// 
		this.nextButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
		this.nextButton.Location = new System.Drawing.Point(120, 332);
		this.nextButton.Name = "nextButton";
		this.nextButton.Size = new System.Drawing.Size(48, 23);
		this.nextButton.TabIndex = 1;
		this.nextButton.Text = ">";
		this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(476, 316);
		this.dataGrid.TabIndex = 2;
		// 
		// firstButton
		// 
		this.firstButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
		this.firstButton.Location = new System.Drawing.Point(8, 332);
		this.firstButton.Name = "firstButton";
		this.firstButton.Size = new System.Drawing.Size(48, 23);
		this.firstButton.TabIndex = 3;
		this.firstButton.Text = "<<";
		this.firstButton.Click += new System.EventHandler(this.firstButton_Click);
		// 
		// lastButton
		// 
		this.lastButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
		this.lastButton.Location = new System.Drawing.Point(176, 332);
		this.lastButton.Name = "lastButton";
		this.lastButton.Size = new System.Drawing.Size(48, 23);
		this.lastButton.TabIndex = 4;
		this.lastButton.Text = ">>";
		this.lastButton.Click += new System.EventHandler(this.lastButton_Click);
		// 
		// gotoPageTextBox
		// 
		this.gotoPageTextBox.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
		this.gotoPageTextBox.Location = new System.Drawing.Point(344, 332);
		this.gotoPageTextBox.Name = "gotoPageTextBox";
		this.gotoPageTextBox.Size = new System.Drawing.Size(72, 20);
		this.gotoPageTextBox.TabIndex = 6;
		this.gotoPageTextBox.Text = "";
		// 
		// gotoPageButton
		// 
		this.gotoPageButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
		this.gotoPageButton.Location = new System.Drawing.Point(264, 332);
		this.gotoPageButton.Name = "gotoPageButton";
		this.gotoPageButton.Size = new System.Drawing.Size(72, 23);
		this.gotoPageButton.TabIndex = 7;
		this.gotoPageButton.Text = "Goto Page";
		this.gotoPageButton.Click += new System.EventHandler(this.gotoPageButton_Click);
		// 
		// ImprovePagingPerformanceForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 366);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.gotoPageButton,
																		this.gotoPageTextBox,
																		this.lastButton,
																		this.firstButton,
																		this.dataGrid,
																		this.nextButton,
																		this.previousButton});
		this.Name = "ImprovePagingPerformanceForm";
		this.Text = "9.04 ImprovePagingPerformanceForm";
		this.Load += new System.EventHandler(this.ImprovePagingPerformanceForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void ImprovePagingPerformanceForm_Load(object sender, System.EventArgs e)
	{
		// get the schema for the Orders table
		da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		table = new DataTable("Orders");
		da.FillSchema(table, SchemaType.Source);

		// set up the paging stored procedure
		SqlCommand cmd = new SqlCommand();
		cmd.CommandText = PAGING_SP;
		cmd.Connection = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@PageCommand", SqlDbType.NVarChar, 10);
		cmd.Parameters.Add("@FirstOrderId", SqlDbType.Int);
		cmd.Parameters.Add("@LastOrderId", SqlDbType.Int);
		cmd.Parameters.Add("@PageCount", SqlDbType.Int).Direction = ParameterDirection.Output;
		cmd.Parameters.Add("@CurrentPage", SqlDbType.Int).Direction = ParameterDirection.InputOutput;
		da = new SqlDataAdapter(cmd);

		//get the first page of records
		GetData("FIRST");
		dataGrid.DataSource = table.DefaultView;
	}

	public void GetData(string pageCommand)
	{
		da.SelectCommand.Parameters["@PageCommand"].Value = pageCommand;
		da.SelectCommand.Parameters["@FirstOrderId"].Value = firstOrderId;
		da.SelectCommand.Parameters["@LastOrderId"].Value = lastOrderId;
		da.SelectCommand.Parameters["@CurrentPage"].Value = currentPage;

		table.Clear();
		da.Fill(table);

		if(table.Rows.Count > 0)
		{
			firstOrderId = (int)table.Rows[0][ORDERID_FIELD];
			lastOrderId = (int)table.Rows[table.Rows.Count - 1][ORDERID_FIELD];
		}
		else
			firstOrderId = lastOrderId = -1;

		int pageCount = (int)da.SelectCommand.Parameters["@PageCount"].Value;
		currentPage = (int)da.SelectCommand.Parameters["@CurrentPage"].Value;

		dataGrid.CaptionText = "Orders: Page " + currentPage + " of " + pageCount;
	}

	private void previousButton_Click(object sender, EventArgs args)
	{
		GetData("PREVIOUS");
	}

	private void nextButton_Click(object sender, EventArgs args)
	{
		GetData("NEXT");
	}

	private void firstButton_Click(object sender, System.EventArgs e)
	{
		GetData("FIRST");		
	}

	private void lastButton_Click(object sender, System.EventArgs e)
	{
		GetData("LAST");		
	}

	private void gotoPageButton_Click(object sender, System.EventArgs e)
	{
		try
		{
			currentPage = Convert.ToInt32(gotoPageTextBox.Text);
		}
		catch(Exception ex)
		{
			MessageBox.Show(ex.Message, "Improving Paging Performance", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			return;
		}

		GetData("GOTO");
	}
}