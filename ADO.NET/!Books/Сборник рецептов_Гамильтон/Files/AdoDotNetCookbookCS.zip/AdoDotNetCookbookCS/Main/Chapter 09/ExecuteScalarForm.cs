using System;
using System.Configuration;

using System.Data.SqlClient;

public class ExecuteScalarForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button executeScalarButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ExecuteScalarForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.executeScalarButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// executeScalarButton
		// 
		this.executeScalarButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.executeScalarButton.Location = new System.Drawing.Point(408, 232);
		this.executeScalarButton.Name = "executeScalarButton";
		this.executeScalarButton.TabIndex = 0;
		this.executeScalarButton.Text = "Execute";
		this.executeScalarButton.Click += new System.EventHandler(this.executeScalarButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// ExecuteScalarForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.executeScalarButton);
		this.Name = "ExecuteScalarForm";
		this.Text = "9.10 ExecuteScalarForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void executeScalarButton_Click(object sender, System.EventArgs e)
	{
		String sqlText = "SELECT COUNT(*) FROM Orders";

		// create the connection and the command
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		conn.Open();
		// execute the scalar SQL statement and store results
		int count = Convert.ToInt32(cmd.ExecuteScalar());

		conn.Close();

		resultTextBox.Text="Count of Orders records: " + count;
	}
}