using System;
using System.Windows.Forms;

using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

public class MainForm : System.Windows.Forms.Form
{
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	private MainMenu mainMenu;

	private MenuItem menuItem01;
	private MenuItem menuItem02;
	private MenuItem menuItem03;
	private MenuItem menuItem04;
	private MenuItem menuItem05;
	private MenuItem menuItem06;
	private MenuItem menuItem07;
	private MenuItem menuItem08;
	private MenuItem menuItem09;
	private MenuItem menuItem10;

	private MenuItem menuItem0101;
	private MenuItem menuItem0102;
	private MenuItem menuItem0103;
	private MenuItem menuItem0104;
	private MenuItem menuItem0105;
	private MenuItem menuItem0106;
	private MenuItem menuItem0107;
	private MenuItem menuItem0108;
	private MenuItem menuItem0109;
	private MenuItem menuItem0110;
	private MenuItem menuItem0111;
	private MenuItem menuItem0112;
	private MenuItem menuItem0113;
	private MenuItem menuItem0114;
	private MenuItem menuItem0115;
	private MenuItem menuItem0116;
	private MenuItem menuItem0117;
	private MenuItem menuItem0118;
	private MenuItem menuItem0119;

	private MenuItem menuItem0201;
	private MenuItem menuItem0202;
	private MenuItem menuItem0203;
	private MenuItem menuItem0204;
	private MenuItem menuItem0205;
	private MenuItem menuItem0206;
	private MenuItem menuItem0207;
	private MenuItem menuItem0208;
	private MenuItem menuItem0209;
	private MenuItem menuItem0210;
	private MenuItem menuItem0211;
	private MenuItem menuItem0212;
	private MenuItem menuItem0213;
	private MenuItem menuItem0214;
	private MenuItem menuItem0215;
	private MenuItem menuItem0216;
	private MenuItem menuItem0217;
	private MenuItem menuItem0218;
	private MenuItem menuItem0219;
	private MenuItem menuItem0220;
	private MenuItem menuItem0221;
	private MenuItem menuItem0222;

	private MenuItem menuItem0301;
	private MenuItem menuItem0302;
	private MenuItem menuItem0303;
	private MenuItem menuItem0304;
	private MenuItem menuItem0305;
	private MenuItem menuItem0306;
	private MenuItem menuItem0307;
	private MenuItem menuItem0308;
	private MenuItem menuItem0309;
	private MenuItem menuItem0310;
	private MenuItem menuItem0311;
	private MenuItem menuItem0312;
	private MenuItem menuItem0313;
	private MenuItem menuItem0314;
	
	private MenuItem menuItem0401;
	private MenuItem menuItem0402;
	private MenuItem menuItem0403;
	private MenuItem menuItem0404;
	private MenuItem menuItem0405;
	private MenuItem menuItem0406;
	private MenuItem menuItem0407;
	private MenuItem menuItem0408;
	private MenuItem menuItem0409;
	private MenuItem menuItem0410;
	private MenuItem menuItem0411;
	private MenuItem menuItem0412;
	private MenuItem menuItem0413;
	private MenuItem menuItem0414;

	private MenuItem menuItem0501;
	private MenuItem menuItem0502;
	private MenuItem menuItem0503;
	private MenuItem menuItem0504;
	private MenuItem menuItem0505;
	private MenuItem menuItem0506;
	private MenuItem menuItem0507;
	private MenuItem menuItem0508;
	private MenuItem menuItem0509;
	private MenuItem menuItem0510;
	private MenuItem menuItem0511;
	private MenuItem menuItem0512;
	
	private MenuItem menuItem0601;
	private MenuItem menuItem0602;
	private MenuItem menuItem0603;
	private MenuItem menuItem0604;
	private MenuItem menuItem0605;
	private MenuItem menuItem0606;
	private MenuItem menuItem0607;
	private MenuItem menuItem0608;
	private MenuItem menuItem0609;
	private MenuItem menuItem0610;
	private MenuItem menuItem0611;
	private MenuItem menuItem0612;
	private MenuItem menuItem0613;
	private MenuItem menuItem0614;
	
	private MenuItem menuItem0701;
	private MenuItem menuItem0702;
	private MenuItem menuItem0703;
	private MenuItem menuItem0704;
	private MenuItem menuItem0705;
	private MenuItem menuItem0706;
	private MenuItem menuItem0707;
	private MenuItem menuItem0708;
	private MenuItem menuItem0709;
	private MenuItem menuItem0710;
	private MenuItem menuItem0711;
	private MenuItem menuItem0712;
	private MenuItem menuItem0713;
	private MenuItem menuItem0714;
	private MenuItem menuItem0715;
	private MenuItem menuItem0716;
	private MenuItem menuItem0717;

	private MenuItem menuItem0801;
	private MenuItem menuItem0802;
	private MenuItem menuItem0803;
	private MenuItem menuItem0804;
	private MenuItem menuItem0805;
	private MenuItem menuItem0806;
	private MenuItem menuItem0807;
	private MenuItem menuItem0808;
	private MenuItem menuItem0809;
	private MenuItem menuItem0810;
	private MenuItem menuItem0811;
	
	private MenuItem menuItem0901;
	private MenuItem menuItem0902;
	private MenuItem menuItem0903;
	private MenuItem menuItem0904;
	private MenuItem menuItem0905;
	private MenuItem menuItem0906;
	private MenuItem menuItem0907;
	private MenuItem menuItem0908;
	private MenuItem menuItem0909;
	private MenuItem menuItem0910;
	private MenuItem menuItem0911;
	private MenuItem menuItem0912;
	private MenuItem menuItem0913;
	private MenuItem menuItem0914;

	private MenuItem menuItem1001;
	private MenuItem menuItem1002;
	private MenuItem menuItem1003;
	private MenuItem menuItem1004;
	private MenuItem menuItem1005;
	private MenuItem menuItem1006;
	private MenuItem menuItem1007;
	private MenuItem menuItem1008;
	private MenuItem menuItem1009;
	private MenuItem menuItem1010;
	private MenuItem menuItem1011;
	private MenuItem menuItem1012;
	private MenuItem menuItem1013;
	private MenuItem menuItem1014;
	private MenuItem menuItem1015;
	private System.Windows.Forms.PictureBox coverPictureBox;
	private MenuItem menuItem1016;

	public MainForm()
	{
		InitializeComponent();
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
		this.mainMenu = new System.Windows.Forms.MainMenu();
		this.menuItem01 = new System.Windows.Forms.MenuItem();
		this.menuItem0101 = new System.Windows.Forms.MenuItem();
		this.menuItem0102 = new System.Windows.Forms.MenuItem();
		this.menuItem0103 = new System.Windows.Forms.MenuItem();
		this.menuItem0104 = new System.Windows.Forms.MenuItem();
		this.menuItem0105 = new System.Windows.Forms.MenuItem();
		this.menuItem0106 = new System.Windows.Forms.MenuItem();
		this.menuItem0107 = new System.Windows.Forms.MenuItem();
		this.menuItem0108 = new System.Windows.Forms.MenuItem();
		this.menuItem0109 = new System.Windows.Forms.MenuItem();
		this.menuItem0110 = new System.Windows.Forms.MenuItem();
		this.menuItem0111 = new System.Windows.Forms.MenuItem();
		this.menuItem0112 = new System.Windows.Forms.MenuItem();
		this.menuItem0113 = new System.Windows.Forms.MenuItem();
		this.menuItem0114 = new System.Windows.Forms.MenuItem();
		this.menuItem0115 = new System.Windows.Forms.MenuItem();
		this.menuItem0116 = new System.Windows.Forms.MenuItem();
		this.menuItem0117 = new System.Windows.Forms.MenuItem();
		this.menuItem0118 = new System.Windows.Forms.MenuItem();
		this.menuItem0119 = new System.Windows.Forms.MenuItem();
		this.menuItem02 = new System.Windows.Forms.MenuItem();
		this.menuItem0201 = new System.Windows.Forms.MenuItem();
		this.menuItem0202 = new System.Windows.Forms.MenuItem();
		this.menuItem0203 = new System.Windows.Forms.MenuItem();
		this.menuItem0204 = new System.Windows.Forms.MenuItem();
		this.menuItem0205 = new System.Windows.Forms.MenuItem();
		this.menuItem0206 = new System.Windows.Forms.MenuItem();
		this.menuItem0207 = new System.Windows.Forms.MenuItem();
		this.menuItem0208 = new System.Windows.Forms.MenuItem();
		this.menuItem0209 = new System.Windows.Forms.MenuItem();
		this.menuItem0210 = new System.Windows.Forms.MenuItem();
		this.menuItem0211 = new System.Windows.Forms.MenuItem();
		this.menuItem0212 = new System.Windows.Forms.MenuItem();
		this.menuItem0213 = new System.Windows.Forms.MenuItem();
		this.menuItem0214 = new System.Windows.Forms.MenuItem();
		this.menuItem0215 = new System.Windows.Forms.MenuItem();
		this.menuItem0216 = new System.Windows.Forms.MenuItem();
		this.menuItem0217 = new System.Windows.Forms.MenuItem();
		this.menuItem0218 = new System.Windows.Forms.MenuItem();
		this.menuItem0219 = new System.Windows.Forms.MenuItem();
		this.menuItem0220 = new System.Windows.Forms.MenuItem();
		this.menuItem0221 = new System.Windows.Forms.MenuItem();
		this.menuItem0222 = new System.Windows.Forms.MenuItem();
		this.menuItem03 = new System.Windows.Forms.MenuItem();
		this.menuItem0301 = new System.Windows.Forms.MenuItem();
		this.menuItem0302 = new System.Windows.Forms.MenuItem();
		this.menuItem0303 = new System.Windows.Forms.MenuItem();
		this.menuItem0304 = new System.Windows.Forms.MenuItem();
		this.menuItem0305 = new System.Windows.Forms.MenuItem();
		this.menuItem0306 = new System.Windows.Forms.MenuItem();
		this.menuItem0307 = new System.Windows.Forms.MenuItem();
		this.menuItem0308 = new System.Windows.Forms.MenuItem();
		this.menuItem0309 = new System.Windows.Forms.MenuItem();
		this.menuItem0310 = new System.Windows.Forms.MenuItem();
		this.menuItem0311 = new System.Windows.Forms.MenuItem();
		this.menuItem0312 = new System.Windows.Forms.MenuItem();
		this.menuItem0313 = new System.Windows.Forms.MenuItem();
		this.menuItem0314 = new System.Windows.Forms.MenuItem();
		this.menuItem04 = new System.Windows.Forms.MenuItem();
		this.menuItem0401 = new System.Windows.Forms.MenuItem();
		this.menuItem0402 = new System.Windows.Forms.MenuItem();
		this.menuItem0403 = new System.Windows.Forms.MenuItem();
		this.menuItem0404 = new System.Windows.Forms.MenuItem();
		this.menuItem0405 = new System.Windows.Forms.MenuItem();
		this.menuItem0406 = new System.Windows.Forms.MenuItem();
		this.menuItem0407 = new System.Windows.Forms.MenuItem();
		this.menuItem0408 = new System.Windows.Forms.MenuItem();
		this.menuItem0409 = new System.Windows.Forms.MenuItem();
		this.menuItem0410 = new System.Windows.Forms.MenuItem();
		this.menuItem0411 = new System.Windows.Forms.MenuItem();
		this.menuItem0412 = new System.Windows.Forms.MenuItem();
		this.menuItem0413 = new System.Windows.Forms.MenuItem();
		this.menuItem0414 = new System.Windows.Forms.MenuItem();
		this.menuItem05 = new System.Windows.Forms.MenuItem();
		this.menuItem0501 = new System.Windows.Forms.MenuItem();
		this.menuItem0502 = new System.Windows.Forms.MenuItem();
		this.menuItem0503 = new System.Windows.Forms.MenuItem();
		this.menuItem0504 = new System.Windows.Forms.MenuItem();
		this.menuItem0505 = new System.Windows.Forms.MenuItem();
		this.menuItem0506 = new System.Windows.Forms.MenuItem();
		this.menuItem0507 = new System.Windows.Forms.MenuItem();
		this.menuItem0508 = new System.Windows.Forms.MenuItem();
		this.menuItem0509 = new System.Windows.Forms.MenuItem();
		this.menuItem0510 = new System.Windows.Forms.MenuItem();
		this.menuItem0511 = new System.Windows.Forms.MenuItem();
		this.menuItem0512 = new System.Windows.Forms.MenuItem();
		this.menuItem06 = new System.Windows.Forms.MenuItem();
		this.menuItem0601 = new System.Windows.Forms.MenuItem();
		this.menuItem0602 = new System.Windows.Forms.MenuItem();
		this.menuItem0603 = new System.Windows.Forms.MenuItem();
		this.menuItem0604 = new System.Windows.Forms.MenuItem();
		this.menuItem0605 = new System.Windows.Forms.MenuItem();
		this.menuItem0606 = new System.Windows.Forms.MenuItem();
		this.menuItem0607 = new System.Windows.Forms.MenuItem();
		this.menuItem0608 = new System.Windows.Forms.MenuItem();
		this.menuItem0609 = new System.Windows.Forms.MenuItem();
		this.menuItem0610 = new System.Windows.Forms.MenuItem();
		this.menuItem0611 = new System.Windows.Forms.MenuItem();
		this.menuItem0612 = new System.Windows.Forms.MenuItem();
		this.menuItem0613 = new System.Windows.Forms.MenuItem();
		this.menuItem0614 = new System.Windows.Forms.MenuItem();
		this.menuItem07 = new System.Windows.Forms.MenuItem();
		this.menuItem0701 = new System.Windows.Forms.MenuItem();
		this.menuItem0702 = new System.Windows.Forms.MenuItem();
		this.menuItem0703 = new System.Windows.Forms.MenuItem();
		this.menuItem0704 = new System.Windows.Forms.MenuItem();
		this.menuItem0705 = new System.Windows.Forms.MenuItem();
		this.menuItem0706 = new System.Windows.Forms.MenuItem();
		this.menuItem0707 = new System.Windows.Forms.MenuItem();
		this.menuItem0708 = new System.Windows.Forms.MenuItem();
		this.menuItem0709 = new System.Windows.Forms.MenuItem();
		this.menuItem0710 = new System.Windows.Forms.MenuItem();
		this.menuItem0711 = new System.Windows.Forms.MenuItem();
		this.menuItem0712 = new System.Windows.Forms.MenuItem();
		this.menuItem0713 = new System.Windows.Forms.MenuItem();
		this.menuItem0714 = new System.Windows.Forms.MenuItem();
		this.menuItem0715 = new System.Windows.Forms.MenuItem();
		this.menuItem0716 = new System.Windows.Forms.MenuItem();
		this.menuItem0717 = new System.Windows.Forms.MenuItem();
		this.menuItem08 = new System.Windows.Forms.MenuItem();
		this.menuItem0801 = new System.Windows.Forms.MenuItem();
		this.menuItem0802 = new System.Windows.Forms.MenuItem();
		this.menuItem0803 = new System.Windows.Forms.MenuItem();
		this.menuItem0804 = new System.Windows.Forms.MenuItem();
		this.menuItem0805 = new System.Windows.Forms.MenuItem();
		this.menuItem0806 = new System.Windows.Forms.MenuItem();
		this.menuItem0807 = new System.Windows.Forms.MenuItem();
		this.menuItem0808 = new System.Windows.Forms.MenuItem();
		this.menuItem0809 = new System.Windows.Forms.MenuItem();
		this.menuItem0810 = new System.Windows.Forms.MenuItem();
		this.menuItem0811 = new System.Windows.Forms.MenuItem();
		this.menuItem09 = new System.Windows.Forms.MenuItem();
		this.menuItem0901 = new System.Windows.Forms.MenuItem();
		this.menuItem0902 = new System.Windows.Forms.MenuItem();
		this.menuItem0903 = new System.Windows.Forms.MenuItem();
		this.menuItem0904 = new System.Windows.Forms.MenuItem();
		this.menuItem0905 = new System.Windows.Forms.MenuItem();
		this.menuItem0906 = new System.Windows.Forms.MenuItem();
		this.menuItem0907 = new System.Windows.Forms.MenuItem();
		this.menuItem0908 = new System.Windows.Forms.MenuItem();
		this.menuItem0909 = new System.Windows.Forms.MenuItem();
		this.menuItem0910 = new System.Windows.Forms.MenuItem();
		this.menuItem0911 = new System.Windows.Forms.MenuItem();
		this.menuItem0912 = new System.Windows.Forms.MenuItem();
		this.menuItem0913 = new System.Windows.Forms.MenuItem();
		this.menuItem0914 = new System.Windows.Forms.MenuItem();
		this.menuItem10 = new System.Windows.Forms.MenuItem();
		this.menuItem1001 = new System.Windows.Forms.MenuItem();
		this.menuItem1002 = new System.Windows.Forms.MenuItem();
		this.menuItem1003 = new System.Windows.Forms.MenuItem();
		this.menuItem1004 = new System.Windows.Forms.MenuItem();
		this.menuItem1005 = new System.Windows.Forms.MenuItem();
		this.menuItem1006 = new System.Windows.Forms.MenuItem();
		this.menuItem1007 = new System.Windows.Forms.MenuItem();
		this.menuItem1008 = new System.Windows.Forms.MenuItem();
		this.menuItem1009 = new System.Windows.Forms.MenuItem();
		this.menuItem1010 = new System.Windows.Forms.MenuItem();
		this.menuItem1011 = new System.Windows.Forms.MenuItem();
		this.menuItem1012 = new System.Windows.Forms.MenuItem();
		this.menuItem1013 = new System.Windows.Forms.MenuItem();
		this.menuItem1014 = new System.Windows.Forms.MenuItem();
		this.menuItem1015 = new System.Windows.Forms.MenuItem();
		this.menuItem1016 = new System.Windows.Forms.MenuItem();
		this.coverPictureBox = new System.Windows.Forms.PictureBox();
		this.SuspendLayout();
		// 
		// mainMenu
		// 
		this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				 this.menuItem01,
																				 this.menuItem02,
																				 this.menuItem03,
																				 this.menuItem04,
																				 this.menuItem05,
																				 this.menuItem06,
																				 this.menuItem07,
																				 this.menuItem08,
																				 this.menuItem09,
																				 this.menuItem10});
		// 
		// menuItem01
		// 
		this.menuItem01.Index = 0;
		this.menuItem01.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem0101,
																				   this.menuItem0102,
																				   this.menuItem0103,
																				   this.menuItem0104,
																				   this.menuItem0105,
																				   this.menuItem0106,
																				   this.menuItem0107,
																				   this.menuItem0108,
																				   this.menuItem0109,
																				   this.menuItem0110,
																				   this.menuItem0111,
																				   this.menuItem0112,
																				   this.menuItem0113,
																				   this.menuItem0114,
																				   this.menuItem0115,
																				   this.menuItem0116,
																				   this.menuItem0117,
																				   this.menuItem0118,
																				   this.menuItem0119});
		this.menuItem01.Text = "Chapter 1";
		// 
		// menuItem0101
		// 
		this.menuItem0101.Index = 0;
		this.menuItem0101.Text = "1.1 Connecting to an ODBC Data Source";
		this.menuItem0101.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0102
		// 
		this.menuItem0102.Index = 1;
		this.menuItem0102.Text = "1.2 Connecting to a Microsoft Excel Workbook";
		this.menuItem0102.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0103
		// 
		this.menuItem0103.Index = 2;
		this.menuItem0103.Text = "1.3 Connecting to a Password-Protected Access Database";
		this.menuItem0103.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0104
		// 
		this.menuItem0104.Index = 3;
		this.menuItem0104.Text = "1.4 Connecting to a Secured Access Database";
		this.menuItem0104.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0105
		// 
		this.menuItem0105.Index = 4;
		this.menuItem0105.Text = "1.5 Connecting to an Access Database from ASP.NET";
		this.menuItem0105.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0106
		// 
		this.menuItem0106.Index = 5;
		this.menuItem0106.Text = "1.6 Using an IP Address to Connect to SQL Server";
		this.menuItem0106.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0107
		// 
		this.menuItem0107.Index = 6;
		this.menuItem0107.Text = "1.7 Connecting to a Named Instance of SQL Server or MSDE";
		this.menuItem0107.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0108
		// 
		this.menuItem0108.Index = 7;
		this.menuItem0108.Text = "1.8 Connecting to SQL Server Using Integrated Security from ASP.NET";
		this.menuItem0108.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0109
		// 
		this.menuItem0109.Index = 8;
		this.menuItem0109.Text = "1.9 Connecting to an Oracle Database";
		this.menuItem0109.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0110
		// 
		this.menuItem0110.Index = 9;
		this.menuItem0110.Text = "1.10 Connecting to Exchange or Outlook";
		this.menuItem0110.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0111
		// 
		this.menuItem0111.Index = 10;
		this.menuItem0111.Text = "1.11 Writing Database-Independent Code";
		this.menuItem0111.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0112
		// 
		this.menuItem0112.Index = 11;
		this.menuItem0112.Text = "1.12 Storing Connection Strings";
		this.menuItem0112.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0113
		// 
		this.menuItem0113.Index = 12;
		this.menuItem0113.Text = "1.13 Using the Data Link Properties Dialog Box";
		this.menuItem0113.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0114
		// 
		this.menuItem0114.Index = 13;
		this.menuItem0114.Text = "1.14 Monitoring Connections";
		this.menuItem0114.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0115
		// 
		this.menuItem0115.Index = 14;
		this.menuItem0115.Text = "1.15 Taking Advantage of Connection Pooling";
		this.menuItem0115.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0116
		// 
		this.menuItem0116.Index = 15;
		this.menuItem0116.Text = "1.16 Setting Connection Pooling Options";
		this.menuItem0116.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0117
		// 
		this.menuItem0117.Index = 16;
		this.menuItem0117.Text = "1.17 Using Transactions with Pooled Connections";
		this.menuItem0117.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0118
		// 
		this.menuItem0118.Index = 17;
		this.menuItem0118.Text = "1.18 Changing the  Database for an Open Connection";
		this.menuItem0118.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0119
		// 
		this.menuItem0119.Index = 18;
		this.menuItem0119.Text = "1.19 Connecting to a Text File";
		this.menuItem0119.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem02
		// 
		this.menuItem02.Index = 1;
		this.menuItem02.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem0201,
																				   this.menuItem0202,
																				   this.menuItem0203,
																				   this.menuItem0204,
																				   this.menuItem0205,
																				   this.menuItem0206,
																				   this.menuItem0207,
																				   this.menuItem0208,
																				   this.menuItem0209,
																				   this.menuItem0210,
																				   this.menuItem0211,
																				   this.menuItem0212,
																				   this.menuItem0213,
																				   this.menuItem0214,
																				   this.menuItem0215,
																				   this.menuItem0216,
																				   this.menuItem0217,
																				   this.menuItem0218,
																				   this.menuItem0219,
																				   this.menuItem0220,
																				   this.menuItem0221,
																				   this.menuItem0222});
		this.menuItem02.Text = "Chapter 2";
		// 
		// menuItem0201
		// 
		this.menuItem0201.Index = 0;
		this.menuItem0201.Text = "2.1 Retrieving Hierarchical Data in a DataSet";
		this.menuItem0201.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0202
		// 
		this.menuItem0202.Index = 1;
		this.menuItem0202.Text = "2.2 Building a DataSet Programatically";
		this.menuItem0202.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0203
		// 
		this.menuItem0203.Index = 2;
		this.menuItem0203.Text = "2.3 Creating a Strongly Typed DataSet";
		this.menuItem0203.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0204
		// 
		this.menuItem0204.Index = 3;
		this.menuItem0204.Text = "2.4 Processing a Batch SQL Statement";
		this.menuItem0204.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0205
		// 
		this.menuItem0205.Index = 4;
		this.menuItem0205.Text = "2.5 Using a Web Service as a Data Source";
		this.menuItem0205.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0206
		// 
		this.menuItem0206.Index = 5;
		this.menuItem0206.Text = "2.6 Accessing Deleted Rows in a DataTable ";
		this.menuItem0206.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0207
		// 
		this.menuItem0207.Index = 6;
		this.menuItem0207.Text = "2.7 Counting Records in a DataReader";
		this.menuItem0207.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0208
		// 
		this.menuItem0208.Index = 7;
		this.menuItem0208.Text = "2.8 Mapping .NET Data Provider Types to .NET Framework Data Types";
		this.menuItem0208.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0209
		// 
		this.menuItem0209.Index = 8;
		this.menuItem0209.Text = "2.9 Returning an Output Parameter Using a DataReader";
		this.menuItem0209.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0210
		// 
		this.menuItem0210.Index = 9;
		this.menuItem0210.Text = "2.10 Raising and Handling Stored Procedure Errors";
		this.menuItem0210.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0211
		// 
		this.menuItem0211.Index = 10;
		this.menuItem0211.Text = "2.11 Testing for No Records";
		this.menuItem0211.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0212
		// 
		this.menuItem0212.Index = 11;
		this.menuItem0212.Text = "2.12 Retrieving Stored Procedure Return Values Using a DataReader";
		this.menuItem0212.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0213
		// 
		this.menuItem0213.Index = 12;
		this.menuItem0213.Text = "2.13 Executing SQL Server User-Defined Scalar Functions";
		this.menuItem0213.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0214
		// 
		this.menuItem0214.Index = 13;
		this.menuItem0214.Text = "2.14 Passing Null Values to Parameters";
		this.menuItem0214.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0215
		// 
		this.menuItem0215.Index = 14;
		this.menuItem0215.Text = "2.15 Retrieving Update Errors";
		this.menuItem0215.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0216
		// 
		this.menuItem0216.Index = 15;
		this.menuItem0216.Text = "2.16 Mapping Table and Column Names between the data Source and DataSet";
		this.menuItem0216.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0217
		// 
		this.menuItem0217.Index = 16;
		this.menuItem0217.Text = "2.17 Displaying Columns from a Related DataTable";
		this.menuItem0217.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0218
		// 
		this.menuItem0218.Index = 17;
		this.menuItem0218.Text = "2.18 Controlling the Names Used in a Strongly Typed DataSet";
		this.menuItem0218.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0219
		// 
		this.menuItem0219.Index = 18;
		this.menuItem0219.Text = "2.19 Replacing Null Values in Strongly Typed DataSets";
		this.menuItem0219.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0220
		// 
		this.menuItem0220.Index = 19;
		this.menuItem0220.Text = "2.20 Retrieving Data from an Oracle Package";
		this.menuItem0220.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0221
		// 
		this.menuItem0221.Index = 20;
		this.menuItem0221.Text = "2.21 Using Parameterized SQL Statements";
		this.menuItem0221.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0222
		// 
		this.menuItem0222.Index = 21;
		this.menuItem0222.Text = "2.22 Querying Data Asynchronously Using with Message Queuing";
		this.menuItem0222.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem03
		// 
		this.menuItem03.Index = 2;
		this.menuItem03.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem0301,
																				   this.menuItem0302,
																				   this.menuItem0303,
																				   this.menuItem0304,
																				   this.menuItem0305,
																				   this.menuItem0306,
																				   this.menuItem0307,
																				   this.menuItem0308,
																				   this.menuItem0309,
																				   this.menuItem0310,
																				   this.menuItem0311,
																				   this.menuItem0312,
																				   this.menuItem0313,
																				   this.menuItem0314});
		this.menuItem03.Text = "Chapter 3";
		// 
		// menuItem0301
		// 
		this.menuItem0301.Index = 0;
		this.menuItem0301.Text = "3.1 Filtering and Sorting Data";
		this.menuItem0301.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0302
		// 
		this.menuItem0302.Index = 1;
		this.menuItem0302.Text = "3.2 Using Expression Columns to Display Calculated Values";
		this.menuItem0302.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0303
		// 
		this.menuItem0303.Index = 2;
		this.menuItem0303.Text = "3.3 Determining the Difference in Data Betweeen Two DataSet Objects";
		this.menuItem0303.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0304
		// 
		this.menuItem0304.Index = 3;
		this.menuItem0304.Text = "3.4 Navigate Between Parent and Child Records Using a DataRelation";
		this.menuItem0304.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0305
		// 
		this.menuItem0305.Index = 4;
		this.menuItem0305.Text = "3.5 Localizing Client-Side Data in a Web Forms Application";
		this.menuItem0305.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0306
		// 
		this.menuItem0306.Index = 5;
		this.menuItem0306.Text = "3.6 Combining Data in Tables from Heterogeneous Data Sources";
		this.menuItem0306.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0307
		// 
		this.menuItem0307.Index = 6;
		this.menuItem0307.Text = "3.7 Using Expression Columns to Display Aggregate Values";
		this.menuItem0307.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0308
		// 
		this.menuItem0308.Index = 7;
		this.menuItem0308.Text = "3.8 Finding Rows in a DataTable";
		this.menuItem0308.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0309
		// 
		this.menuItem0309.Index = 8;
		this.menuItem0309.Text = "3.9 Finding Rows in a DataView";
		this.menuItem0309.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0310
		// 
		this.menuItem0310.Index = 9;
		this.menuItem0310.Text = "3.10 Getting the Top n Rows in a DataTable";
		this.menuItem0310.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0311
		// 
		this.menuItem0311.Index = 10;
		this.menuItem0311.Text = "3.11 Getting Typed DataRows from DataViews";
		this.menuItem0311.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0312
		// 
		this.menuItem0312.Index = 11;
		this.menuItem0312.Text = "3.12 Filter for Null Values";
		this.menuItem0312.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0313
		// 
		this.menuItem0313.Index = 12;
		this.menuItem0313.Text = "3.13 Executing Queries That Use COMPUTE BY";
		this.menuItem0313.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0314
		// 
		this.menuItem0314.Index = 13;
		this.menuItem0314.Text = "3.14 Using the Shape Language to Retrieve Hierarchical Data";
		this.menuItem0314.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem04
		// 
		this.menuItem04.Index = 3;
		this.menuItem04.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem0401,
																				   this.menuItem0402,
																				   this.menuItem0403,
																				   this.menuItem0404,
																				   this.menuItem0405,
																				   this.menuItem0406,
																				   this.menuItem0407,
																				   this.menuItem0408,
																				   this.menuItem0409,
																				   this.menuItem0410,
																				   this.menuItem0411,
																				   this.menuItem0412,
																				   this.menuItem0413,
																				   this.menuItem0414});
		this.menuItem04.Text = "Chapter 4";
		// 
		// menuItem0401
		// 
		this.menuItem0401.Index = 0;
		this.menuItem0401.Text = "4.1 Using AutoIncrementing Column Without Causing Conflicts";
		this.menuItem0401.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0402
		// 
		this.menuItem0402.Index = 1;
		this.menuItem0402.Text = "4.2 Get Identity Column Value from SQL Server";
		this.menuItem0402.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0403
		// 
		this.menuItem0403.Index = 2;
		this.menuItem0403.Text = "4.3 Get an AutoNumber Value from Microsoft Access";
		this.menuItem0403.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0404
		// 
		this.menuItem0404.Index = 3;
		this.menuItem0404.Text = "4.4 Getting a Sequence Values from Oracle";
		this.menuItem0404.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0405
		// 
		this.menuItem0405.Index = 4;
		this.menuItem0405.Text = "4.5 Adding Parent/Child Rows with Auto-Incrementing Keys";
		this.menuItem0405.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0406
		// 
		this.menuItem0406.Index = 5;
		this.menuItem0406.Text = "4.6 Add Records with a GUID Primary Key";
		this.menuItem0406.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0407
		// 
		this.menuItem0407.Index = 6;
		this.menuItem0407.Text = "4.7 Updating a Data Source with Data from a Different Data Source";
		this.menuItem0407.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0408
		// 
		this.menuItem0408.Index = 7;
		this.menuItem0408.Text = "4.8 Updating a Primary Key Value";
		this.menuItem0408.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0409
		// 
		this.menuItem0409.Index = 8;
		this.menuItem0409.Text = "4.9 Getting Stored Procedure Parameter Information at Runtime";
		this.menuItem0409.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0410
		// 
		this.menuItem0410.Index = 9;
		this.menuItem0410.Text = "4.10 Updating a DataSet with a Many-to-Many Relationship";
		this.menuItem0410.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0411
		// 
		this.menuItem0411.Index = 10;
		this.menuItem0411.Text = "4.11 Updating Server Data Using a Web Service";
		this.menuItem0411.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0412
		// 
		this.menuItem0412.Index = 11;
		this.menuItem0412.Text = "4.12 Updating Server Data Using .NET Remoting";
		this.menuItem0412.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0413
		// 
		this.menuItem0413.Index = 12;
		this.menuItem0413.Text = "4.13 Updating Data Asynchronously Using Message Queuing";
		this.menuItem0413.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0414
		// 
		this.menuItem0414.Index = 13;
		this.menuItem0414.Text = "4.14 Overcoming Keyword Conflicts When Using CommandBuilders";
		this.menuItem0414.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem05
		// 
		this.menuItem05.Index = 4;
		this.menuItem05.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem0501,
																				   this.menuItem0502,
																				   this.menuItem0503,
																				   this.menuItem0504,
																				   this.menuItem0505,
																				   this.menuItem0506,
																				   this.menuItem0507,
																				   this.menuItem0508,
																				   this.menuItem0509,
																				   this.menuItem0510,
																				   this.menuItem0511,
																				   this.menuItem0512});
		this.menuItem05.Text = "Chapter 5";
		// 
		// menuItem0501
		// 
		this.menuItem0501.Index = 0;
		this.menuItem0501.Text = "5.1 Copying Rows from One DataTable to Another";
		this.menuItem0501.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0502
		// 
		this.menuItem0502.Index = 1;
		this.menuItem0502.Text = "5.2 Copying Tables from One DataSet to Another";
		this.menuItem0502.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0503
		// 
		this.menuItem0503.Index = 2;
		this.menuItem0503.Text = "5.3 Converting a DataReader to a DataSet";
		this.menuItem0503.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0504
		// 
		this.menuItem0504.Index = 3;
		this.menuItem0504.Text = "5.4 Serializing Data";
		this.menuItem0504.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0505
		// 
		this.menuItem0505.Index = 4;
		this.menuItem0505.Text = "5.5 Deserializing Data";
		this.menuItem0505.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0506
		// 
		this.menuItem0506.Index = 5;
		this.menuItem0506.Text = "5.6 Merging Data";
		this.menuItem0506.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0507
		// 
		this.menuItem0507.Index = 6;
		this.menuItem0507.Text = "5.7 Transmitting a DataSet Securely";
		this.menuItem0507.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0508
		// 
		this.menuItem0508.Index = 7;
		this.menuItem0508.Text = "5.8 Transferring Login Credentials Securely";
		this.menuItem0508.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0509
		// 
		this.menuItem0509.Index = 8;
		this.menuItem0509.Text = "5.9 Loading an ADO Recordset into a DataSet";
		this.menuItem0509.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0510
		// 
		this.menuItem0510.Index = 9;
		this.menuItem0510.Text = "5.10 Converting a DataSet to an ADO Recordset";
		this.menuItem0510.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0511
		// 
		this.menuItem0511.Index = 10;
		this.menuItem0511.Text = "5.11 Exporting the Results of a Query as a String";
		this.menuItem0511.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0512
		// 
		this.menuItem0512.Index = 11;
		this.menuItem0512.Text = "5.12 Exporting the Results of a Query to an Array";
		this.menuItem0512.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem06
		// 
		this.menuItem06.Index = 5;
		this.menuItem06.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem0601,
																				   this.menuItem0602,
																				   this.menuItem0603,
																				   this.menuItem0604,
																				   this.menuItem0605,
																				   this.menuItem0606,
																				   this.menuItem0607,
																				   this.menuItem0608,
																				   this.menuItem0609,
																				   this.menuItem0610,
																				   this.menuItem0611,
																				   this.menuItem0612,
																				   this.menuItem0613,
																				   this.menuItem0614});
		this.menuItem06.Text = "Chapter 6";
		// 
		// menuItem0601
		// 
		this.menuItem0601.Index = 0;
		this.menuItem0601.Text = "6.1 Creating a Class That Participates in an Automatic Transaction";
		this.menuItem0601.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0602
		// 
		this.menuItem0602.Index = 1;
		this.menuItem0602.Text = "6.2 Using Manual Transactions";
		this.menuItem0602.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0603
		// 
		this.menuItem0603.Index = 2;
		this.menuItem0603.Text = "6.3 Nesting Manual Transactions with the SQL Server .NET Data Provider";
		this.menuItem0603.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0604
		// 
		this.menuItem0604.Index = 3;
		this.menuItem0604.Text = "6.4 Using ADO.NET and SQL Server DBMS Transactions Together";
		this.menuItem0604.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0605
		// 
		this.menuItem0605.Index = 4;
		this.menuItem0605.Text = "6.5 Using a Transaction with a DataAdapter";
		this.menuItem0605.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0606
		// 
		this.menuItem0606.Index = 5;
		this.menuItem0606.Text = "6.6 Avoiding Referential Integrity Problems When Updating the Data Source";
		this.menuItem0606.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0607
		// 
		this.menuItem0607.Index = 6;
		this.menuItem0607.Text = "6.7 Enforcing Business Rules with Column Expressions ";
		this.menuItem0607.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0608
		// 
		this.menuItem0608.Index = 7;
		this.menuItem0608.Text = "6.8 Creating Constraints, PrimaryKeys, Relationships Based on Multiple Columns";
		this.menuItem0608.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0609
		// 
		this.menuItem0609.Index = 8;
		this.menuItem0609.Text = "6.9 Retrieving Constraints from a SQL Server Database";
		this.menuItem0609.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0610
		// 
		this.menuItem0610.Index = 9;
		this.menuItem0610.Text = "6.10 Checking for Concurrency Violations";
		this.menuItem0610.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0611
		// 
		this.menuItem0611.Index = 10;
		this.menuItem0611.Text = "6.11 Resolving Data Conflicts";
		this.menuItem0611.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0612
		// 
		this.menuItem0612.Index = 11;
		this.menuItem0612.Text = "6.12 Using Transaction Isolation Levels to Protect Data";
		this.menuItem0612.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0613
		// 
		this.menuItem0613.Index = 12;
		this.menuItem0613.Text = "6.13 Implementing Pessimistic Concurrency Without Using Database Locks";
		this.menuItem0613.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0614
		// 
		this.menuItem0614.Index = 13;
		this.menuItem0614.Text = "6.14 Specifying Locking Hints in a SQL Server Database ";
		this.menuItem0614.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem07
		// 
		this.menuItem07.Index = 6;
		this.menuItem07.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem0701,
																				   this.menuItem0702,
																				   this.menuItem0703,
																				   this.menuItem0704,
																				   this.menuItem0705,
																				   this.menuItem0706,
																				   this.menuItem0707,
																				   this.menuItem0708,
																				   this.menuItem0709,
																				   this.menuItem0710,
																				   this.menuItem0711,
																				   this.menuItem0712,
																				   this.menuItem0713,
																				   this.menuItem0714,
																				   this.menuItem0715,
																				   this.menuItem0716,
																				   this.menuItem0717});
		this.menuItem07.Text = "Chapter 7";
		// 
		// menuItem0701
		// 
		this.menuItem0701.Index = 0;
		this.menuItem0701.Text = "7.1 Binding Simple Data to Web Forms Controls";
		this.menuItem0701.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0702
		// 
		this.menuItem0702.Index = 1;
		this.menuItem0702.Text = "7.2 Binding Complex Data to Web Forms Controls";
		this.menuItem0702.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0703
		// 
		this.menuItem0703.Index = 2;
		this.menuItem0703.Text = "7.3 Binding Data to a Web Forms DataList";
		this.menuItem0703.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0704
		// 
		this.menuItem0704.Index = 3;
		this.menuItem0704.Text = "7.4 Binding Data to a Web forms DataGrid";
		// 
		// menuItem0705
		// 
		this.menuItem0705.Index = 4;
		this.menuItem0705.Text = "7.5  Editing and Updating Data in a Web Forms DataGrid";
		this.menuItem0705.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0706
		// 
		this.menuItem0706.Index = 5;
		this.menuItem0706.Text = "7.6 Synchronizing Master-Detail Web Forms DataGrids";
		this.menuItem0706.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0707
		// 
		this.menuItem0707.Index = 6;
		this.menuItem0707.Text = "7.7 Displaying an Image from a Database in a Web Forms Control";
		this.menuItem0707.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0708
		// 
		this.menuItem0708.Index = 7;
		this.menuItem0708.Text = "7.8 Displaying an Image from a Database in a Windows Forms Control";
		this.menuItem0708.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0709
		// 
		this.menuItem0709.Index = 8;
		this.menuItem0709.Text = "7.9 Binding a Group of Radio Buttons in a Windows Form";
		this.menuItem0709.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0710
		// 
		this.menuItem0710.Index = 9;
		this.menuItem0710.Text = "7.10 Creating Custom Columns in a Windows Forms DataGrid";
		this.menuItem0710.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0711
		// 
		this.menuItem0711.Index = 10;
		this.menuItem0711.Text = "7.11 Populating a Windows Forms ComboBox";
		this.menuItem0711.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0712
		// 
		this.menuItem0712.Index = 11;
		this.menuItem0712.Text = "7.12 Binding a Windows DataGrid to Master-Detail Data";
		this.menuItem0712.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0713
		// 
		this.menuItem0713.Index = 12;
		this.menuItem0713.Text = "7.13 Loading a Windows PictureBox with Images Stored by Access as OLE Objects";
		this.menuItem0713.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0714
		// 
		this.menuItem0714.Index = 13;
		this.menuItem0714.Text = "7.14 Using a DataView to Control Edits, Deletions, or Additions in Windows Forms";
		this.menuItem0714.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0715
		// 
		this.menuItem0715.Index = 14;
		this.menuItem0715.Text = "7.15 Adding Search Capabilities to Windows Forms";
		this.menuItem0715.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0716
		// 
		this.menuItem0716.Index = 15;
		this.menuItem0716.Text = "7.16 Dynamically Creating Crystal Reports";
		this.menuItem0716.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0717
		// 
		this.menuItem0717.Index = 16;
		this.menuItem0717.Text = "7.17 Using ADO.NET Design-Time Features in Classes Without a GUI ";
		this.menuItem0717.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem08
		// 
		this.menuItem08.Index = 7;
		this.menuItem08.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem0801,
																				   this.menuItem0802,
																				   this.menuItem0803,
																				   this.menuItem0804,
																				   this.menuItem0805,
																				   this.menuItem0806,
																				   this.menuItem0807,
																				   this.menuItem0808,
																				   this.menuItem0809,
																				   this.menuItem0810,
																				   this.menuItem0811});
		this.menuItem08.Text = "Chapter 8";
		// 
		// menuItem0801
		// 
		this.menuItem0801.Index = 0;
		this.menuItem0801.Text = "8.1 Using XSD Schema Files to Load and Save a DataSet Structure";
		this.menuItem0801.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0802
		// 
		this.menuItem0802.Index = 1;
		this.menuItem0802.Text = "8.2 Saving and Loading a DataSet from XML";
		this.menuItem0802.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0803
		// 
		this.menuItem0803.Index = 2;
		this.menuItem0803.Text = "8.3 Synchronizing a DataSet with an XML Document";
		this.menuItem0803.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0804
		// 
		this.menuItem0804.Index = 3;
		this.menuItem0804.Text = "8.4 Storing XML to a Database Field";
		this.menuItem0804.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0805
		// 
		this.menuItem0805.Index = 4;
		this.menuItem0805.Text = "8.5 Reading XML Data Directly from SQL Server";
		this.menuItem0805.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0806
		// 
		this.menuItem0806.Index = 5;
		this.menuItem0806.Text = "8.6 Using XPath to Query Data in a DataSet";
		this.menuItem0806.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0807
		// 
		this.menuItem0807.Index = 6;
		this.menuItem0807.Text = "8.7 Transforming a DataSet Using XSLT";
		this.menuItem0807.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0808
		// 
		this.menuItem0808.Index = 7;
		this.menuItem0808.Text = "8.8 Creating an XML File That Shows Changes Made to a DataSet";
		this.menuItem0808.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0809
		// 
		this.menuItem0809.Index = 8;
		this.menuItem0809.Text = "8.9 Formatting Column Values When Outputting Data as XML";
		this.menuItem0809.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0810
		// 
		this.menuItem0810.Index = 9;
		this.menuItem0810.Text = "8.10 Filling a DataSet Using an XML Template Queries ";
		this.menuItem0810.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0811
		// 
		this.menuItem0811.Index = 10;
		this.menuItem0811.Text = "8.11 Using a Single Stored Procedure to Update Multiple Changes to a SQL Server D" +
			"atabase";
		this.menuItem0811.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem09
		// 
		this.menuItem09.Index = 8;
		this.menuItem09.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem0901,
																				   this.menuItem0902,
																				   this.menuItem0903,
																				   this.menuItem0904,
																				   this.menuItem0905,
																				   this.menuItem0906,
																				   this.menuItem0907,
																				   this.menuItem0908,
																				   this.menuItem0909,
																				   this.menuItem0910,
																				   this.menuItem0911,
																				   this.menuItem0912,
																				   this.menuItem0913,
																				   this.menuItem0914});
		this.menuItem09.Text = "Chapter 9";
		// 
		// menuItem0901
		// 
		this.menuItem0901.Index = 0;
		this.menuItem0901.Text = "9.1 Filling a DataSet Asynchronously";
		this.menuItem0901.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0902
		// 
		this.menuItem0902.Index = 1;
		this.menuItem0902.Text = "9.2 Cancelling an Asynchronous Query";
		this.menuItem0902.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0903
		// 
		this.menuItem0903.Index = 2;
		this.menuItem0903.Text = "9.3 Caching Data";
		this.menuItem0903.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0904
		// 
		this.menuItem0904.Index = 3;
		this.menuItem0904.Text = "9.4 Improving Paging Performance";
		this.menuItem0904.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0905
		// 
		this.menuItem0905.Index = 4;
		this.menuItem0905.Text = "9.5 Performing a Bulk Insert with SQL Server";
		this.menuItem0905.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0906
		// 
		this.menuItem0906.Index = 5;
		this.menuItem0906.Text = "9.6 improving DataReader Performance with Typed Accessors";
		this.menuItem0906.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0907
		// 
		this.menuItem0907.Index = 6;
		this.menuItem0907.Text = "9.7 Improving DataReader Performance with Column Ordinals";
		this.menuItem0907.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0908
		// 
		this.menuItem0908.Index = 7;
		this.menuItem0908.Text = "9.8 Degugging SQL Server Stored Procedures";
		this.menuItem0908.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0909
		// 
		this.menuItem0909.Index = 8;
		this.menuItem0909.Text = "9.9 Improving Performance While Filling a DataSet";
		this.menuItem0909.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0910
		// 
		this.menuItem0910.Index = 9;
		this.menuItem0910.Text = "9.10 Retrieving a Single Value from a Query";
		this.menuItem0910.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0911
		// 
		this.menuItem0911.Index = 10;
		this.menuItem0911.Text = "9.11 Reading and Writing Binary Data with SQL Server";
		this.menuItem0911.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0912
		// 
		this.menuItem0912.Index = 11;
		this.menuItem0912.Text = "9.12 Reading and Writing Binary Data with Oracle";
		this.menuItem0912.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0913
		// 
		this.menuItem0913.Index = 12;
		this.menuItem0913.Text = "9.13 Performing Batch Updates with a DataAdapter";
		this.menuItem0913.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem0914
		// 
		this.menuItem0914.Index = 13;
		this.menuItem0914.Text = "9.14 Refreshing a DataSet Automatically Using Extended Properties";
		this.menuItem0914.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem10
		// 
		this.menuItem10.Index = 9;
		this.menuItem10.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.menuItem1001,
																				   this.menuItem1002,
																				   this.menuItem1003,
																				   this.menuItem1004,
																				   this.menuItem1005,
																				   this.menuItem1006,
																				   this.menuItem1007,
																				   this.menuItem1008,
																				   this.menuItem1009,
																				   this.menuItem1010,
																				   this.menuItem1011,
																				   this.menuItem1012,
																				   this.menuItem1013,
																				   this.menuItem1014,
																				   this.menuItem1015,
																				   this.menuItem1016});
		this.menuItem10.Text = "Chapter 10";
		// 
		// menuItem1001
		// 
		this.menuItem1001.Index = 0;
		this.menuItem1001.Text = "10.1 Listing SQL Servers";
		this.menuItem1001.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1002
		// 
		this.menuItem1002.Index = 1;
		this.menuItem1002.Text = "10.2 Retrieving Database Schema Information from SQL Server";
		this.menuItem1002.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1003
		// 
		this.menuItem1003.Index = 2;
		this.menuItem1003.Text = "10.3 Retrieving Column Defaults Values from SQL Server";
		this.menuItem1003.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1004
		// 
		this.menuItem1004.Index = 3;
		this.menuItem1004.Text = "10.4 Determining the Length of Columns in a SQL Server Table";
		this.menuItem1004.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1005
		// 
		this.menuItem1005.Index = 4;
		this.menuItem1005.Text = "10.5 Counting Records";
		this.menuItem1005.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1006
		// 
		this.menuItem1006.Index = 5;
		this.menuItem1006.Text = "10.6 Creating a New Access Database";
		this.menuItem1006.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1007
		// 
		this.menuItem1007.Index = 6;
		this.menuItem1007.Text = "10.7 Creating a New SQL Server Database";
		this.menuItem1007.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1008
		// 
		this.menuItem1008.Index = 7;
		this.menuItem1008.Text = "10.8 Add Tables to a Database";
		this.menuItem1008.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1009
		// 
		this.menuItem1009.Index = 8;
		this.menuItem1009.Text = "10.9 Getting a SQL Server Query Plan";
		this.menuItem1009.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1010
		// 
		this.menuItem1010.Index = 9;
		this.menuItem1010.Text = "10.10 Compacting an Access Database";
		this.menuItem1010.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1011
		// 
		this.menuItem1011.Index = 10;
		this.menuItem1011.Text = "10.11 Creating DataSet Relationships from SQL Server Relationships";
		this.menuItem1011.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1012
		// 
		this.menuItem1012.Index = 11;
		this.menuItem1012.Text = "10.12 Getting SQL Server Column Metadata Without Returning Data";
		this.menuItem1012.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1013
		// 
		this.menuItem1013.Index = 12;
		this.menuItem1013.Text = "10.13 Listing Installed OLE DB Providers";
		this.menuItem1013.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1014
		// 
		this.menuItem1014.Index = 13;
		this.menuItem1014.Text = "10.14 Listing Tables in an Access Database";
		this.menuItem1014.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1015
		// 
		this.menuItem1015.Index = 14;
		this.menuItem1015.Text = "10.15 Creating a Table in the Database from a DataTable Schema ";
		this.menuItem1015.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// menuItem1016
		// 
		this.menuItem1016.Index = 15;
		this.menuItem1016.Text = "10.16 Listing Installed ODBC Drivers";
		this.menuItem1016.Click += new System.EventHandler(this.menuItem_Click);
		// 
		// coverPictureBox
		// 
		this.coverPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("coverPictureBox.Image")));
		this.coverPictureBox.Location = new System.Drawing.Point(68, 0);
		this.coverPictureBox.Name = "coverPictureBox";
		this.coverPictureBox.Size = new System.Drawing.Size(504, 661);
		this.coverPictureBox.TabIndex = 0;
		this.coverPictureBox.TabStop = false;
		// 
		// MainForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.BackColor = System.Drawing.Color.Gray;
		this.ClientSize = new System.Drawing.Size(632, 569);
		this.Controls.Add(this.coverPictureBox);
		this.Menu = this.mainMenu;
		this.Name = "MainForm";
		this.Text = "ADO.NET Cookbook - C# Solutions";
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new MainForm());
	}

	private void menuItem_Click(object sender, System.EventArgs e)
	{
		Form f = null;
		bool noCode = false;
		bool webCode = false;
		bool topicDeleted = false;

		// switch on the recipe expressed as an integer
		// the first half of the expression gets the chapter (main menu index),
		// converts to one-based, and multiplies by 100
		// the second half gets the section (sub menu index), converts to
		// one-based and adds to the chapter number above
		// so recipe 9.3 becomes 903 and recipe 10.11 becomes 1011
		switch((((MenuItem)((MenuItem)sender).Parent).Index + 1) * 100 +
			((MenuItem)sender).Index + 1)
		{
			case 101:
				f = new OdbcConnectForm();
				break;
			case 102:
				f = new ExcelForm();
				break;
			case 103:
				f = new AccessPasswordForm();
				break;
			case 104:
				f = new AccessSecureForm();
				break;
			case 105:
				noCode = true;
				break;
			case 106:
				f = new ConnectSqlServerIpAddressForm();
				break;
			case 107:
				f = new ConnectNamedInstanceForm();
				break;
			case 108:
				noCode = true;
				break;
			case 109:
				f = new ConnectOracleForm();
				break;
			case 110:
				f = new ConnectExchangeDataForm();
				break;
			case 111:
				f = new DatabaseIndependentCodeForm();
				break;
			case 112:
				noCode = true;
				break;
			case 113:
				f = new DataLinkDialogForm();
				break;
			case 114:
				noCode = true;
				break;
			case 115:
				noCode = true;
				break;
			case 116:
				f = new ConnectionPoolingOptionsForm();
				break;
			case 117:
				noCode = true;
				break;
			case 118:
				f = new ChangeDatabaseForm();
				break;
			case 119:
				f = new ConnectTextFileForm();
				break;

			case 201:
				f = new HierarchicalDataSetForm();
				break;
			case 202:
				f = new BuildDataSetProgramaticallyForm();
				break;
			case 203:
				noCode = true;
				break;
			case 204:
				f = new BatchSqlStatementForm();
				break;
			case 205:
				f = new WebServiceDataSourceForm();
				break;
			case 206:
				f = new AccessDeletedRowsForm();
				break;
			case 207:
				f = new DataReaderRowCountForm();
				break;
			case 208:
				noCode = true;
				break;
			case 209:
				f = new SpOutputValueDataReaderForm();
				break;
			case 210:
				f = new RaiserrorForm();
				break;
			case 211:
				f = new NoRecordTestForm();
				break;
			case 212:
				f = new SpReturnValueDataReaderForm();
				break;
			case 213:
				f = new ScalarFunctionForm();
				break;
			case 214:
				f = new NullParameterForm();
				break;
			case 215:
				f = new RetrieveProviderErrorsForm();
				break;
			case 216:
				f = new MappingsForm();
				break;
			case 217:
				f = new LookupColumnsForm();
				break;
			case 218:
				f = new TypedDataSetNamesForm();
				break;
			case 219:
				f = new TypedDataSetNullsForm();
				break;
			case 220:
				f = new OracleRefCursorsForm();
				break;
			case 221:
				f = new UsingParameterizedQueriesForm();
				break;
			case 222:
				f = new MessageQueueQueryForm();
				break;

			case 301:
				f = new FilterSortForm();
				break;
			case 302:
				f = new ExpressionColumnForm();
				break;
			case 303:
				f = new DataSetDifferenceForm();
				break;
			case 304:
				f = new NavigateDataRelationForm();
				break;
			case 305:
				webCode = true;
				break;
			case 306:
				f = new CombiningDataFromMultipleDatabasesForm();
				break;
			case 307:
				f = new ChildAggregateForm();
				break;
			case 308:
				f = new FindDataTableRowsForm();
				break;
			case 309:
				f = new FindDataViewRowsForm();
				break;
			case 310:
				f = new DataViewTopNSelectForm();
				break;
			case 311:
				f = new TypedDataRowFromDataViewForm();
				break;
			case 312:
				f = new FilterNullValuesForm();
				break;
			case 313:
				f = new ComputeForm();
				break;
			case 314:
				f = new ShapeForm();
				break;

			case 401:
				f = new AutoIncrementWithoutConflictForm();
				break;
			case 402:
				f = new IdentityValueForm();
				break;
			case 403:
				f = new MsAccessAutonumberValueForm();
				break;
			case 404:
				f = new OracleSequenceValuesForm();
				break;
			case 405:
				f = new AddParentChildAutoIncrementForm();
				break;
			case 406:
				f = new AddGuidPKRecordForm();
				break;
			case 407:
				f = new UpdateDataFromDifferentDataSourceForm();
				break;
			case 408:
				f = new UpdatePrimaryKeyForm();
				break;
			case 409:
				f = new SpParameterForm();
				break;
			case 410:
				f = new UpdateManyToManyRelationshipForm();
				break;
			case 411:
				f = new UpdateServerThroughWebServiceForm();
				break;
			case 412:
				f = new RemotingForm();
				break;
			case 413:
				f = new MessageQueueUpdateForm();
				break;
			case 414:
				f = new CommandBuilderKeywordConflictForm();
				break;
		
			case 501:
				f = new CopyRowsBetweenTablesForm();
				break;
			case 502:
				f = new CopyTablesBetweenDataSetsForm();
				break;
			case 503:
				f = new ConvertDataReaderToDataSetForm();
				break;
			case 504:
				f = new SerializeForm();
				break;
			case 505:
				f = new DeserializeForm();
				break;
			case 506:
				f = new MergingDataForm();
				break;
			case 507:
				f = new SecureTransmissionForm();
				break;
			case 508:
				webCode = true;
				break;
			case 509:
				f = new AdoRecordsetForm();
				break;
			case 510:
				f = new ConvertDataSetToAdoRecordsetForm();
				break;
			case 511:
				f = new AdoGetStringForm();
				break;
			case 512:
				f = new AdoGetRowsForm();
				break;

			case 601:
				f = new AutoTransactionForm();
				break;
			case 602:
				f = new ManualTransactionForm();
				break;
			case 603:
				f = new NestedManualTransactionForm();
				break;
			case 604:
				f = new DbmsTransactionForm();
				break;
			case 605:
				f = new TransactionDataAdapterForm();
				break;
			case 606:
				f = new ReferentialIntegrityUpdateLogicForm();
				break;
			case 607:
				f = new EnforceBusinessRulesWithColumnExpressionsForm();
				break;
			case 608:
				f = new MultiColumnConstraintAndRelationForm();
				break;
			case 609:
				f = new ConstraintForm();
				break;
			case 610:
				f = new RowversionForm();
				break;
			case 611:
				f = new ResolveDataConflictsForm();
				break;
			case 612:
				f = new TransactionIsolationLevelsForm();
				break;
			case 613:
				f = new PessimisticUpdatesForm();
				break;
			case 614:
				f = new UsingLockingHintsForPessimisticLockingForm();
				break;

			case 701:
				webCode = true;
				break;
			case 702:
				webCode = true;
				break;
			case 703:
				webCode = true;
				break;
			case 704:
				webCode = true;
				break;
			case 705:
				webCode = true;
				break;
			case 706:
				webCode = true;
				break;
			case 707:
				webCode = true;
				break;
			case 708:
				f = new DisplayDatabaseImageForm();
				break;
			case 709:
				f = new RadioButtonForm();
				break;
			case 710:
				f = new CustomColumnsInDataGridForm();
				break;
			case 711:
				f = new ComboBoxForm();
				break;
			case 712:
				f = new HierarchicalDataGridForm();
				break;
			case 713:
				f = new DisplayMsAccessImageForm();
				break;
			case 714:
				f = new ControlDataEditWithDataViewForm();
				break;
			case 715:
				f = new SearchDataGridForm();
				break;
			case 716:
				f = new CrystalReportsForm();
				break;
			case 717:
				f = new UsingDesignTimeFeauresWithComponentsForm();
				break;

			case 801:
				f = new XsdSchemaFileForm();
				break;
			case 802:
				f = new XmlFileForm();
				break;
			case 803:
				f = new SyncDataSetWithXmlDocForm();
				break;
			case 804:
				f = new StoreXmlFieldForm();
				break;
			case 805:
				f = new ReadXmlDirectForm();
				break;
			case 806:
				f = new XPathQueryForm();
				break;
			case 807:
				f = new XslTransformForm();
				break;
			case 808:
				f = new XmlDiffgramForm();
				break;
			case 809:
				f = new XmlElementsOrAttributesForm();
				break;
			case 810:
				f = new UsingXmlTemplateQueriesForm();
				break;
			case 811:
				f = new StoredProcedureMultipleRowsForm();
				break;

			case 901:
				f = new AsynchronousFillForm();
				break;
			case 902:
				f = new AsynchronousFillCancelForm();
				break;
			case 903:
				webCode = true;
				break;
			case 904:
				f = new ImprovePagingPerformanceForm();
				break;
			case 905:
				f = new BulkInsertForm();
				break;
			case 906:
				f = new DataReaderPerformanceForm();
				break;
			case 907:
				f = new DataReaderColumnOrdinalForm();
				break;
			case 908:
				noCode = true;
				break;
			case 909:
				f = new DataSetFillPerformanceForm();
				break;
			case 910:
				f = new ExecuteScalarForm();
				break;
			case 911:
				f = new BinaryDataForm();
				break;
			case 912:
				f = new ReadWriteBinaryDataFromOracleForm();
				break;
			case 913:
				f = new CustomAdapterBatchUpdateForm();
				break;
			case 914:
				f = new AutomaticRefreshDataSetForm();
				break;

			case 1001:
				f = new ServerListForm();
				break;
			case 1002:
				f = new DatabaseSchemaForm();
				break;
			case 1003:
				f = new ColumnDefaultsForm();
				break;
			case 1004:
				f = new ColumnSchemaForm();
				break;
			case 1005:
				f = new CountRecordForm();
				break;
			case 1006:
				f = new CreateAccessDatabaseForm();
				break;
			case 1007:
				f = new CreateServerDatabaseForm();
				break;
			case 1008:
				f = new AddTableToDatabaseForm();
				break;
			case 1009:
				f = new ShowPlanForm();
				break;
			case 1010:
				f = new CompactAccessForm();
				break;
			case 1011:
				f = new AutoDataRelationForm();
				break;
			case 1012:
				f = new ColumnSchemaSPForm();
				break;
			case 1013:
				f = new OleDbProvidersForm();
				break;
			case 1014:
				f = new ListAccessTablesForm();
				break;
			case 1015:
				f = new CreateDatabaseTableFromDataTableSchemaForm();
				break;
			case 1016:
				f = new OdbcDriversForm();
				break;
		}

		if(f != null)
		{
			Cursor.Current = Cursors.WaitCursor;
			f.Show();
			Cursor.Current = Cursors.Default;
		}
		else if(noCode)
			MessageBox.Show("No code sample required for this topic.", ((MenuItem)sender).Text,
				MessageBoxButtons.OK, MessageBoxIcon.Information);			
		else if(webCode)
			MessageBox.Show("Code sample for this topic in ASP.NET samples.", ((MenuItem)sender).Text,
				MessageBoxButtons.OK, MessageBoxIcon.Information);						
		else if(topicDeleted)
			MessageBox.Show("This topic has been deleted.", ((MenuItem)sender).Text,
				MessageBoxButtons.OK, MessageBoxIcon.Information);						
	}
}