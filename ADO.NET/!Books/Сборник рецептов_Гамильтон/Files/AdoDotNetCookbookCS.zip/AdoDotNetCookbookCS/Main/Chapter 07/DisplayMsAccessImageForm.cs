using System;
using System.Configuration;
using System.Drawing;
using System.Windows.Forms;

using System.IO;
using System.Data;
using System.Data.OleDb;

public class DisplayMsAccessImageForm : System.Windows.Forms.Form
{
	private const int MSACCESSIMAGEOFFSET = 78;

	private DataSet ds;
	private OleDbDataAdapter da;

	private BindingManagerBase bm;

	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.Button moveFirstButton;
	private System.Windows.Forms.Button movePreviousButton;
	private System.Windows.Forms.Button moveLastButton;
	private System.Windows.Forms.Button moveNextButton;
	private System.Windows.Forms.PictureBox picturePictureBox;
	private System.Windows.Forms.TextBox categoryIdTextBox;
	private System.Windows.Forms.TextBox categoryNameTextBox;
	private System.Windows.Forms.TextBox descriptionTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DisplayMsAccessImageForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.label1 = new System.Windows.Forms.Label();
		this.categoryIdTextBox = new System.Windows.Forms.TextBox();
		this.categoryNameTextBox = new System.Windows.Forms.TextBox();
		this.label2 = new System.Windows.Forms.Label();
		this.descriptionTextBox = new System.Windows.Forms.TextBox();
		this.label3 = new System.Windows.Forms.Label();
		this.picturePictureBox = new System.Windows.Forms.PictureBox();
		this.moveFirstButton = new System.Windows.Forms.Button();
		this.movePreviousButton = new System.Windows.Forms.Button();
		this.moveLastButton = new System.Windows.Forms.Button();
		this.moveNextButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.TabIndex = 0;
		this.label1.Text = "Category ID:";
		// 
		// categoryIdTextBox
		// 
		this.categoryIdTextBox.Location = new System.Drawing.Point(112, 8);
		this.categoryIdTextBox.Name = "categoryIdTextBox";
		this.categoryIdTextBox.ReadOnly = true;
		this.categoryIdTextBox.TabIndex = 1;
		this.categoryIdTextBox.Text = "";
		// 
		// categoryNameTextBox
		// 
		this.categoryNameTextBox.Location = new System.Drawing.Point(112, 32);
		this.categoryNameTextBox.Name = "categoryNameTextBox";
		this.categoryNameTextBox.ReadOnly = true;
		this.categoryNameTextBox.TabIndex = 3;
		this.categoryNameTextBox.Text = "";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 32);
		this.label2.Name = "label2";
		this.label2.TabIndex = 2;
		this.label2.Text = "Name:";
		// 
		// descriptionTextBox
		// 
		this.descriptionTextBox.Location = new System.Drawing.Point(8, 72);
		this.descriptionTextBox.Multiline = true;
		this.descriptionTextBox.Name = "descriptionTextBox";
		this.descriptionTextBox.ReadOnly = true;
		this.descriptionTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.descriptionTextBox.Size = new System.Drawing.Size(200, 96);
		this.descriptionTextBox.TabIndex = 5;
		this.descriptionTextBox.Text = "";
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(8, 56);
		this.label3.Name = "label3";
		this.label3.TabIndex = 4;
		this.label3.Text = "Description:";
		// 
		// picturePictureBox
		// 
		this.picturePictureBox.Location = new System.Drawing.Point(224, 8);
		this.picturePictureBox.Name = "picturePictureBox";
		this.picturePictureBox.Size = new System.Drawing.Size(200, 200);
		this.picturePictureBox.TabIndex = 6;
		this.picturePictureBox.TabStop = false;
		// 
		// moveFirstButton
		// 
		this.moveFirstButton.Location = new System.Drawing.Point(40, 184);
		this.moveFirstButton.Name = "moveFirstButton";
		this.moveFirstButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
		this.moveFirstButton.Size = new System.Drawing.Size(32, 23);
		this.moveFirstButton.TabIndex = 24;
		this.moveFirstButton.Text = ">>";
		this.moveFirstButton.Click += new System.EventHandler(this.moveFirstButton_Click);
		// 
		// movePreviousButton
		// 
		this.movePreviousButton.Location = new System.Drawing.Point(80, 184);
		this.movePreviousButton.Name = "movePreviousButton";
		this.movePreviousButton.Size = new System.Drawing.Size(32, 23);
		this.movePreviousButton.TabIndex = 25;
		this.movePreviousButton.Text = "<";
		this.movePreviousButton.Click += new System.EventHandler(this.movePreviousButton_Click);
		// 
		// moveLastButton
		// 
		this.moveLastButton.Location = new System.Drawing.Point(160, 184);
		this.moveLastButton.Name = "moveLastButton";
		this.moveLastButton.Size = new System.Drawing.Size(32, 23);
		this.moveLastButton.TabIndex = 27;
		this.moveLastButton.Text = ">>";
		this.moveLastButton.Click += new System.EventHandler(this.moveLastButton_Click);
		// 
		// moveNextButton
		// 
		this.moveNextButton.Location = new System.Drawing.Point(120, 184);
		this.moveNextButton.Name = "moveNextButton";
		this.moveNextButton.Size = new System.Drawing.Size(32, 23);
		this.moveNextButton.TabIndex = 26;
		this.moveNextButton.Text = ">";
		this.moveNextButton.Click += new System.EventHandler(this.moveNextButton_Click);
		// 
		// DisplayMsAccessImageForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(428, 222);
		this.Controls.Add(this.moveLastButton);
		this.Controls.Add(this.moveNextButton);
		this.Controls.Add(this.movePreviousButton);
		this.Controls.Add(this.moveFirstButton);
		this.Controls.Add(this.picturePictureBox);
		this.Controls.Add(this.descriptionTextBox);
		this.Controls.Add(this.label3);
		this.Controls.Add(this.categoryNameTextBox);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.categoryIdTextBox);
		this.Controls.Add(this.label1);
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
		this.MaximizeBox = false;
		this.Name = "DisplayMsAccessImageForm";
		this.Text = "7.13 DisplayMsAccessImageForm";
		this.Load += new System.EventHandler(this.DisplayMsAccessImageForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void DisplayMsAccessImageForm_Load(object sender, System.EventArgs e)
	{
		// create the DataSet
		ds = new DataSet();

		// create the DataAdapter and retrieve the Categories table
		String selectCommand = "SELECT CategoryID, CategoryName, Description FROM Categories";
		da = new OleDbDataAdapter(selectCommand, ConfigurationSettings.AppSettings["MsAccess_ConnectString"]);	
		da.FillSchema(ds, SchemaType.Source, "Categories");
		da.Fill(ds, "Categories");

		// bind table fields to controls
		categoryIdTextBox.DataBindings.Add("Text", ds, "Categories.CategoryID");
		categoryNameTextBox.DataBindings.Add("Text", ds, "Categories.CategoryName");
		descriptionTextBox.DataBindings.Add("Text", ds, "Categories.Description"); 

		// get the binding manager base for the parent table
		bm = BindingContext[ds, "Categories"];
		// update the image in response to each record reposition
		bm.PositionChanged += new EventHandler(bm_PositionChanged);
		// update the display for the first record
		bm_PositionChanged(null, null);
	}

	private void bm_PositionChanged(Object sender, EventArgs e)
	{
		// refresh the photo displayed when the current record changes

		// get the new CategoryID using the BindingManager
		int categoryId = (int)ds.Tables["Categories"].Rows[bm.Position]["CategoryID"];

		// create a connection
		OleDbConnection conn = new OleDbConnection(ConfigurationSettings.AppSettings["MsAccess_ConnectString"]);
		// create a command to retrieve the category photo
		String sqlText = "SELECT Picture FROM Categories WHERE CategoryID=" + categoryId;
		OleDbCommand cmd = new OleDbCommand(sqlText, conn);

		// retrieve the image from the database
		conn.Open();
		Byte[] image = (Byte[])cmd.ExecuteScalar();
		// write to a stream removing the image header
		MemoryStream ms = new MemoryStream();
		ms.Write(image, MSACCESSIMAGEOFFSET, image.Length - MSACCESSIMAGEOFFSET);
		conn.Close();

		// load the image into the PictureBox from the stream
		picturePictureBox.Image = Image.FromStream(ms);
		ms.Close();
	}

	private void moveFirstButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = 0;
	}

	private void movePreviousButton_Click(object sender, System.EventArgs e)
	{
		bm.Position -= 1;
	}

	private void moveNextButton_Click(object sender, System.EventArgs e)
	{
		bm.Position += 1;
	}

	private void moveLastButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = bm.Count - 1;
	}
}