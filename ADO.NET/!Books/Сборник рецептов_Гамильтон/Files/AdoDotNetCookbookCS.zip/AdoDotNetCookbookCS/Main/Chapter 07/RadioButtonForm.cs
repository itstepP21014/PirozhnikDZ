using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class RadioButtonForm : System.Windows.Forms.Form
{
	private const String TABLENAME = "TBL0709";

	private DataSet ds;
	private SqlDataAdapter da;

	private BindingManagerBase bm;

	private System.Windows.Forms.RadioButton value1RadioButton;
	private System.Windows.Forms.RadioButton value2RadioButton;
	private System.Windows.Forms.RadioButton value3RadioButton;
	private System.Windows.Forms.Button updateButton;
	private System.Windows.Forms.Button moveLastButton;
	private System.Windows.Forms.Button moveNextButton;
	private System.Windows.Forms.Button movePreviousButton;
	private System.Windows.Forms.Button moveFirstButton;
	private System.Windows.Forms.Label label4;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox field1TextBox;
	private System.Windows.Forms.TextBox idTextBox;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.GroupBox radioButtonGroupBox;
	private System.Windows.Forms.TextBox radioButtonItemIdTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public RadioButtonForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.radioButtonGroupBox = new System.Windows.Forms.GroupBox();
		this.value3RadioButton = new System.Windows.Forms.RadioButton();
		this.value2RadioButton = new System.Windows.Forms.RadioButton();
		this.value1RadioButton = new System.Windows.Forms.RadioButton();
		this.updateButton = new System.Windows.Forms.Button();
		this.moveLastButton = new System.Windows.Forms.Button();
		this.moveNextButton = new System.Windows.Forms.Button();
		this.movePreviousButton = new System.Windows.Forms.Button();
		this.moveFirstButton = new System.Windows.Forms.Button();
		this.label4 = new System.Windows.Forms.Label();
		this.label1 = new System.Windows.Forms.Label();
		this.field1TextBox = new System.Windows.Forms.TextBox();
		this.idTextBox = new System.Windows.Forms.TextBox();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.label3 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.radioButtonItemIdTextBox = new System.Windows.Forms.TextBox();
		this.radioButtonGroupBox.SuspendLayout();
		this.SuspendLayout();
		// 
		// radioButtonGroupBox
		// 
		this.radioButtonGroupBox.Controls.Add(this.value3RadioButton);
		this.radioButtonGroupBox.Controls.Add(this.value2RadioButton);
		this.radioButtonGroupBox.Controls.Add(this.value1RadioButton);
		this.radioButtonGroupBox.Location = new System.Drawing.Point(112, 40);
		this.radioButtonGroupBox.Name = "radioButtonGroupBox";
		this.radioButtonGroupBox.Size = new System.Drawing.Size(168, 96);
		this.radioButtonGroupBox.TabIndex = 1;
		this.radioButtonGroupBox.TabStop = false;
		this.radioButtonGroupBox.Text = "Radio Group";
		// 
		// value3RadioButton
		// 
		this.value3RadioButton.Location = new System.Drawing.Point(8, 64);
		this.value3RadioButton.Name = "value3RadioButton";
		this.value3RadioButton.TabIndex = 2;
		this.value3RadioButton.Tag = "3";
		this.value3RadioButton.Text = "Value 3";
		// 
		// value2RadioButton
		// 
		this.value2RadioButton.Location = new System.Drawing.Point(8, 40);
		this.value2RadioButton.Name = "value2RadioButton";
		this.value2RadioButton.TabIndex = 1;
		this.value2RadioButton.Tag = "2";
		this.value2RadioButton.Text = "Value 2";
		// 
		// value1RadioButton
		// 
		this.value1RadioButton.Location = new System.Drawing.Point(8, 16);
		this.value1RadioButton.Name = "value1RadioButton";
		this.value1RadioButton.TabIndex = 0;
		this.value1RadioButton.Tag = "1";
		this.value1RadioButton.Text = "Value 1";
		// 
		// updateButton
		// 
		this.updateButton.Location = new System.Drawing.Point(200, 184);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 23;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// moveLastButton
		// 
		this.moveLastButton.Location = new System.Drawing.Point(136, 184);
		this.moveLastButton.Name = "moveLastButton";
		this.moveLastButton.Size = new System.Drawing.Size(32, 23);
		this.moveLastButton.TabIndex = 22;
		this.moveLastButton.Text = ">>";
		this.moveLastButton.Click += new System.EventHandler(this.moveLastButton_Click);
		// 
		// moveNextButton
		// 
		this.moveNextButton.Location = new System.Drawing.Point(96, 184);
		this.moveNextButton.Name = "moveNextButton";
		this.moveNextButton.Size = new System.Drawing.Size(32, 23);
		this.moveNextButton.TabIndex = 21;
		this.moveNextButton.Text = ">";
		this.moveNextButton.Click += new System.EventHandler(this.moveNextButton_Click);
		// 
		// movePreviousButton
		// 
		this.movePreviousButton.Location = new System.Drawing.Point(56, 184);
		this.movePreviousButton.Name = "movePreviousButton";
		this.movePreviousButton.Size = new System.Drawing.Size(32, 23);
		this.movePreviousButton.TabIndex = 20;
		this.movePreviousButton.Text = "<";
		this.movePreviousButton.Click += new System.EventHandler(this.movePreviousButton_Click);
		// 
		// moveFirstButton
		// 
		this.moveFirstButton.Location = new System.Drawing.Point(16, 184);
		this.moveFirstButton.Name = "moveFirstButton";
		this.moveFirstButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
		this.moveFirstButton.Size = new System.Drawing.Size(32, 23);
		this.moveFirstButton.TabIndex = 19;
		this.moveFirstButton.Text = ">>";
		this.moveFirstButton.Click += new System.EventHandler(this.moveFirstButton_Click);
		// 
		// label4
		// 
		this.label4.Location = new System.Drawing.Point(8, 224);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(100, 16);
		this.label4.TabIndex = 18;
		this.label4.Text = "Messages:";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(10, 9);
		this.label1.Name = "label1";
		this.label1.TabIndex = 17;
		this.label1.Text = "ID:";
		// 
		// field1TextBox
		// 
		this.field1TextBox.Location = new System.Drawing.Point(112, 144);
		this.field1TextBox.Name = "field1TextBox";
		this.field1TextBox.Size = new System.Drawing.Size(168, 20);
		this.field1TextBox.TabIndex = 16;
		this.field1TextBox.Text = "";
		// 
		// idTextBox
		// 
		this.idTextBox.Location = new System.Drawing.Point(114, 9);
		this.idTextBox.Name = "idTextBox";
		this.idTextBox.ReadOnly = true;
		this.idTextBox.TabIndex = 14;
		this.idTextBox.Text = "";
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 240);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(268, 64);
		this.resultTextBox.TabIndex = 15;
		this.resultTextBox.Text = "";
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(8, 144);
		this.label3.Name = "label3";
		this.label3.TabIndex = 24;
		this.label3.Text = "Field 1:";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 48);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(88, 32);
		this.label2.TabIndex = 25;
		this.label2.Text = "Radio Button Item ID:";
		// 
		// radioButtonItemIdTextBox
		// 
		this.radioButtonItemIdTextBox.Location = new System.Drawing.Point(224, 8);
		this.radioButtonItemIdTextBox.Name = "radioButtonItemIdTextBox";
		this.radioButtonItemIdTextBox.Size = new System.Drawing.Size(48, 20);
		this.radioButtonItemIdTextBox.TabIndex = 26;
		this.radioButtonItemIdTextBox.TabStop = false;
		this.radioButtonItemIdTextBox.Text = "";
		// 
		// RadioButtonForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(288, 310);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.label3);
		this.Controls.Add(this.updateButton);
		this.Controls.Add(this.moveLastButton);
		this.Controls.Add(this.moveNextButton);
		this.Controls.Add(this.movePreviousButton);
		this.Controls.Add(this.moveFirstButton);
		this.Controls.Add(this.label4);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.field1TextBox);
		this.Controls.Add(this.idTextBox);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.radioButtonGroupBox);
		this.Controls.Add(this.radioButtonItemIdTextBox);
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
		this.MaximizeBox = false;
		this.Name = "RadioButtonForm";
		this.Text = "7.09 RadioButtonForm";
		this.Load += new System.EventHandler(this.RadioButtonForm_Load);
		this.radioButtonGroupBox.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion

	private void RadioButtonForm_Load(object sender, System.EventArgs e)
	{
		// create the DataSet
		ds = new DataSet();

		// create the select and update commands for the DataAdapter
		String selectCommand = "SELECT Id, RadioButtonItemId, Field1 FROM " + TABLENAME;
		String updateCommand = "UPDATE " + TABLENAME + " " +
			"SET RadioButtonItemId = @RadioButtonItemId, Field1=@Field1 " +
			"WHERE Id=@Id";

		// create the DataAdapter
		da = new SqlDataAdapter(selectCommand, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.UpdateCommand = new SqlCommand(updateCommand, da.SelectCommand.Connection);
		da.UpdateCommand.CommandType = CommandType.Text;
		da.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		da.UpdateCommand.Parameters.Add("@RadioButtonItemId", SqlDbType.Int, 0, "RadioButtonItemId");
		da.UpdateCommand.Parameters.Add("@Field1", SqlDbType.NVarChar, 50, "Field1");
		
		// retrieve the data and schema for the table
		da.FillSchema(ds, SchemaType.Source, TABLENAME);
		da.Fill(ds, TABLENAME);

		// bind all of the controls, including hidden text box, to the DataSet
		idTextBox.DataBindings.Add("Text", ds, TABLENAME + ".Id");
		radioButtonItemIdTextBox.Visible = false;
		radioButtonItemIdTextBox.DataBindings.Add("Text", ds, TABLENAME + ".RadioButtonItemId");
		field1TextBox.DataBindings.Add("Text", ds, TABLENAME +  ".Field1");

		// get the binding manager base for the table
		bm = BindingContext[ds, TABLENAME];
		// update the correct radio button in response to each record reposition
		bm.PositionChanged += new EventHandler(bm_PositionChanged);
		// update the display for the first record
		bm_PositionChanged(null, null);

	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		// retrieve the selected radio button based on the value in the
		// tag field to the hidden text box
		foreach(RadioButton rb in radioButtonGroupBox.Controls)
		{
			if (rb.Checked)
			{
				radioButtonItemIdTextBox.Text = rb.Tag.ToString();
				break;
			}
		}

		// end the current update and update the record using the DataAdapter
		bm.EndCurrentEdit();
		da.Update(ds.Tables[TABLENAME]);
	}

	private void bm_PositionChanged(Object sender, EventArgs e)
	{
		// refresh the checked radio button when the current record changes
		foreach(RadioButton rb in radioButtonGroupBox.Controls)
		{
			if (rb.Tag.ToString() == radioButtonItemIdTextBox.Text)
			{
				rb.Checked = true;
				break;
			}
		}
	}

	private void moveFirstButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = 0;
	}

	private void movePreviousButton_Click(object sender, System.EventArgs e)
	{
		bm.Position -= 1;
	}

	private void moveNextButton_Click(object sender, System.EventArgs e)
	{
		bm.Position += 1;
	}

	private void moveLastButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = bm.Count - 1;
	}
}