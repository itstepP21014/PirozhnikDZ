using System;
using System.Configuration;
using System.Windows.Forms;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

using System.Data;
using System.Data.SqlClient;

public class CrystalReportsForm : System.Windows.Forms.Form
{
	private CrystalDecisions.Windows.Forms.CrystalReportViewer crv;

	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox orderIdFromTextBox;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.TextBox orderIdToTextBox;
	private System.Windows.Forms.Button goButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public CrystalReportsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.crv = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
		this.label1 = new System.Windows.Forms.Label();
		this.orderIdFromTextBox = new System.Windows.Forms.TextBox();
		this.label2 = new System.Windows.Forms.Label();
		this.orderIdToTextBox = new System.Windows.Forms.TextBox();
		this.goButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// crv
		// 
		this.crv.ActiveViewIndex = -1;
		this.crv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.crv.Location = new System.Drawing.Point(8, 40);
		this.crv.Name = "crv";
		this.crv.ReportSource = null;
		this.crv.Size = new System.Drawing.Size(576, 320);
		this.crv.TabIndex = 0;
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(88, 16);
		this.label1.TabIndex = 1;
		this.label1.Text = "Order ID From:";
		// 
		// orderIdFromTextBox
		// 
		this.orderIdFromTextBox.Location = new System.Drawing.Point(96, 8);
		this.orderIdFromTextBox.Name = "orderIdFromTextBox";
		this.orderIdFromTextBox.TabIndex = 2;
		this.orderIdFromTextBox.Text = "";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(224, 8);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(72, 17);
		this.label2.TabIndex = 3;
		this.label2.Text = "Order ID To:";
		// 
		// orderIdToTextBox
		// 
		this.orderIdToTextBox.Location = new System.Drawing.Point(296, 8);
		this.orderIdToTextBox.Name = "orderIdToTextBox";
		this.orderIdToTextBox.TabIndex = 4;
		this.orderIdToTextBox.Text = "";
		// 
		// goButton
		// 
		this.goButton.Location = new System.Drawing.Point(432, 8);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 5;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// CrystalReportsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(592, 366);
		this.Controls.Add(this.goButton);
		this.Controls.Add(this.orderIdToTextBox);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.orderIdFromTextBox);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.crv);
		this.Name = "CrystalReportsForm";
		this.Text = "7.16 CrystalReportsForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		// get the user entered OrderID range
		int orderIdFrom, orderIdTo;
		try
		{
			orderIdFrom = Convert.ToInt32(orderIdFromTextBox.Text);
			orderIdTo = Convert.ToInt32(orderIdToTextBox.Text);
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message, "Dynamic Crystal Reports", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return;
		}

		Cursor.Current = Cursors.WaitCursor;

		// create a DataAdapter and fill the table
		String sqlText = "SELECT * FROM Orders " +
			"JOIN [Order Details] Order_Details ON Orders.OrderID = Order_Details.OrderID " +
			"WHERE Orders.OrderID BETWEEN " + orderIdFrom + " AND " + orderIdTo;
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable();
		da.Fill(dt);

		// create a new ReportDocument
		ReportDocument cr = new ReportDocument();
		// load the report
		cr.Load(ConfigurationSettings.AppSettings["Project_Directory"] + @"Chapter 07\OrderWithDetailsCrystalReport.rpt");
		// set the data source for the report
		cr.SetDataSource(dt);

		// set the report document for the report view
		crv.ReportSource = cr;

		Cursor.Current = Cursors.Default;
	}
}