using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class SearchDataGridForm : System.Windows.Forms.Form
{
	private DataView dv;
	private CurrencyManager cm;

	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox findTextBox;
	private System.Windows.Forms.Button findButton;
	private System.Windows.Forms.DataGrid findDataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public SearchDataGridForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.label1 = new System.Windows.Forms.Label();
		this.findTextBox = new System.Windows.Forms.TextBox();
		this.findButton = new System.Windows.Forms.Button();
		this.findDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.findDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(104, 23);
		this.label1.TabIndex = 0;
		this.label1.Text = "Find Customer ID:";
		// 
		// findTextBox
		// 
		this.findTextBox.Location = new System.Drawing.Point(112, 8);
		this.findTextBox.Name = "findTextBox";
		this.findTextBox.Size = new System.Drawing.Size(200, 20);
		this.findTextBox.TabIndex = 1;
		this.findTextBox.Text = "";
		// 
		// findButton
		// 
		this.findButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.findButton.Location = new System.Drawing.Point(408, 8);
		this.findButton.Name = "findButton";
		this.findButton.TabIndex = 2;
		this.findButton.Text = "Find";
		this.findButton.Click += new System.EventHandler(this.findButton_Click);
		// 
		// findDataGrid
		// 
		this.findDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.findDataGrid.DataMember = "";
		this.findDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.findDataGrid.Location = new System.Drawing.Point(8, 40);
		this.findDataGrid.Name = "findDataGrid";
		this.findDataGrid.Size = new System.Drawing.Size(476, 216);
		this.findDataGrid.TabIndex = 3;
		// 
		// SearchDataGridForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.findDataGrid);
		this.Controls.Add(this.findButton);
		this.Controls.Add(this.findTextBox);
		this.Controls.Add(this.label1);
		this.Name = "SearchDataGridForm";
		this.Text = "7.15 SearchDataGridForm";
		this.Load += new System.EventHandler(this.SearchDataGridForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.findDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void SearchDataGridForm_Load(object sender, System.EventArgs e)
	{
		// create the DataAdapter and load the Customers data in a table
		String sqlText = "SELECT * FROM Customers";
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable();
		da.Fill(dt);

		// create a view from the default view for the table
		dv = dt.DefaultView;
		dv.Sort = "CustomerID";

		// bind the view to the grid
		findDataGrid.DataSource = dv;

		// get the CurrencyManager for the DataView
		cm = (CurrencyManager)findDataGrid.BindingContext[dv];
	}

	private void findButton_Click(object sender, System.EventArgs e)
	{
		if(findTextBox.Text != "")
		{
			// find the customer
			int i = dv.Find(findTextBox.Text);
			if(i < 0)
				// a match was not found
				MessageBox.Show("No matching records found.", "Find", MessageBoxButtons.OK, MessageBoxIcon.Information);
			else
				// reposition the grid record using the CurrencyManager
				cm.Position = i;
		}
		else
		{
			MessageBox.Show("Enter find criteria.", "Find", MessageBoxButtons.OK, MessageBoxIcon.Question);
			findTextBox.Focus();
		}
	}
}