using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class HierarchicalDataGridForm : System.Windows.Forms.Form
{
	private DataSet ds;
	// private SqlDataAdapter daParent, daChild;
	private SqlDataAdapter daOrder, daOrderDetail;

	// table name constants
	private const String ORDERS_TABLE			= "Orders";
	private const String ORDERDETAILS_TABLE		= "OrderDetails";
	
	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants for Orders table
	public const String ORDERID_FIELD			= "OrderID";
	public const String CUSTOMERID_FIELD		= "CustomerID";
	public const String EMPLOYEEID_FIELD		= "EmployeeID";
	public const String ORDERDATE_FIELD			= "OrderDate";
	public const String REQUIREDDATE_FIELD		= "RequiredDate";
	public const String SHIPPEDDDATE_FIELD		= "ShippedDate";
	public const String SHIPVIA_FIELD			= "ShipVia";
	public const String FREIGHT_FIELD			= "Freight";
	public const String SHIPNAME_FIELD			= "ShipName";
	public const String SHIPADDRESS_FIELD		= "ShipAddress";
	public const String SHIPCITY_FIELD			= "ShipCity";
	public const String SHIPREGION_FIELD		= "ShipRegion";
	public const String SHIPPOSTALCODE_FIELD	= "ShipPostalCode";
	public const String SHIPCOUNTRY_FIELD		= "ShipCountry";

	// stored procedure name constants
	public const String DELETEORDERS_SP			= "DeleteOrders";
	public const String GETORDERS_SP			= "GetOrders";
	public const String INSERTORDERS_SP			= "InsertOrders";
	public const String UPDATEORDERS_SP			= "UpdateOrders";

	// stored procedure parameter name constants for Orders table
	public const String ORDERID_PARM			= "@OrderID";
	public const String CUSTOMERID_PARM			= "@CustomerID";
	public const String EMPLOYEEID_PARM			= "@EmployeeID";
	public const String ORDERDATE_PARM			= "@OrderDate";
	public const String REQUIREDDATE_PARM		= "@RequiredDate";
	public const String SHIPPEDDDATE_PARM		= "@ShippedDate";
	public const String SHIPVIA_PARM			= "@ShipVia";
	public const String FREIGHT_PARM			= "@Freight";
	public const String SHIPNAME_PARM			= "@ShipName";
	public const String SHIPADDRESS_PARM		= "@ShipAddress";
	public const String SHIPCITY_PARM			= "@ShipCity";
	public const String SHIPREGION_PARM			= "@ShipRegion";
	public const String SHIPPOSTALCODE_PARM		= "@ShipPostalCode";
	public const String SHIPCOUNTRY_PARM		= "@ShipCountry";

	// field name constants for OrderDetails table
	//public const String ORDERID_FIELD			= "OrderID";
	public const String PRODUCTID_FIELD			= "ProductID";
	public const String UNITPRICE_FIELD			= "UnitPrice";
	public const String QUANTITY_FIELD			= "Quantity";
	public const String DISCOUNT_FIELD			= "Discount";

	// stored procedure name constants
	public const String DELETEORDERDETAILS_SP	= "DeleteOrderDetails";
	public const String GETORDERDETAILS_SP		= "GetOrderDetails";
	public const String INSERTORDERDETAILS_SP	= "InsertOrderDetails";
	public const String UPDATEORDERDETAILS_SP	= "UpdateOrderDetails";

	// stored procedure parameter name constants for OrderDetails table
	//public const String ORDERID_PARM			= "@OrderID";
	public const String PRODUCTID_PARM			= "@ProductID";
	public const String UNITPRICE_PARM			= "@UnitPrice";
	public const String QUANTITY_PARM			= "@Quantity";
	public const String DISCOUNT_PARM			= "@Discount";

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button updateButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public HierarchicalDataGridForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.updateButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 0;
		// 
		// updateButton
		// 
		this.updateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.updateButton.Location = new System.Drawing.Point(408, 232);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 1;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// HierarchicalDataGridForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.updateButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "HierarchicalDataGridForm";
		this.Text = "7.12 HierarchicalDataGridForm";
		this.Load += new System.EventHandler(this.HierarchicalDataGridForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void HierarchicalDataGridForm_Load(object sender, System.EventArgs e)
	{
		ds = new DataSet();
		
		// fill the Order table and add it to the DataSet
		daOrder = new SqlDataAdapter(GETORDERS_SP, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		daOrder.SelectCommand.CommandType = CommandType.StoredProcedure;
		DataTable dtOrder = new DataTable(ORDERS_TABLE);
		daOrder.FillSchema(dtOrder, SchemaType.Source);
		daOrder.Fill(dtOrder);
		ds.Tables.Add(dtOrder);

		// fill the OrderDetails table with schema and add it to the DataSet
		daOrderDetail = new SqlDataAdapter(GETORDERDETAILS_SP, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		daOrderDetail.SelectCommand.CommandType = CommandType.StoredProcedure;
		DataTable dtOrderDetail = new DataTable(ORDERDETAILS_TABLE);
		daOrderDetail.FillSchema(dtOrderDetail, SchemaType.Source); 
		daOrderDetail.Fill(dtOrderDetail);
		ds.Tables.Add(dtOrderDetail);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
			ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
			true);

		// build the orders delete command
		SqlCommand deleteCommand = new SqlCommand(DELETEORDERS_SP, daOrder.SelectCommand.Connection);
		deleteCommand.CommandType = CommandType.StoredProcedure;
		SqlParameterCollection sqlParams = deleteCommand.Parameters;
		sqlParams.Add(ORDERID_PARM, SqlDbType.Int, 0, ORDERID_FIELD);
		daOrder.DeleteCommand = deleteCommand;

		// build the orders insert command
		SqlCommand insertCommand = new SqlCommand(INSERTORDERS_SP, daOrder.SelectCommand.Connection);
		insertCommand.CommandType = CommandType.StoredProcedure;
		sqlParams = insertCommand.Parameters;
		sqlParams.Add(ORDERID_PARM, SqlDbType.Int, 0, ORDERID_FIELD).Direction = ParameterDirection.Output;
		sqlParams.Add(CUSTOMERID_PARM, SqlDbType.NChar, 5, CUSTOMERID_FIELD);
		sqlParams.Add(EMPLOYEEID_PARM, SqlDbType.Int, 0, EMPLOYEEID_FIELD);
		sqlParams.Add(ORDERDATE_PARM, SqlDbType.DateTime, 0, ORDERDATE_FIELD);
		sqlParams.Add(REQUIREDDATE_PARM, SqlDbType.DateTime, 0, REQUIREDDATE_FIELD);
		sqlParams.Add(SHIPPEDDDATE_PARM, SqlDbType.DateTime, 0, SHIPPEDDDATE_FIELD);
		sqlParams.Add(SHIPVIA_PARM, SqlDbType.Int, 0, SHIPVIA_FIELD);
		sqlParams.Add(FREIGHT_PARM, SqlDbType.Money, 0, FREIGHT_FIELD);
		sqlParams.Add(SHIPNAME_PARM, SqlDbType.NVarChar, 40, SHIPNAME_FIELD);
		sqlParams.Add(SHIPADDRESS_PARM, SqlDbType.NVarChar, 60, SHIPADDRESS_FIELD);
		sqlParams.Add(SHIPCITY_PARM, SqlDbType.NVarChar, 15, SHIPCITY_FIELD);
		sqlParams.Add(SHIPREGION_PARM, SqlDbType.NVarChar, 15, SHIPREGION_FIELD);
		sqlParams.Add(SHIPPOSTALCODE_PARM, SqlDbType.NVarChar, 10, SHIPPOSTALCODE_FIELD);
		sqlParams.Add(SHIPCOUNTRY_PARM, SqlDbType.NVarChar, 15, SHIPCOUNTRY_FIELD);
		daOrder.InsertCommand = insertCommand;
		
		// build the orders update command
		SqlCommand updateCommand = new SqlCommand(UPDATEORDERS_SP, daOrder.SelectCommand.Connection);
		updateCommand.CommandType = CommandType.StoredProcedure;
		sqlParams = updateCommand.Parameters;
		sqlParams.Add(ORDERID_PARM, SqlDbType.Int, 0, ORDERID_FIELD);
		sqlParams.Add(CUSTOMERID_PARM, SqlDbType.NChar, 5, CUSTOMERID_FIELD);
		sqlParams.Add(EMPLOYEEID_PARM, SqlDbType.Int, 0, EMPLOYEEID_FIELD);
		sqlParams.Add(ORDERDATE_PARM, SqlDbType.DateTime, 0, ORDERDATE_FIELD);
		sqlParams.Add(REQUIREDDATE_PARM, SqlDbType.DateTime, 0, REQUIREDDATE_FIELD);
		sqlParams.Add(SHIPPEDDDATE_PARM, SqlDbType.DateTime, 0, SHIPPEDDDATE_FIELD);
		sqlParams.Add(SHIPVIA_PARM, SqlDbType.Int, 0, SHIPVIA_FIELD);
		sqlParams.Add(FREIGHT_PARM, SqlDbType.Money, 0, FREIGHT_FIELD);
		sqlParams.Add(SHIPNAME_PARM, SqlDbType.NVarChar, 40, SHIPNAME_FIELD);
		sqlParams.Add(SHIPADDRESS_PARM, SqlDbType.NVarChar, 60, SHIPADDRESS_FIELD);
		sqlParams.Add(SHIPCITY_PARM, SqlDbType.NVarChar, 15, SHIPCITY_FIELD);
		sqlParams.Add(SHIPREGION_PARM, SqlDbType.NVarChar, 15, SHIPREGION_FIELD);
		sqlParams.Add(SHIPPOSTALCODE_PARM, SqlDbType.NVarChar, 10, SHIPPOSTALCODE_FIELD);
		sqlParams.Add(SHIPCOUNTRY_PARM, SqlDbType.NVarChar, 15, SHIPCOUNTRY_FIELD);
		daOrder.UpdateCommand = updateCommand;

		// build the order details delete command
		deleteCommand = new SqlCommand(DELETEORDERDETAILS_SP, daOrderDetail.SelectCommand.Connection);
		deleteCommand.CommandType = CommandType.StoredProcedure;
		sqlParams = deleteCommand.Parameters;
		sqlParams.Add(ORDERID_PARM, SqlDbType.Int, 0, ORDERID_FIELD);
		sqlParams.Add(PRODUCTID_PARM, SqlDbType.Int, 0, PRODUCTID_FIELD);
		daOrderDetail.DeleteCommand = deleteCommand;

		// build the order details insert command
		insertCommand = new SqlCommand(INSERTORDERDETAILS_SP,  daOrderDetail.SelectCommand.Connection);
		insertCommand.CommandType = CommandType.StoredProcedure;        
		sqlParams = insertCommand.Parameters;
		sqlParams.Add(ORDERID_PARM, SqlDbType.Int, 0, ORDERID_FIELD);
		sqlParams.Add(PRODUCTID_PARM, SqlDbType.Int, 0, PRODUCTID_FIELD);
		sqlParams.Add(UNITPRICE_PARM, SqlDbType.Money, 0, UNITPRICE_FIELD);
		sqlParams.Add(QUANTITY_PARM, SqlDbType.SmallInt, 0, QUANTITY_FIELD);
		sqlParams.Add(DISCOUNT_PARM, SqlDbType.Real, 0, DISCOUNT_FIELD);
		daOrderDetail.InsertCommand = insertCommand;

		// build the order details update command
		updateCommand = new SqlCommand(UPDATEORDERDETAILS_SP,  daOrderDetail.SelectCommand.Connection);
		updateCommand.CommandType = CommandType.StoredProcedure;
		sqlParams = updateCommand.Parameters;
		sqlParams.Add(ORDERID_PARM, SqlDbType.Int, 0, ORDERID_FIELD);
		sqlParams.Add(PRODUCTID_PARM, SqlDbType.Int, 0, PRODUCTID_FIELD);
		sqlParams.Add(UNITPRICE_PARM, SqlDbType.Money, 0, UNITPRICE_FIELD);
		sqlParams.Add(QUANTITY_PARM, SqlDbType.SmallInt, 0, QUANTITY_FIELD);
		sqlParams.Add(DISCOUNT_PARM, SqlDbType.Real, 0, DISCOUNT_FIELD);
		daOrderDetail.UpdateCommand = updateCommand;

		// fill the parent and child table
		daOrder.Fill(dtOrder);
		daOrderDetail.Fill(dtOrderDetail);

		// bind the default view of the order table to the grid
		dataGrid.DataSource = dtOrder.DefaultView;
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		// update parent and child tables
		daOrderDetail.Update(ds.Tables[ORDERDETAILS_TABLE].Select(null, null, DataViewRowState.Deleted));
		daOrder.Update(ds.Tables[ORDERS_TABLE].Select(null, null, DataViewRowState.Deleted));
		daOrder.Update(ds.Tables[ORDERS_TABLE].Select(null, null, DataViewRowState.ModifiedCurrent));
		daOrder.Update(ds.Tables[ORDERS_TABLE].Select(null, null, DataViewRowState.Added));
		daOrderDetail.Update(ds.Tables[ORDERDETAILS_TABLE].Select(null, null, DataViewRowState.ModifiedCurrent));
		daOrderDetail.Update(ds.Tables[ORDERDETAILS_TABLE].Select(null, null, DataViewRowState.Added));
	}
}