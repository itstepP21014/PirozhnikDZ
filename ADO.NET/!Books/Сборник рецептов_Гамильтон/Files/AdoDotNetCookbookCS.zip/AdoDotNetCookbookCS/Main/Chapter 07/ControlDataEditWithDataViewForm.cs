using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class ControlDataEditWithDataViewForm : System.Windows.Forms.Form
{
	private DataView dv;

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.CheckBox allowDeleteCheckBox;
	private System.Windows.Forms.CheckBox allowEditCheckBox;
	private System.Windows.Forms.CheckBox allowInsertCheckBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ControlDataEditWithDataViewForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.allowDeleteCheckBox = new System.Windows.Forms.CheckBox();
		this.allowEditCheckBox = new System.Windows.Forms.CheckBox();
		this.allowInsertCheckBox = new System.Windows.Forms.CheckBox();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 32);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 224);
		this.dataGrid.TabIndex = 0;
		// 
		// allowDeleteCheckBox
		// 
		this.allowDeleteCheckBox.Checked = true;
		this.allowDeleteCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
		this.allowDeleteCheckBox.Location = new System.Drawing.Point(8, 0);
		this.allowDeleteCheckBox.Name = "allowDeleteCheckBox";
		this.allowDeleteCheckBox.Size = new System.Drawing.Size(88, 24);
		this.allowDeleteCheckBox.TabIndex = 1;
		this.allowDeleteCheckBox.Text = "Allow Delete";
		this.allowDeleteCheckBox.CheckedChanged += new System.EventHandler(this.allowDeleteCheckBox_CheckedChanged);
		// 
		// allowEditCheckBox
		// 
		this.allowEditCheckBox.Checked = true;
		this.allowEditCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
		this.allowEditCheckBox.Location = new System.Drawing.Point(104, 0);
		this.allowEditCheckBox.Name = "allowEditCheckBox";
		this.allowEditCheckBox.Size = new System.Drawing.Size(80, 24);
		this.allowEditCheckBox.TabIndex = 2;
		this.allowEditCheckBox.Text = "Allow Edit";
		this.allowEditCheckBox.CheckedChanged += new System.EventHandler(this.allowEditCheckBox_CheckedChanged);
		// 
		// allowInsertCheckBox
		// 
		this.allowInsertCheckBox.Checked = true;
		this.allowInsertCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
		this.allowInsertCheckBox.Location = new System.Drawing.Point(192, 0);
		this.allowInsertCheckBox.Name = "allowInsertCheckBox";
		this.allowInsertCheckBox.TabIndex = 3;
		this.allowInsertCheckBox.Text = "Allow Insert";
		this.allowInsertCheckBox.CheckedChanged += new System.EventHandler(this.allowInsertCheckBox_CheckedChanged);
		// 
		// ControlDataEditWithDataViewForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.allowInsertCheckBox);
		this.Controls.Add(this.allowEditCheckBox);
		this.Controls.Add(this.allowDeleteCheckBox);
		this.Controls.Add(this.dataGrid);
		this.Name = "ControlDataEditWithDataViewForm";
		this.Text = "7.14 ControlDataEditWithDataViewForm";
		this.Load += new System.EventHandler(this.ControlDataEditWithDataViewForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void ControlDataEditWithDataViewForm_Load(object sender, System.EventArgs e)
	{
		// fill the Order table
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dtOrders = new DataTable("Orders");
		da.FillSchema(dtOrders, SchemaType.Source);
		da.Fill(dtOrders);

		// create a view and bind it to the grid
		dv = new DataView(dtOrders);
		dataGrid.DataSource = dv;
	}

	private void allowDeleteCheckBox_CheckedChanged(object sender, System.EventArgs e)
	{
		dv.AllowDelete = allowDeleteCheckBox.Checked;
	}

	private void allowEditCheckBox_CheckedChanged(object sender, System.EventArgs e)
	{
		dv.AllowEdit = allowEditCheckBox.Checked;
	}

	private void allowInsertCheckBox_CheckedChanged(object sender, System.EventArgs e)
	{
		dv.AllowNew = allowInsertCheckBox.Checked;
	}
}