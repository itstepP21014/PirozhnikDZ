using System;
using System.Configuration;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

using System.Data;
using System.Data.SqlClient;

public class DisplayDatabaseImageForm : System.Windows.Forms.Form
{
	private DataSet ds;
	private SqlDataAdapter da;

	private BindingManagerBase bm;

	private System.Windows.Forms.Button moveLastButton;
	private System.Windows.Forms.Button moveNextButton;
	private System.Windows.Forms.Button movePreviousButton;
	private System.Windows.Forms.Button moveFirstButton;
	private System.Windows.Forms.PictureBox photoPictureBox;
	private System.Windows.Forms.TextBox lastNameTextBox;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.TextBox firstNameTextBox;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.TextBox employeeIdTextBox;
	private System.Windows.Forms.Label label1;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DisplayDatabaseImageForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.moveLastButton = new System.Windows.Forms.Button();
		this.moveNextButton = new System.Windows.Forms.Button();
		this.movePreviousButton = new System.Windows.Forms.Button();
		this.moveFirstButton = new System.Windows.Forms.Button();
		this.photoPictureBox = new System.Windows.Forms.PictureBox();
		this.lastNameTextBox = new System.Windows.Forms.TextBox();
		this.label3 = new System.Windows.Forms.Label();
		this.firstNameTextBox = new System.Windows.Forms.TextBox();
		this.label2 = new System.Windows.Forms.Label();
		this.employeeIdTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.SuspendLayout();
		// 
		// moveLastButton
		// 
		this.moveLastButton.Location = new System.Drawing.Point(160, 184);
		this.moveLastButton.Name = "moveLastButton";
		this.moveLastButton.Size = new System.Drawing.Size(32, 23);
		this.moveLastButton.TabIndex = 38;
		this.moveLastButton.Text = ">>";
		this.moveLastButton.Click += new System.EventHandler(this.moveLastButton_Click);
		// 
		// moveNextButton
		// 
		this.moveNextButton.Location = new System.Drawing.Point(120, 184);
		this.moveNextButton.Name = "moveNextButton";
		this.moveNextButton.Size = new System.Drawing.Size(32, 23);
		this.moveNextButton.TabIndex = 37;
		this.moveNextButton.Text = ">";
		this.moveNextButton.Click += new System.EventHandler(this.moveNextButton_Click);
		// 
		// movePreviousButton
		// 
		this.movePreviousButton.Location = new System.Drawing.Point(80, 184);
		this.movePreviousButton.Name = "movePreviousButton";
		this.movePreviousButton.Size = new System.Drawing.Size(32, 23);
		this.movePreviousButton.TabIndex = 36;
		this.movePreviousButton.Text = "<";
		this.movePreviousButton.Click += new System.EventHandler(this.movePreviousButton_Click);
		// 
		// moveFirstButton
		// 
		this.moveFirstButton.Location = new System.Drawing.Point(40, 184);
		this.moveFirstButton.Name = "moveFirstButton";
		this.moveFirstButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
		this.moveFirstButton.Size = new System.Drawing.Size(32, 23);
		this.moveFirstButton.TabIndex = 35;
		this.moveFirstButton.Text = ">>";
		this.moveFirstButton.Click += new System.EventHandler(this.moveFirstButton_Click);
		// 
		// photoPictureBox
		// 
		this.photoPictureBox.Location = new System.Drawing.Point(224, 8);
		this.photoPictureBox.Name = "photoPictureBox";
		this.photoPictureBox.Size = new System.Drawing.Size(200, 200);
		this.photoPictureBox.TabIndex = 34;
		this.photoPictureBox.TabStop = false;
		// 
		// lastNameTextBox
		// 
		this.lastNameTextBox.Location = new System.Drawing.Point(112, 56);
		this.lastNameTextBox.Name = "lastNameTextBox";
		this.lastNameTextBox.ReadOnly = true;
		this.lastNameTextBox.TabIndex = 33;
		this.lastNameTextBox.Text = "";
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(8, 56);
		this.label3.Name = "label3";
		this.label3.TabIndex = 32;
		this.label3.Text = "Last Name:";
		// 
		// firstNameTextBox
		// 
		this.firstNameTextBox.Location = new System.Drawing.Point(112, 32);
		this.firstNameTextBox.Name = "firstNameTextBox";
		this.firstNameTextBox.ReadOnly = true;
		this.firstNameTextBox.TabIndex = 31;
		this.firstNameTextBox.Text = "";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 32);
		this.label2.Name = "label2";
		this.label2.TabIndex = 30;
		this.label2.Text = "First Name:";
		// 
		// employeeIdTextBox
		// 
		this.employeeIdTextBox.Location = new System.Drawing.Point(112, 8);
		this.employeeIdTextBox.Name = "employeeIdTextBox";
		this.employeeIdTextBox.ReadOnly = true;
		this.employeeIdTextBox.TabIndex = 29;
		this.employeeIdTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.TabIndex = 28;
		this.label1.Text = "Employee ID:";
		// 
		// DisplayDatabaseImageForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(428, 222);
		this.Controls.Add(this.moveLastButton);
		this.Controls.Add(this.moveNextButton);
		this.Controls.Add(this.movePreviousButton);
		this.Controls.Add(this.moveFirstButton);
		this.Controls.Add(this.photoPictureBox);
		this.Controls.Add(this.lastNameTextBox);
		this.Controls.Add(this.label3);
		this.Controls.Add(this.firstNameTextBox);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.employeeIdTextBox);
		this.Controls.Add(this.label1);
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
		this.MaximizeBox = false;
		this.Name = "DisplayDatabaseImageForm";
		this.Text = "7.08 DisplayDatabaseImageForm";
		this.Load += new System.EventHandler(this.DisplayDatabaseImageForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void DisplayDatabaseImageForm_Load(object sender, System.EventArgs e)
	{
		// create the DataSet
		ds = new DataSet();

		// create the DataAdapter and retrieve the Employees table
		String selectCommand = "SELECT EmployeeID, LastName, FirstName FROM Employees";
		da = new SqlDataAdapter(selectCommand, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.FillSchema(ds, SchemaType.Source, "Employees");
		da.Fill(ds, "Employees");

		// bind several table fields to controls
		employeeIdTextBox.DataBindings.Add("Text", ds, "Employees.EmployeeID");
		lastNameTextBox.DataBindings.Add("Text", ds, "Employees.LastName");
		firstNameTextBox.DataBindings.Add("Text", ds, "Employees.FirstName");

		// get the binding manager base for the Employees table
		bm = BindingContext[ds, "Employees"];
		// update the image in response to each record reposition
		bm.PositionChanged += new EventHandler(bm_PositionChanged);
		// update the display for the first record
		bm_PositionChanged(null, null);
	}

	private void bm_PositionChanged(Object sender, EventArgs e)
	{
		// refresh the photo displayed when the current record changes

		// get the new EmployeeID using the BindingManager
		int employeeId = (int)ds.Tables["Employees"].Rows[bm.Position]["EmployeeID"];

		// create a connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// create a command to retrieve the employee photo
		String sqlText = "SELECT Photo FROM Employees WHERE EmployeeID=" + employeeId;
		SqlCommand cmd = new SqlCommand(sqlText, conn);

		// retrieve the employee photo to a stream
		conn.Open();
		Byte[] image = (Byte[])cmd.ExecuteScalar();;
		MemoryStream ms = new MemoryStream(image);
		conn.Close();

		// load the image into the PictureBox from the stream
		photoPictureBox.Image = Image.FromStream(ms);
		ms.Close();
	}

	private void moveFirstButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = 0;
	}

	private void movePreviousButton_Click(object sender, System.EventArgs e)
	{
		bm.Position -= 1;
	}

	private void moveNextButton_Click(object sender, System.EventArgs e)
	{
		bm.Position += 1;
	}

	private void moveLastButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = bm.Count-1;
	}
}