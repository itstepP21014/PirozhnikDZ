using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class ComboBoxForm : System.Windows.Forms.Form
{		
	private const String TABLENAME = "TBL0711";
	private const String TABLENAME_COMBOBOXSOURCE = "TBL0711_ComboBoxSource";
	private const String RELATIONNAME = "REL0711";

	private DataSet ds;
	private SqlDataAdapter da;

	private BindingManagerBase bm;

	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.ComboBox comboBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.TextBox idTextBox;
	private System.Windows.Forms.TextBox field1TextBox;
	private System.Windows.Forms.Label label4;
	private System.Windows.Forms.Button moveFirstButton;
	private System.Windows.Forms.Button movePreviousButton;
	private System.Windows.Forms.Button moveNextButton;
	private System.Windows.Forms.Button moveLastButton;
	private System.Windows.Forms.Button updateButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ComboBoxForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.comboBox = new System.Windows.Forms.ComboBox();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.idTextBox = new System.Windows.Forms.TextBox();
		this.field1TextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.label4 = new System.Windows.Forms.Label();
		this.moveFirstButton = new System.Windows.Forms.Button();
		this.movePreviousButton = new System.Windows.Forms.Button();
		this.moveNextButton = new System.Windows.Forms.Button();
		this.moveLastButton = new System.Windows.Forms.Button();
		this.updateButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// comboBox
		// 
		this.comboBox.Location = new System.Drawing.Point(112, 32);
		this.comboBox.Name = "comboBox";
		this.comboBox.Size = new System.Drawing.Size(168, 21);
		this.comboBox.TabIndex = 2;
		this.comboBox.SelectionChangeCommitted += new System.EventHandler(this.comboBox_SelectionChangeCommitted);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 200);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(266, 54);
		this.resultTextBox.TabIndex = 2;
		this.resultTextBox.Text = "";
		// 
		// idTextBox
		// 
		this.idTextBox.Location = new System.Drawing.Point(112, 8);
		this.idTextBox.Name = "idTextBox";
		this.idTextBox.ReadOnly = true;
		this.idTextBox.TabIndex = 1;
		this.idTextBox.Text = "";
		// 
		// field1TextBox
		// 
		this.field1TextBox.Location = new System.Drawing.Point(112, 56);
		this.field1TextBox.Name = "field1TextBox";
		this.field1TextBox.Size = new System.Drawing.Size(168, 20);
		this.field1TextBox.TabIndex = 4;
		this.field1TextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.TabIndex = 5;
		this.label1.Text = "ID:";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 32);
		this.label2.Name = "label2";
		this.label2.TabIndex = 6;
		this.label2.Text = "ComboBox Item:";
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(8, 56);
		this.label3.Name = "label3";
		this.label3.TabIndex = 7;
		this.label3.Text = "Field 1:";
		// 
		// label4
		// 
		this.label4.Location = new System.Drawing.Point(8, 184);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(100, 16);
		this.label4.TabIndex = 8;
		this.label4.Text = "Messages:";
		// 
		// moveFirstButton
		// 
		this.moveFirstButton.Location = new System.Drawing.Point(8, 88);
		this.moveFirstButton.Name = "moveFirstButton";
		this.moveFirstButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
		this.moveFirstButton.Size = new System.Drawing.Size(32, 23);
		this.moveFirstButton.TabIndex = 9;
		this.moveFirstButton.Text = ">>";
		this.moveFirstButton.Click += new System.EventHandler(this.moveFirstButton_Click);
		// 
		// movePreviousButton
		// 
		this.movePreviousButton.Location = new System.Drawing.Point(48, 88);
		this.movePreviousButton.Name = "movePreviousButton";
		this.movePreviousButton.Size = new System.Drawing.Size(32, 23);
		this.movePreviousButton.TabIndex = 10;
		this.movePreviousButton.Text = "<";
		this.movePreviousButton.Click += new System.EventHandler(this.movePreviousButton_Click);
		// 
		// moveNextButton
		// 
		this.moveNextButton.Location = new System.Drawing.Point(88, 88);
		this.moveNextButton.Name = "moveNextButton";
		this.moveNextButton.Size = new System.Drawing.Size(32, 23);
		this.moveNextButton.TabIndex = 11;
		this.moveNextButton.Text = ">";
		this.moveNextButton.Click += new System.EventHandler(this.moveNextButton_Click);
		// 
		// moveLastButton
		// 
		this.moveLastButton.Location = new System.Drawing.Point(128, 88);
		this.moveLastButton.Name = "moveLastButton";
		this.moveLastButton.Size = new System.Drawing.Size(32, 23);
		this.moveLastButton.TabIndex = 12;
		this.moveLastButton.Text = ">>";
		this.moveLastButton.Click += new System.EventHandler(this.moveLastButton_Click);
		// 
		// updateButton
		// 
		this.updateButton.Location = new System.Drawing.Point(200, 88);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 13;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// ComboBoxForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(286, 264);
		this.Controls.Add(this.updateButton);
		this.Controls.Add(this.moveLastButton);
		this.Controls.Add(this.moveNextButton);
		this.Controls.Add(this.movePreviousButton);
		this.Controls.Add(this.moveFirstButton);
		this.Controls.Add(this.label4);
		this.Controls.Add(this.label3);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.field1TextBox);
		this.Controls.Add(this.idTextBox);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.comboBox);
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
		this.MaximizeBox = false;
		this.Name = "ComboBoxForm";
		this.Text = "7.11 ComboBoxForm";
		this.Load += new System.EventHandler(this.ComboBoxForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void ComboBoxForm_Load(object sender, System.EventArgs e)
	{
		// create the DataSet
		ds = new DataSet();

		// create the select and update commands for the DataAdapter
		String selectCommand = "SELECT Id, ComboBoxItemId, Field1 FROM " + TABLENAME;
		String updateCommand = "UPDATE " + TABLENAME + " " +
			"SET ComboBoxItemId = @ComboBoxItemId, Field1 = @Field1 " +
			"WHERE Id = @Id";

		// create the DataAdapter
		da = new SqlDataAdapter(selectCommand, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.UpdateCommand = new SqlCommand(updateCommand, da.SelectCommand.Connection);
		da.UpdateCommand.CommandType = CommandType.Text;
		da.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		da.UpdateCommand.Parameters.Add("@ComboBoxItemId", SqlDbType.Int, 0, "ComboBoxItemId");
		da.UpdateCommand.Parameters.Add("@Field1", SqlDbType.NVarChar, 50, "Field1");
		
		// retrieve the data and schema for the table
		da.FillSchema(ds, SchemaType.Source, TABLENAME);
		da.Fill(ds, TABLENAME);

		// create and fill the schema for the ComboBox table
		String sqlText = "SELECT ComboBoxItemId, Description FROM " + TABLENAME_COMBOBOXSOURCE;
		SqlDataAdapter daCB = new SqlDataAdapter(sqlText, da.SelectCommand.Connection);
		DataTable comboBoxSourceTable = new DataTable(TABLENAME_COMBOBOXSOURCE);
		daCB.FillSchema(comboBoxSourceTable, SchemaType.Source);
		// add the instructions for the user as the first element
		comboBoxSourceTable.Rows.Add(new object[] {-1, "<Select>"});
		// fill the rest of the data for the ComboBox
		daCB.Fill(comboBoxSourceTable);

		// add the ComboBox source table to the DataSet
		ds.Tables.Add(comboBoxSourceTable);

		// relate the parent and ComboBox tables
		ds.Relations.Add(new DataRelation(RELATIONNAME,
			ds.Tables[TABLENAME_COMBOBOXSOURCE].Columns["ComboBoxItemId"],
			ds.Tables[TABLENAME].Columns["ComboBoxItemId"],
			true));

		// set up the ComboBox with the DataSet
		comboBox.DataSource = ds.Tables[TABLENAME_COMBOBOXSOURCE];
		comboBox.ValueMember = "ComboBoxItemId";
		comboBox.DisplayMember = "Description";

		// bind all of the controls to the DataSet
		idTextBox.DataBindings.Add("Text", ds, TABLENAME + ".Id");
		comboBox.DataBindings.Add("SelectedValue", ds, TABLENAME + ".ComboBoxItemId");
		field1TextBox.DataBindings.Add("Text", ds, TABLENAME +  ".Field1");

		// get the binding manager base for the parent table
		bm = BindingContext[ds, TABLENAME];
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		// end the current update and update the record using the DataAdapter
		bm.EndCurrentEdit();
		da.Update(ds.Tables[TABLENAME]);
	}

	private void comboBox_SelectionChangeCommitted(object sender, System.EventArgs e)
	{
		resultTextBox.Text="SelectedIndex = " + comboBox.SelectedIndex + Environment.NewLine +
			"SelectedValue = " + comboBox.SelectedValue + Environment.NewLine +
			"SelectedText = " + ((DataRowView)comboBox.Items[comboBox.SelectedIndex])["Description"];
	}

	private void moveFirstButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = 0;
	}

	private void movePreviousButton_Click(object sender, System.EventArgs e)
	{
		bm.Position -= 1;
	}

	private void moveNextButton_Click(object sender, System.EventArgs e)
	{
		bm.Position += 1;
	}

	private void moveLastButton_Click(object sender, System.EventArgs e)
	{
		bm.Position = bm.Count - 1;
	}
}