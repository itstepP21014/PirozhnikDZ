using System;

using System.Data;

public class UsingDesignTimeFeauresWithComponentsForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button updateButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public UsingDesignTimeFeauresWithComponentsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.updateButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 0;
		// 
		// updateButton
		// 
		this.updateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.updateButton.Location = new System.Drawing.Point(408, 232);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 1;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// UsingDesignTimeFeauresWithComponentsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.updateButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "UsingDesignTimeFeauresWithComponentsForm";
		this.Text = "7.17 UsingDesignTimeFeauresWithComponentsForm";
		this.Load += new System.EventHandler(this.UsingDesignTimeFeauresWithComponentsForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void UsingDesignTimeFeauresWithComponentsForm_Load(object sender, System.EventArgs e)
	{
		// bind the default of the table from the component to the grid
		Component0717 c = new Component0717();
		dataGrid.DataSource = c.MyDataTable.DefaultView;
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		// update the table to the data source using the component
		Component0717 c = new Component0717();
		c.Update(((DataView)dataGrid.DataSource).Table);
	}
}