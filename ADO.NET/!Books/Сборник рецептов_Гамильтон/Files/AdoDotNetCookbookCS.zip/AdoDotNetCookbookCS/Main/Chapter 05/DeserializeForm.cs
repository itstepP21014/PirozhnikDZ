using System;
using System.Windows.Forms;

using System.IO;
using System.Data;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Xml.Serialization;

public class DeserializeForm : System.Windows.Forms.Form
{
	private OpenFileDialog ofd;

	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Button fileDialogButton;
	private System.Windows.Forms.TextBox fileNameTextBox;
	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.RadioButton binaryRadioButton;
	private System.Windows.Forms.RadioButton soapRadioButton;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.RadioButton xmlSerializerRadioButton;
	private System.Windows.Forms.RadioButton xmlReadRadioButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DeserializeForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		ofd = new OpenFileDialog();
		ofd.InitialDirectory = System.IO.Path.GetTempPath();
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.label1 = new System.Windows.Forms.Label();
		this.fileDialogButton = new System.Windows.Forms.Button();
		this.fileNameTextBox = new System.Windows.Forms.TextBox();
		this.goButton = new System.Windows.Forms.Button();
		this.binaryRadioButton = new System.Windows.Forms.RadioButton();
		this.soapRadioButton = new System.Windows.Forms.RadioButton();
		this.xmlSerializerRadioButton = new System.Windows.Forms.RadioButton();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.xmlReadRadioButton = new System.Windows.Forms.RadioButton();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 112);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(100, 16);
		this.label1.TabIndex = 16;
		this.label1.Text = "Filename:";
		// 
		// fileDialogButton
		// 
		this.fileDialogButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.fileDialogButton.Location = new System.Drawing.Point(460, 128);
		this.fileDialogButton.Name = "fileDialogButton";
		this.fileDialogButton.Size = new System.Drawing.Size(24, 23);
		this.fileDialogButton.TabIndex = 15;
		this.fileDialogButton.Text = "...";
		this.fileDialogButton.Click += new System.EventHandler(this.fileDialogButton_Click);
		// 
		// fileNameTextBox
		// 
		this.fileNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.fileNameTextBox.Location = new System.Drawing.Point(8, 128);
		this.fileNameTextBox.Name = "fileNameTextBox";
		this.fileNameTextBox.Size = new System.Drawing.Size(444, 20);
		this.fileNameTextBox.TabIndex = 4;
		this.fileNameTextBox.Text = "";
		// 
		// goButton
		// 
		this.goButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.goButton.Location = new System.Drawing.Point(408, 8);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 5;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// binaryRadioButton
		// 
		this.binaryRadioButton.Location = new System.Drawing.Point(8, 80);
		this.binaryRadioButton.Name = "binaryRadioButton";
		this.binaryRadioButton.TabIndex = 3;
		this.binaryRadioButton.Text = "Binary";
		// 
		// soapRadioButton
		// 
		this.soapRadioButton.Location = new System.Drawing.Point(8, 56);
		this.soapRadioButton.Name = "soapRadioButton";
		this.soapRadioButton.TabIndex = 2;
		this.soapRadioButton.Text = "SOAP";
		// 
		// xmlSerializerRadioButton
		// 
		this.xmlSerializerRadioButton.Location = new System.Drawing.Point(8, 32);
		this.xmlSerializerRadioButton.Name = "xmlSerializerRadioButton";
		this.xmlSerializerRadioButton.TabIndex = 1;
		this.xmlSerializerRadioButton.Text = "XmlSerializer";
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 160);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 144);
		this.dataGrid.TabIndex = 17;
		// 
		// xmlReadRadioButton
		// 
		this.xmlReadRadioButton.Checked = true;
		this.xmlReadRadioButton.Location = new System.Drawing.Point(8, 8);
		this.xmlReadRadioButton.Name = "xmlReadRadioButton";
		this.xmlReadRadioButton.TabIndex = 0;
		this.xmlReadRadioButton.Text = "XmlRead";
		// 
		// DeserializeForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 310);
		this.Controls.Add(this.xmlReadRadioButton);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.fileDialogButton);
		this.Controls.Add(this.fileNameTextBox);
		this.Controls.Add(this.goButton);
		this.Controls.Add(this.binaryRadioButton);
		this.Controls.Add(this.soapRadioButton);
		this.Controls.Add(this.xmlSerializerRadioButton);
		this.Name = "DeserializeForm";
		this.Text = "5.05 DeserializeForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		// create and open the stream for deserializing
		Stream stream = null;
		try
		{
			stream = File.Open(fileNameTextBox.Text, FileMode.Open, FileAccess.Read);
		}
		catch(Exception ex)
		{
			MessageBox.Show(ex.Message, "Deserializing Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return;
		}

		// deserialize the DataSet from the stream
		DataSet ds = null;
		try
		{
			if (xmlReadRadioButton.Checked)
			{
				ds = new DataSet();
				ds.ReadXml(stream);
			}
			else if (xmlSerializerRadioButton.Checked)
			{
				XmlSerializer xs = new XmlSerializer(typeof(DataSet));
				ds = (DataSet)xs.Deserialize(stream);
			}
			else if(soapRadioButton.Checked)
			{
				SoapFormatter sf = new SoapFormatter();
				ds = (DataSet)sf.Deserialize(stream);
			}		
			else if(binaryRadioButton.Checked)
			{
				BinaryFormatter bf = new BinaryFormatter();
				ds = (DataSet)bf.Deserialize(stream);
			}
		}
		catch (System.Exception ex)
		{
			MessageBox.Show(ex.Message, "Deserializing Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return;
		}
		finally
		{
			stream.Close();
		}

		// bind the DataSet to the grid
		dataGrid.DataSource = ds.DefaultViewManager;

		MessageBox.Show("Deserialization complete.", "Deserializing Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
	}

	private void fileDialogButton_Click(object sender, System.EventArgs e)
	{
		// file dialog to save file
		if(xmlReadRadioButton.Checked || xmlSerializerRadioButton.Checked)
			ofd.Filter = "XML files (*.xml)|*.xml";
		else if(soapRadioButton.Checked)
			ofd.Filter = "SOAP files (*.soap)|*.soap";
		else if(binaryRadioButton.Checked)
			ofd.Filter = "Binary files (*.bin)|*.bin";

		ofd.Filter += "|All files (*.*)|*.*";
		ofd.FilterIndex = 0;

		if (ofd.ShowDialog() == DialogResult.OK)
			fileNameTextBox.Text = ofd.FileName;
	}
}