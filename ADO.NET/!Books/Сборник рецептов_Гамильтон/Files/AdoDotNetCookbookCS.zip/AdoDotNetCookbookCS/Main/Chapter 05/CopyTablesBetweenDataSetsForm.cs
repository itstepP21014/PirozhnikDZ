using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class CopyTablesBetweenDataSetsForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";
	private const String ORDERDATE_FIELD	= "OrderDate";
	private const String EMPLOYEEID_FIELD	= "EmployeeID";

	private DataSet dsSource;

	private System.Windows.Forms.DataGrid sourceDataGrid;
	private System.Windows.Forms.DataGrid destDataGrid;
	private System.Windows.Forms.Button copyButton;
	private System.Windows.Forms.RadioButton copyAllRadioButton;
	private System.Windows.Forms.RadioButton copySubsetRadioButton;
	private System.Windows.Forms.TextBox employeeIdTextBox;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public CopyTablesBetweenDataSetsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.sourceDataGrid = new System.Windows.Forms.DataGrid();
		this.destDataGrid = new System.Windows.Forms.DataGrid();
		this.copyButton = new System.Windows.Forms.Button();
		this.copyAllRadioButton = new System.Windows.Forms.RadioButton();
		this.copySubsetRadioButton = new System.Windows.Forms.RadioButton();
		this.employeeIdTextBox = new System.Windows.Forms.TextBox();
		((System.ComponentModel.ISupportInitialize)(this.sourceDataGrid)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.destDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// sourceDataGrid
		// 
		this.sourceDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.sourceDataGrid.CaptionText = "Source";
		this.sourceDataGrid.DataMember = "";
		this.sourceDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.sourceDataGrid.Location = new System.Drawing.Point(8, 8);
		this.sourceDataGrid.Name = "sourceDataGrid";
		this.sourceDataGrid.Size = new System.Drawing.Size(616, 192);
		this.sourceDataGrid.TabIndex = 0;
		// 
		// destDataGrid
		// 
		this.destDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.destDataGrid.CaptionText = "Destination";
		this.destDataGrid.DataMember = "";
		this.destDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.destDataGrid.Location = new System.Drawing.Point(8, 208);
		this.destDataGrid.Name = "destDataGrid";
		this.destDataGrid.Size = new System.Drawing.Size(616, 192);
		this.destDataGrid.TabIndex = 1;
		// 
		// copyButton
		// 
		this.copyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.copyButton.Location = new System.Drawing.Point(544, 408);
		this.copyButton.Name = "copyButton";
		this.copyButton.TabIndex = 2;
		this.copyButton.Text = "Copy";
		this.copyButton.Click += new System.EventHandler(this.copyButton_Click);
		// 
		// copyAllRadioButton
		// 
		this.copyAllRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.copyAllRadioButton.Checked = true;
		this.copyAllRadioButton.Location = new System.Drawing.Point(8, 408);
		this.copyAllRadioButton.Name = "copyAllRadioButton";
		this.copyAllRadioButton.TabIndex = 3;
		this.copyAllRadioButton.TabStop = true;
		this.copyAllRadioButton.Text = "Copy All Rows";
		// 
		// copySubsetRadioButton
		// 
		this.copySubsetRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.copySubsetRadioButton.Location = new System.Drawing.Point(128, 408);
		this.copySubsetRadioButton.Name = "copySubsetRadioButton";
		this.copySubsetRadioButton.Size = new System.Drawing.Size(168, 24);
		this.copySubsetRadioButton.TabIndex = 4;
		this.copySubsetRadioButton.Text = "Copy Rows for Employee ID:";
		// 
		// employeeIdTextBox
		// 
		this.employeeIdTextBox.Location = new System.Drawing.Point(296, 408);
		this.employeeIdTextBox.Name = "employeeIdTextBox";
		this.employeeIdTextBox.Size = new System.Drawing.Size(48, 20);
		this.employeeIdTextBox.TabIndex = 6;
		this.employeeIdTextBox.Text = "";
		// 
		// CopyTablesBetweenDataSetsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(632, 438);
		this.Controls.Add(this.employeeIdTextBox);
		this.Controls.Add(this.copySubsetRadioButton);
		this.Controls.Add(this.copyAllRadioButton);
		this.Controls.Add(this.copyButton);
		this.Controls.Add(this.destDataGrid);
		this.Controls.Add(this.sourceDataGrid);
		this.Name = "CopyTablesBetweenDataSetsForm";
		this.Text = "5.02 CopyTablesBetweenDataSetsForm";
		this.Load += new System.EventHandler(this.CopyTablesBetweenDataSetsForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.sourceDataGrid)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.destDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void CopyTablesBetweenDataSetsForm_Load(object sender, System.EventArgs e)
	{
		dsSource = new DataSet("Source");
		
		SqlDataAdapter da;

		// fill the Order table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.FillSchema(orderTable, SchemaType.Source);
		da.Fill(orderTable);
		dsSource.Tables.Add(orderTable);

		// fill the OrderDetails table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderDetailTable = new DataTable(ORDERDETAILS_TABLE);
		da.FillSchema(orderDetailTable, SchemaType.Source);
		da.Fill(orderDetailTable);
		dsSource.Tables.Add(orderDetailTable);

		// create a relation between the tables
		dsSource.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			dsSource.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
			dsSource.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
			true);

		// bind the source and destination DataSet to the grids
		sourceDataGrid.DataSource = dsSource.Tables[ORDERS_TABLE].DefaultView;
	}

	private void copyButton_Click(object sender, System.EventArgs e)
	{
		// create the destination DataSet to copy tables into
		DataSet dsDest = new DataSet("Destination");

		if (copyAllRadioButton.Checked)
		{
			foreach(DataTable sourceTable in dsSource.Tables)
			{
				// first technique, when all rows need to be copied
				dsDest.Tables.Add(sourceTable.Copy());
			}
		}
		else if (copySubsetRadioButton.Checked)
		{

			int employeeId = 0;
			try
			{
				employeeId = Convert.ToInt32(employeeIdTextBox.Text);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
				return;
			}

			// second technique, can be used to import subset
			foreach(DataTable dtSource in dsSource.Tables)
			{
				// add logic to selectively copy tables

				dsDest.Tables.Add(dtSource.Clone());
			}

			// copy rows for selected employee from the Orders table
			foreach(DataRow parentRow in dsSource.Tables[ORDERS_TABLE].Select(EMPLOYEEID_FIELD + "=" + employeeId))
			{
				dsDest.Tables[ORDERS_TABLE].ImportRow(parentRow);

				// copy the Order Details for the Order
				foreach(DataRow childRow in parentRow.GetChildRows(ORDERS_ORDERDETAILS_RELATION))
				{
					dsDest.Tables[ORDERDETAILS_TABLE].ImportRow(childRow);
				}
			}
		}

		// create the relations in the destination DataSet
		// iterate over the collection of relations in the source
		foreach(DataRelation sourceRelation in dsSource.Relations)
		{
			// get the name of the parent and child table for the relation
			String parentTableName = sourceRelation.ParentTable.TableName;
			String childTableName = sourceRelation.ChildTable.TableName;

			// get the number of parent columns for the source relation
			int nCol = sourceRelation.ParentColumns.Length;

			// create an array of parent columns in the destination
			DataColumn[] parentCols = new DataColumn[nCol];
			for(int i = 0; i < nCol; i++)
				parentCols[i] = dsDest.Tables[parentTableName].Columns[sourceRelation.ParentColumns[i].Ordinal];

			// create an array of child columns in the destination
			DataColumn[] childCols = new DataColumn[nCol];
			for(int i = 0; i < nCol; i++)
				childCols[i] = dsDest.Tables[childTableName].Columns[sourceRelation.ChildColumns[i].Ordinal];

			// create the relation in the destination DataSet
			dsDest.Relations.Add(new DataRelation(sourceRelation.RelationName, parentCols, childCols, false));
		}
		
		// set the enforce constraints flag to match the source DataSet
		dsDest.EnforceConstraints = dsSource.EnforceConstraints;

		// bind the default view of the Orders table to the grid
		destDataGrid.DataSource = dsDest.Tables[ORDERS_TABLE].DefaultView;
	}
}