using System;
using System.Configuration;
using System.Collections;

using System.Data;
using System.Data.SqlClient;

public class ConvertDataReaderToDataSetForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";

	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ConvertDataReaderToDataSetForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 2;
		// 
		// ConvertDataReaderToDataSetForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.dataGrid,
																		this.goButton});
		this.Name = "ConvertDataReaderToDataSetForm";
		this.Text = "5.03 ConvertDataReaderToDataSetForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		DataSet ds = new DataSet();

		// SQL for batch query
		String sqlText = "SELECT * FROM Orders; " +
			"SELECT * FROM [Order Details];";

		// create connection and command
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		
		// open DataReader with KeyInfo
		conn.Open();
		SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.KeyInfo);

		// loop over the result sets of the DataReader
		do
		{
			DataTable schemaTable = dr.GetSchemaTable();
			if (schemaTable != null)
			{
				ArrayList pkCols = new ArrayList();

				DataTable dataTable = new DataTable();
				foreach(DataRow schemaRow in schemaTable.Rows)
				{
					DataColumn col = new DataColumn();
					col.ColumnName = schemaRow["ColumnName"].ToString();
					col.DataType = (Type)schemaRow["DataType"];
					// set the length of the field for string types only
					if (schemaRow["DataType"].ToString() == "System.String")
						col.MaxLength = (Int32)schemaRow["ColumnSize"];
					col.Unique = (bool)schemaRow["IsUnique"];
					col.AllowDBNull = (bool)schemaRow["AllowDBNull"];
					col.AutoIncrement = (bool)schemaRow["IsAutoIncrement"];
					// if part of the key, add the column name to the
					// array of columns comprising the primary key
					if ((bool)schemaRow["IsKey"])
						pkCols.Add(col);

					dataTable.Columns.Add(col);
				}

				// add the primary key to the table
				dataTable.PrimaryKey = (DataColumn[])pkCols.ToArray(typeof(DataColumn));
				// add the table to the DataSet
				ds.Tables.Add(dataTable);

				object[] aData = new object[dataTable.Columns.Count];
				// read all rows from the DataReader
				while(dr.Read())
				{
					// read the row from the DataReader into an array
					dr.GetValues(aData);
					// add the row from the array to the DataTable
					dataTable.Rows.Add(aData);
				}
			}
		}
		while (dr.NextResult());

		conn.Close();

		// name the tables added to the DataSet
		ds.Tables[0].TableName = ORDERS_TABLE;
		ds.Tables[1].TableName = ORDERDETAILS_TABLE;

		// manually add a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD], ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD], true);

		// bind the Order table default view to the grid
		dataGrid.DataSource = ds.Tables[ORDERS_TABLE].DefaultView;
	}
}