using System;

using System.Data;
using System.Data.OleDb;

public class AdoRecordsetForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button loadAdoRecordsetButton;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AdoRecordsetForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.loadAdoRecordsetButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// loadAdoRecordsetButton
		// 
		this.loadAdoRecordsetButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.loadAdoRecordsetButton.Location = new System.Drawing.Point(360, 232);
		this.loadAdoRecordsetButton.Name = "loadAdoRecordsetButton";
		this.loadAdoRecordsetButton.Size = new System.Drawing.Size(120, 23);
		this.loadAdoRecordsetButton.TabIndex = 0;
		this.loadAdoRecordsetButton.Text = "Load ADO Recordset";
		this.loadAdoRecordsetButton.Click += new System.EventHandler(this.loadAdoRecordsetButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 1;
		// 
		// AdoRecordsetForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.dataGrid,
																		this.loadAdoRecordsetButton});
		this.Name = "AdoRecordsetForm";
		this.Text = "5.09 AdoRecordsetForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void loadAdoRecordsetButton_Click(object sender, System.EventArgs e)
	{
		// open an ADO connection
		ADODB.Connection conn = new ADODB.Connection();
		conn.Open("Provider = SQLOLEDB;Data Source = (local);Initial Catalog = northwind","sa","",0);

		// create an ADO recordset
		ADODB.Recordset rs = new ADODB.Recordset();
		rs.Open("SELECT * FROM Orders", conn, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, 0);
		
		// create and fill a dt from the ADO recordset
		DataTable dt = new DataTable("Orders");
		(new OleDbDataAdapter()).Fill(dt, rs);
		conn.Close();

		// bind the default view of the dt to the grid
		dataGrid.DataSource = dt.DefaultView;
	}
}