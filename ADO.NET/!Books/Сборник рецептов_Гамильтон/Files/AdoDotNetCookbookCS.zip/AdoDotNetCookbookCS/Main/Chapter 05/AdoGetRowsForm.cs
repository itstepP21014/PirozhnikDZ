using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class AdoGetRowsForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";

	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.TextBox resultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AdoGetRowsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 1;
		this.resultTextBox.Text = "";
		// 
		// AdoGetRowsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.resultTextBox,
																		this.goButton});
		this.Name = "AdoGetRowsForm";
		this.Text = "5.12 AdoGetRowsForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		// fill the Order table
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable(ORDERS_TABLE);
		da.Fill(dt);

		StringBuilder sb = new StringBuilder();

		Array a = GetRows(dt, -1, -1, null);

		// iterate over the rows of the array
		for(int iRow = 0; iRow < a.GetLength(0); iRow++)
		{
			// iterate over the columns of the array
			for(int iCol = 0; iCol < a.GetLength(1); iCol++)
			{
				sb.Append(a.GetValue(iRow, iCol).ToString() + "\t");
			}
			sb.Remove(sb.Length - 2, 2);
			sb.Append(Environment.NewLine);
		}

		resultTextBox.Text = sb.ToString();		
	}

	private Array GetRows(DataTable dt, int rowCount, int startRow, String[] colName)
	{
		// if column names are specified, ensure that they exist in the table
		if (colName != null)
		{
			for (int i = 0;  i < colName.Length; i++)
			{
				if (!dt.Columns.Contains(colName[i]))
					throw(new ArgumentException("The column " + colName[i] + 
						" does not exist in the table."));
			}
		}

		// if no columns were specified, set the number of columns to the
		// number of columns in the table, otherwise set the number of
		// columns to the number of items in the specified columns array
		int nCols = (colName == null) ? dt.Columns.Count : colName.Length;

		// the table row to start exporting
		// set to 1 if less than 1 is specified
		startRow = (startRow < 1) ? 1 : startRow;

		// the number of rows to export calculated as the number of rows in
		// the table less the starting row number.
		// if the starting row is specified as greater than the number of 
		// rows in the table, set the number of rows to 0.
		int nRows = Math.Max((dt.Rows.Count - startRow) + 1, 0);
		// if the number of rows to export is specified as greater than 0,
		// set the number of rows to export as the lesser of the number
		// specified and the number of rows calculated in the table
		// starting with the specified row.
		if (rowCount >= 0)
			nRows = Math.Min(nRows, rowCount);

		// create an object array to hold the data in the table
		Array a = Array.CreateInstance(typeof(object), nRows, nCols);

		// iterate over the collection of rows in the table
		for(int iRow = startRow - 1; iRow < startRow - 1 + nRows; iRow++)
		{
			if (colName == null)
			{
				// iterate over the collection of columns in the table
				for(int iCol = 0; iCol < dt.Columns.Count; iCol++)
				{
					// set the cell in the array
					a.SetValue(dt.Rows[iRow][iCol], iRow, iCol);
				}
			}
			else
			{
				for(int i = 0; i < colName.Length; i++)
				{
					// set the cell in the array
					a.SetValue(dt.Rows[iRow][colName[i]], iRow - startRow + 1, i);
				}
			}
		}

		return a;
	}
}