using System;
using System.Configuration;
using System.Windows.Forms;

using System.Xml;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;

using System.Data;
using System.Data.SqlClient;

public class SecureTransmissionForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";

	private RSACryptoServiceProvider rSAReceiver;

	private const int keySize = 128;

	// DES key and IV
	private Byte[] dESKey = new Byte[]		{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08};
	private Byte[] dESIV = new Byte[]		{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18};
	// RC2 key and IV
	private Byte[] rC2Key = new Byte[]		{0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
												0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};
	private Byte[] rC2IV = new Byte[]		{0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
												0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F};
	// Rijndael key and IV
	private Byte[] rijndaelKey = new Byte[]	{0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
												0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F};
	private Byte[] rijndaelIV = new Byte[]	{0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
												0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F};
	// triple DES key and IV
	private Byte[] tDESKey = new Byte[]		{0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
												0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
												0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17};
	private Byte[] tDESIV = new Byte[]		{0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
												0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
												0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37};

	private System.Windows.Forms.Button decryptButton;
	private System.Windows.Forms.Button encryptButton;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.RadioButton rijndaelRadioButton;
	private System.Windows.Forms.RadioButton dESRadioButton;
	private System.Windows.Forms.RadioButton tripleDESRadioButton;
	private System.Windows.Forms.RadioButton rc2RadioButton;
	private System.Windows.Forms.RadioButton rSARadioButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public SecureTransmissionForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//create a new instance of RSA for receiver
		rSAReceiver = new RSACryptoServiceProvider();
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.decryptButton = new System.Windows.Forms.Button();
		this.encryptButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.dESRadioButton = new System.Windows.Forms.RadioButton();
		this.rijndaelRadioButton = new System.Windows.Forms.RadioButton();
		this.tripleDESRadioButton = new System.Windows.Forms.RadioButton();
		this.rc2RadioButton = new System.Windows.Forms.RadioButton();
		this.rSARadioButton = new System.Windows.Forms.RadioButton();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// decryptButton
		// 
		this.decryptButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.decryptButton.Location = new System.Drawing.Point(408, 40);
		this.decryptButton.Name = "decryptButton";
		this.decryptButton.TabIndex = 11;
		this.decryptButton.Text = "Decrypt";
		this.decryptButton.Click += new System.EventHandler(this.decryptButton_Click);
		// 
		// encryptButton
		// 
		this.encryptButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.encryptButton.Location = new System.Drawing.Point(408, 8);
		this.encryptButton.Name = "encryptButton";
		this.encryptButton.TabIndex = 12;
		this.encryptButton.Text = "Encrypt";
		this.encryptButton.Click += new System.EventHandler(this.encryptButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 136);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 120);
		this.dataGrid.TabIndex = 13;
		// 
		// dESRadioButton
		// 
		this.dESRadioButton.Checked = true;
		this.dESRadioButton.Location = new System.Drawing.Point(8, 8);
		this.dESRadioButton.Name = "dESRadioButton";
		this.dESRadioButton.TabIndex = 0;
		this.dESRadioButton.TabStop = true;
		this.dESRadioButton.Text = "DES";
		// 
		// rijndaelRadioButton
		// 
		this.rijndaelRadioButton.Location = new System.Drawing.Point(8, 56);
		this.rijndaelRadioButton.Name = "rijndaelRadioButton";
		this.rijndaelRadioButton.TabIndex = 2;
		this.rijndaelRadioButton.Text = "Rijndael";
		// 
		// tripleDESRadioButton
		// 
		this.tripleDESRadioButton.Location = new System.Drawing.Point(8, 80);
		this.tripleDESRadioButton.Name = "tripleDESRadioButton";
		this.tripleDESRadioButton.TabIndex = 3;
		this.tripleDESRadioButton.Text = "Triple DES";
		// 
		// rc2RadioButton
		// 
		this.rc2RadioButton.Location = new System.Drawing.Point(8, 32);
		this.rc2RadioButton.Name = "rc2RadioButton";
		this.rc2RadioButton.TabIndex = 1;
		this.rc2RadioButton.Text = "RC2";
		// 
		// rSARadioButton
		// 
		this.rSARadioButton.Location = new System.Drawing.Point(8, 104);
		this.rSARadioButton.Name = "rSARadioButton";
		this.rSARadioButton.Size = new System.Drawing.Size(120, 24);
		this.rSARadioButton.TabIndex = 14;
		this.rSARadioButton.Text = "RSA (Asymmetric)";
		// 
		// SecureTransmissionForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.rSARadioButton);
		this.Controls.Add(this.rc2RadioButton);
		this.Controls.Add(this.tripleDESRadioButton);
		this.Controls.Add(this.rijndaelRadioButton);
		this.Controls.Add(this.dESRadioButton);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.encryptButton);
		this.Controls.Add(this.decryptButton);
		this.Name = "SecureTransmissionForm";
		this.Text = "5.07 SecureTransmissionForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void encryptButton_Click(object sender, System.EventArgs e)
	{
		DataSet ds = new DataSet();
		
		SqlDataAdapter da;

		// fill the Order table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.FillSchema(orderTable, SchemaType.Source);
		da.Fill(orderTable);
		ds.Tables.Add(orderTable);

		// fill the OrderDetails table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderDetailTable = new DataTable(ORDERDETAILS_TABLE);
		da.FillSchema(orderDetailTable, SchemaType.Source);
		da.Fill(orderDetailTable);
		ds.Tables.Add(orderDetailTable);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
			ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
			true);

		// clear the grid
		dataGrid.DataSource = null;

		if(rSARadioButton.Checked)
		{
			// asymmetric algorithm
			EncryptedMessage em = new EncryptedMessage();

			// RC2 symmetric algorithm to encode the DataSet
			RC2CryptoServiceProvider rC2 = new RC2CryptoServiceProvider();
			rC2.KeySize = keySize;
			// generate RC2 Key and IV
			rC2.GenerateKey();
			rC2.GenerateIV();

			// get the receiver's RSA public key
			RSACryptoServiceProvider rSA = new RSACryptoServiceProvider();
			rSA.ImportParameters(rSAReceiver.ExportParameters(false));
			try
			{
				// encrypt the RC2 key and IV with the receiver's RSA public key
				em.Key = rSA.Encrypt(rC2.Key, false);
				em.IV = rSA.Encrypt(rC2.IV, false);
			}
			catch(CryptographicException ex)
			{
				MessageBox.Show(ex.Message, "Securing Transmission", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			Cursor.Current = Cursors.WaitCursor;

			// use the CryptoStream to write the encrypted DataSet to the MemoryStream
			MemoryStream ms = new MemoryStream();
			CryptoStream cs = new CryptoStream(ms, rC2.CreateEncryptor(), CryptoStreamMode.Write);
			ds.WriteXml(cs, XmlWriteMode.WriteSchema);
			cs.FlushFinalBlock();
			em.Body = ms.ToArray();

			cs.Close();
			ms.Close();

			// serialize the encrypted message to a file
			Stream s = File.Open(System.IO.Path.GetTempPath() + @"\rsa.dat", FileMode.Create);
			BinaryFormatter bf = new BinaryFormatter();
			bf.Serialize(s, em);
			s.Close();

			Cursor.Current = Cursors.Default;

			MessageBox.Show("Encryption complete.", "Securing Transmission", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
		else
		{
			SaveFileDialog sfd;
			sfd = new SaveFileDialog();
			sfd.InitialDirectory = System.IO.Path.GetTempPath();
			sfd.Filter = "All files (*.*)|*.*";
			sfd.FilterIndex = 0;

			if (sfd.ShowDialog() == DialogResult.OK)
			{
				FileStream fsWrite = null;
				try
				{
					fsWrite = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "Securing Transmission", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return;
				}

				Cursor.Current = Cursors.WaitCursor;

				// symmetric algorithms
				byte[] key = null;
				byte[] iV = null;
				SymmetricAlgorithm sa = null;

				if(dESRadioButton.Checked)
				{
					sa = new DESCryptoServiceProvider();
					key = dESKey;
					iV = dESIV;
				}
				else if(rc2RadioButton.Checked)
				{
					sa = new RC2CryptoServiceProvider();
					sa.KeySize = 128;
					key = rC2Key;
					iV = rC2IV;
				}
				else if(rijndaelRadioButton.Checked)
				{
					sa = new RijndaelManaged();
					key = rijndaelKey;
					iV = rijndaelIV;
				}
				else if(tripleDESRadioButton.Checked)
				{
					sa = new TripleDESCryptoServiceProvider();          
					key = tDESKey;
					iV = tDESIV;
				}
				
				// encrypt the DataSet
				CryptoStream cs = null;
				try
				{
					cs = new CryptoStream(fsWrite, sa.CreateEncryptor(key, iV), CryptoStreamMode.Write);

					ds.WriteXml(cs, XmlWriteMode.WriteSchema);
					cs.Close();

					MessageBox.Show("Encryption complete.", "Securing Transmission", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "Securing Transmission", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				finally
				{
					fsWrite.Close();
					Cursor.Current = Cursors.Default;
				}
			}
		}
	}

	private void decryptButton_Click(object sender, System.EventArgs e)
	{
		dataGrid.DataSource = null;
		DataSet ds = new DataSet();

		if(rSARadioButton.Checked)
		{
			// asymmetric algorithm

			// deserialize the encrypted message from a file
			Stream s = null;
			try
			{
				s = File.Open(System.IO.Path.GetTempPath() + @"\rsa.dat", FileMode.Open);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "Securing Transmission", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			BinaryFormatter bf = new BinaryFormatter();
			EncryptedMessage em = (EncryptedMessage)bf.Deserialize(s);
			s.Close();

			// RC2 symmetric algorithm to decode the DataSet
			RC2CryptoServiceProvider rC2 = new RC2CryptoServiceProvider();
			rC2.KeySize = keySize;

			// decrypt the RC2 key and IV using the receiver's RSA private key
			try
			{
				rC2.Key = rSAReceiver.Decrypt(em.Key, false);
				rC2.IV = rSAReceiver.Decrypt(em.IV, false);
			}
			catch (CryptographicException ex)
			{
				MessageBox.Show(ex.Message, "Securing Transmission", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			
			Cursor.Current = Cursors.WaitCursor;

			// put the message body into the MemoryStream
			MemoryStream ms = new MemoryStream(em.Body);
			// use the CryptoStream to read the encrypted DataSet from the MemoryStream
			CryptoStream cs = new CryptoStream(ms, rC2.CreateDecryptor(), CryptoStreamMode.Read);			
			ds.ReadXml(cs, XmlReadMode.ReadSchema);
			cs.Close();

			dataGrid.DataSource = ds.DefaultViewManager;

			Cursor.Current = Cursors.Default;
		}
		else
		{
			// symmetric algorithm
			OpenFileDialog ofd;
			ofd = new OpenFileDialog();
			ofd.InitialDirectory = System.IO.Path.GetTempPath();
			ofd.Filter = "All files (*.*)|*.*";
			ofd.FilterIndex = 0;

			if (ofd.ShowDialog() == DialogResult.OK)
			{
				FileStream fsRead = null;
				try
				{
					fsRead = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read);
				}
				catch(Exception ex)
				{
					dataGrid.DataSource = null;
					MessageBox.Show(ex.Message, "Securing Transmission", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return;
				}

				Cursor.Current = Cursors.WaitCursor;

				SymmetricAlgorithm sa = null;
				byte[] key = null;
				byte[] iV = null;
				if(dESRadioButton.Checked)
				{
					sa = new DESCryptoServiceProvider();
					key = dESKey;
					iV = dESIV;
				}
				else if(rc2RadioButton.Checked)
				{
					sa = new RC2CryptoServiceProvider();
					sa.KeySize = 128;
					key = rC2Key;
					iV = rC2IV;
				}
				else if(rijndaelRadioButton.Checked)
				{
					sa = new RijndaelManaged();
					key = rijndaelKey;
					iV = rijndaelIV;
				}
				else if(tripleDESRadioButton.Checked)
				{
					sa = new TripleDESCryptoServiceProvider();          
					key = tDESKey;
					iV = tDESIV;
				}

				// decrypt the stream into the DataSet
				CryptoStream cs = null;
				try
				{
					cs = new CryptoStream(fsRead, sa.CreateDecryptor(key, iV), CryptoStreamMode.Read);			

					ds.ReadXml(cs, XmlReadMode.ReadSchema);
					cs.Close();

					dataGrid.DataSource = ds.DefaultViewManager;
				}
				catch(Exception ex)
				{
					dataGrid.DataSource = null;
					MessageBox.Show(ex.Message, "Securing Transmission", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				finally
				{
					fsRead.Close();
					Cursor.Current = Cursors.Default;
				}
			}
		}
	}
}

[Serializable()]
internal class EncryptedMessage
{
	public byte[] Body;		// RC2 encrypted
	public byte[] Key;		// RSA encrypted RC2 key
	public byte[] IV;		// RC2 initialization vector
}