using System;
using System.Configuration;
using System.Windows.Forms;
using System.IO;
using System.Text;

using System.Xml;
using System.Xml.Xsl;

using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

public class ConvertDataSetToAdoRecordsetForm : System.Windows.Forms.Form
{
	private readonly String ADOXMLFILE = ConfigurationSettings.AppSettings["Temp_Directory"] + "ADO_Orders.xml";

	private System.Windows.Forms.Button saveButton;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ConvertDataSetToAdoRecordsetForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.saveButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// saveButton
		// 
		this.saveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.saveButton.Location = new System.Drawing.Point(408, 232);
		this.saveButton.Name = "saveButton";
		this.saveButton.TabIndex = 0;
		this.saveButton.Text = "Go";
		this.saveButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(480, 216);
		this.dataGrid.TabIndex = 2;
		// 
		// ConvertDataSetToAdoRecordsetForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.saveButton);
		this.Name = "ConvertDataSetToAdoRecordsetForm";
		this.Text = "5.10 ConvertDataSetToAdoRecordsetForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		Cursor.Current = Cursors.WaitCursor;

		String sqlText = "SELECT * FROM Orders";

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// create the command to load all orders records
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		conn.Open();
		// create a DataReader from the command
		SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SchemaOnly | CommandBehavior.KeyInfo);
		// create a table of the schema for the DataReader
		DataTable schemaTable = dr.GetSchemaTable();

		// create an XML document
		XmlDocument xmlDoc = new XmlDocument();
		// add ADO namespace and schema definition tags to the XML document
		String adoXml = "<xml xmlns:s = 'uuid:BDC6E3F0-6DA3-11d1-A2A3-00AA00C14882' " +
			"xmlns:dt = 'uuid:C2F41010-65B3-11d1-A29F-00AA00C14882' " +
			"xmlns:rs = 'urn:schemas-microsoft-com:rowset' " +
			"xmlns:z = '#RowsetSchema'>" +
			"<s:Schema id = 'RowsetSchema'>" +
			"<s:ElementType name = 'row' content = 'eltOnly'>" +
			"</s:ElementType>" +	
			"</s:Schema>" +
			"</xml>";
		xmlDoc.LoadXml(adoXml);

		// create a namespace manager for the XML document
		XmlNamespaceManager nm = new XmlNamespaceManager(xmlDoc.NameTable);
		// add ADO prefixes
		nm.AddNamespace("s", "uuid:BDC6E3F0-6DA3-11d1-A2A3-00AA00C14882");
		nm.AddNamespace("dt", "uuid:C2F41010-65B3-11d1-A29F-00AA00C14882");
		nm.AddNamespace("rs", "urn:schemas-microsoft-com:rowset");
		nm.AddNamespace("z", "#RowsetSchema");

		// select the s:ElementType node
		XmlNode curNode = xmlDoc.SelectSingleNode("//s:ElementType", nm);

		XmlElement xe = null;
		XmlAttribute xa = null;
		// iterate through the schema records for the DataReader
		foreach(DataRow sr in schemaTable.Rows)
		{
			// create an 'AttributeType' element for the schema record
			xe = xmlDoc.CreateElement("s", "AttributeType", "uuid:BDC6E3F0-6DA3-11d1-A2A3-00AA00C14882");

			// get the data type
			SqlDbType sqlDbType = (SqlDbType)sr["ProviderType"];

			// create the 'name' attribute
			xa = xmlDoc.CreateAttribute("", "name", "");
			xa.Value = sr["ColumnName"].ToString();
			xe.SetAttributeNode(xa);

			// create the 'number' attribute
			xa = xmlDoc.CreateAttribute("rs", "number", "urn:schemas-microsoft-com:rowset");
			xa.Value = ((int)sr["ColumnOrdinal"] + 1).ToString();
			xe.SetAttributeNode(xa);

			// add attribute if null values are allowed in the column
			if((bool)sr["AllowDBNull"])
			{
				xa = xmlDoc.CreateAttribute("rs", "nullable", "urn:schemas-microsoft-com:rowset");
				xa.Value = sr["AllowDBNull"].ToString().ToLower();
				xe.SetAttributeNode(xa);
			}

			// add 'writeunknown' attribute
			xa = xmlDoc.CreateAttribute("rs", "writeunknown", "urn:schemas-microsoft-com:rowset");
			xa.Value = "true";
			xe.SetAttributeNode(xa);

			// create a 'datatype' element for the column within the 'AttributeType'
			XmlElement dataele = xmlDoc.CreateElement("s", "datatype", "uuid:BDC6E3F0-6DA3-11d1-A2A3-00AA00C14882");
			String typeName, dbTypeName;
			GetDataTypeInfo(sqlDbType, out typeName, out dbTypeName);

			// add a 'type' attribute specifying the data type
			xa = xmlDoc.CreateAttribute("dt", "type", "uuid:C2F41010-65B3-11d1-A29F-00AA00C14882");
			xa.Value = typeName;
			dataele.SetAttributeNode(xa);

			// add a 'dbtype' attribute, if necessary
			if (dbTypeName != "")
			{
				xa = xmlDoc.CreateAttribute("rs", "dbtype", "urn:schemas-microsoft-com:rowset");
				xa.Value = dbTypeName;
				dataele.SetAttributeNode(xa);
			}

			// add the 'maxlength' attribute
			xa = xmlDoc.CreateAttribute("dt", "maxLength", "uuid:C2F41010-65B3-11d1-A29F-00AA00C14882");
			xa.Value = sr["ColumnSize"].ToString();
			dataele.SetAttributeNode(xa);

			// add 'scale' and 'precision' attributes if appropriate
			if(sr["DataType"].ToString() != "System.String")
			{
				if(Convert.ToByte(sr["NumericScale"]) != 255)
				{
					xa = xmlDoc.CreateAttribute("rs", "scale", "urn:schemas-microsoft-com:rowset");
					xa.Value = sr["NumericScale"].ToString();
					dataele.SetAttributeNode(xa);
				}

				xa = xmlDoc.CreateAttribute("rs", "precision", "urn:schemas-microsoft-com:rowset");
				xa.Value = sr["NumericPrecision"].ToString();
				dataele.SetAttributeNode(xa);
			}
	
			// add a 'fixedlength' attribute if appropriate
			if (sqlDbType != SqlDbType.VarChar && sqlDbType != SqlDbType.NVarChar)
			{
				xa = xmlDoc.CreateAttribute("rs", "fixedlength", "urn:schemas-microsoft-com:rowset");
				xa.Value = "true";
				dataele.SetAttributeNode(xa);
			}

			// add a 'maybe' null attribute if appropriate
			if(!(bool)sr["AllowDBNull"])
			{
				xa = xmlDoc.CreateAttribute("rs", "maybenull", "urn:schemas-microsoft-com:rowset");
				xa.Value = sr["AllowDBNull"].ToString().ToLower();
				dataele.SetAttributeNode(xa);
			}

			// add the 'datatype' element to the 'AttributeType'
			xe.AppendChild(dataele);

			// add the 'AttributeType' element to the 'ElementType' attribute
			curNode.AppendChild(xe);
		}
		// add the 'extends' element with attribute 'type" of 'rs:rowbase'
		xe = xmlDoc.CreateElement("s", "extends", "uuid:BDC6E3F0-6DA3-11d1-A2A3-00AA00C14882");
		xa = xmlDoc.CreateAttribute("", "type", "");
		xa.Value = "rs:rowbase";
		xe.SetAttributeNode(xa);
		curNode.AppendChild(xe);

		// close the reader and connection
		dr.Close();
		conn.Close();

		// load the Orders data into a table in a DataSet
		DataSet ds = new DataSet();
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(ds, "Orders");

		// write the column data as attributes
		foreach(DataColumn dc in ds.Tables["Orders"].Columns)
			dc.ColumnMapping = MappingType.Attribute;
		// write the DataSet to an XML document
		XmlDataDocument ordersXml = new XmlDataDocument(ds);

		// load the XML transformation
		XslTransform xslt = new XslTransform();
		xslt.Load(ConfigurationSettings.AppSettings["Project_Directory"] + @"Chapter 05\Orders.xslt");

		// transform the XML document
		XmlReader xr = xslt.Transform(ordersXml, null, (XmlResolver)null);

		// load the transformed document into an XML document
		XmlDocument resultXmlDoc = new XmlDocument();
		resultXmlDoc.Load(xr);
		xr.Close();

		StringBuilder sb = new StringBuilder(xmlDoc.OuterXml);
		// insert the data before the closing </xml> tag.
		sb.Insert(sb.Length - 6, resultXmlDoc.InnerXml.Remove(8, resultXmlDoc.InnerXml.IndexOf(">") - 8));
		// make the <z:row> elements self closing
		// (ADO import doesn't work otherwise)
		sb.Replace("></z:row>","/>");

		// write the order data to a file as ADO XML format
		StreamWriter sw = new StreamWriter(ADOXMLFILE);
		sw.Write(sb.ToString());
		sw.Close();

		// create and open an ADO connection
		ADODB.Connection adoConn = new ADODB.Connection();
		adoConn.Open("Provider = SQLOLEDB;Data Source=(local);Initial Catalog=northwind", "sa", "", 0);

		// create the ADO recordset
		ADODB.Recordset rs = new ADODB.Recordset();
		try
		{
			// load the XML into the ADO recordset
			rs.Open(ADOXMLFILE,
				adoConn,
				ADODB.CursorTypeEnum.adOpenStatic,
				ADODB.LockTypeEnum.adLockBatchOptimistic,
				(int)ADODB.CommandTypeEnum.adCmdFile);
		}
		catch (System.Exception ex)
		{
			MessageBox.Show(ex.Message);
			adoConn.Close();

			Cursor.Current = Cursors.Default;

			return;
		}

		try
		{
			// load the ADO recordset into a DataTable
			OleDbDataAdapter oleDa = new OleDbDataAdapter();
			DataTable dt = new DataTable("Orders");
			oleDa.Fill(dt, rs);

			// bind the default view of the table to the grid
			dataGrid.DataSource = dt.DefaultView;
		}
		catch(Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
		finally
		{
			adoConn.Close();
			Cursor.Current = Cursors.Default;
		}

		dataGrid.CaptionText = "ADO Recordset Serialized as an XML document";
	}

	private void GetDataTypeInfo(SqlDbType sqlDbType, out String type, out String dbtype)
	{
		type = "";
		dbtype = "";

		// convert the SqlDbType to type attributes in the dt and rs namespaces
		switch(sqlDbType)
		{
			case SqlDbType.BigInt:
				type = "i8";
				break;
			case SqlDbType.Binary:
				type = "bin.hex";
				break;
			case SqlDbType.Bit:
				type = "Boolean";
				break;
			case SqlDbType.Char:
				type = "string";
				dbtype = "str";
				break;
			case SqlDbType.DateTime:
				type = "dateTime";
				dbtype = "variantdate";
				break;
			case SqlDbType.Decimal:
				type = "number";
				dbtype = "decimal";
				break;
			case SqlDbType.Float:
				type = "float";
				break;
			case SqlDbType.Image:
				type = "bin.hex";
				break;
			case SqlDbType.Int:
				type = "int";
				break;
			case SqlDbType.Money:
				type = "i8";
				dbtype = "currency";
				break;
			case SqlDbType.NChar:
				type = "string";
				break;
			case SqlDbType.NText:
				type = "string";
				break;
			case SqlDbType.NVarChar:
				type = "string";
				break;
			case SqlDbType.Real:
				type = "r4";
				break;
			case SqlDbType.SmallDateTime:
				type = "dateTime";
				break;
			case SqlDbType.SmallInt:
				type = "i2";
				break;
			case SqlDbType.SmallMoney:
				type = "i4";
				dbtype = "currency";
				break;
			case SqlDbType.Text:
				type = "string";
				dbtype = "str";
				break;
			case SqlDbType.Timestamp:
				type = "dateTime";
				dbtype = "timestamp";
				break;
			case SqlDbType.TinyInt:
				type = "i1";
				break;
			case SqlDbType.UniqueIdentifier:
				type = "uuid";
				break;
			case SqlDbType.VarBinary:
				type = "bin.hex";
				break;
			case SqlDbType.VarChar:
				type = "string";
				dbtype = "str";
				break;
			case SqlDbType.Variant:
				type = "string";
				break;
		}
	}
}