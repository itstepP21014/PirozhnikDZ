using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class MergingDataForm : System.Windows.Forms.Form
{
	private SqlDataAdapter daA, daB;
	private DataSet dsA, dsB;

	private System.Windows.Forms.DataGrid dataGridA;
	private System.Windows.Forms.DataGrid dataGridB;
	private System.Windows.Forms.DataGrid dataGridMerge;
	private System.Windows.Forms.Button mergeAIntoBButton;
	private System.Windows.Forms.Button mergeBIntoAButton;
	private System.Windows.Forms.Button clearResultsButton;
	private System.Windows.Forms.GroupBox groupBox1;
	private System.Windows.Forms.RadioButton addRadioButton;
	private System.Windows.Forms.RadioButton addWithKeyRadioButton;
	private System.Windows.Forms.RadioButton errorRadioButton;
	private System.Windows.Forms.RadioButton ignoreRadioButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public MergingDataForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGridA = new System.Windows.Forms.DataGrid();
		this.dataGridB = new System.Windows.Forms.DataGrid();
		this.dataGridMerge = new System.Windows.Forms.DataGrid();
		this.mergeAIntoBButton = new System.Windows.Forms.Button();
		this.mergeBIntoAButton = new System.Windows.Forms.Button();
		this.clearResultsButton = new System.Windows.Forms.Button();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.addRadioButton = new System.Windows.Forms.RadioButton();
		this.addWithKeyRadioButton = new System.Windows.Forms.RadioButton();
		this.errorRadioButton = new System.Windows.Forms.RadioButton();
		this.ignoreRadioButton = new System.Windows.Forms.RadioButton();
		((System.ComponentModel.ISupportInitialize)(this.dataGridA)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.dataGridB)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.dataGridMerge)).BeginInit();
		this.groupBox1.SuspendLayout();
		this.SuspendLayout();
		// 
		// dataGridA
		// 
		this.dataGridA.CaptionText = "Employee A";
		this.dataGridA.DataMember = "";
		this.dataGridA.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGridA.Location = new System.Drawing.Point(8, 8);
		this.dataGridA.Name = "dataGridA";
		this.dataGridA.Size = new System.Drawing.Size(425, 120);
		this.dataGridA.TabIndex = 0;
		this.dataGridA.TabStop = false;
		// 
		// dataGridB
		// 
		this.dataGridB.CaptionText = "Employee B";
		this.dataGridB.DataMember = "";
		this.dataGridB.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGridB.Location = new System.Drawing.Point(8, 136);
		this.dataGridB.Name = "dataGridB";
		this.dataGridB.Size = new System.Drawing.Size(425, 120);
		this.dataGridB.TabIndex = 1;
		this.dataGridB.TabStop = false;
		// 
		// dataGridMerge
		// 
		this.dataGridMerge.CaptionText = "Merge Results";
		this.dataGridMerge.DataMember = "";
		this.dataGridMerge.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGridMerge.Location = new System.Drawing.Point(8, 264);
		this.dataGridMerge.Name = "dataGridMerge";
		this.dataGridMerge.Size = new System.Drawing.Size(425, 120);
		this.dataGridMerge.TabIndex = 2;
		this.dataGridMerge.TabStop = false;
		// 
		// mergeAIntoBButton
		// 
		this.mergeAIntoBButton.Location = new System.Drawing.Point(504, 296);
		this.mergeAIntoBButton.Name = "mergeAIntoBButton";
		this.mergeAIntoBButton.Size = new System.Drawing.Size(80, 23);
		this.mergeAIntoBButton.TabIndex = 5;
		this.mergeAIntoBButton.Text = "Merge A->B";
		this.mergeAIntoBButton.Click += new System.EventHandler(this.mergeAIntoBButton_Click);
		// 
		// mergeBIntoAButton
		// 
		this.mergeBIntoAButton.Location = new System.Drawing.Point(504, 328);
		this.mergeBIntoAButton.Name = "mergeBIntoAButton";
		this.mergeBIntoAButton.Size = new System.Drawing.Size(80, 23);
		this.mergeBIntoAButton.TabIndex = 6;
		this.mergeBIntoAButton.Text = "Merge B<-A";
		this.mergeBIntoAButton.Click += new System.EventHandler(this.mergeBIntoAButton_Click);
		// 
		// clearResultsButton
		// 
		this.clearResultsButton.Location = new System.Drawing.Point(504, 360);
		this.clearResultsButton.Name = "clearResultsButton";
		this.clearResultsButton.Size = new System.Drawing.Size(80, 23);
		this.clearResultsButton.TabIndex = 7;
		this.clearResultsButton.Text = "Clear Results";
		this.clearResultsButton.Click += new System.EventHandler(this.clearResultsButton_Click);
		// 
		// groupBox1
		// 
		this.groupBox1.Controls.Add(this.ignoreRadioButton);
		this.groupBox1.Controls.Add(this.errorRadioButton);
		this.groupBox1.Controls.Add(this.addWithKeyRadioButton);
		this.groupBox1.Controls.Add(this.addRadioButton);
		this.groupBox1.Location = new System.Drawing.Point(448, 8);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(136, 120);
		this.groupBox1.TabIndex = 0;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "MissingSchemaAction";
		// 
		// addRadioButton
		// 
		this.addRadioButton.Checked = true;
		this.addRadioButton.Location = new System.Drawing.Point(8, 24);
		this.addRadioButton.Name = "addRadioButton";
		this.addRadioButton.Size = new System.Drawing.Size(104, 16);
		this.addRadioButton.TabIndex = 1;
		this.addRadioButton.TabStop = true;
		this.addRadioButton.Text = "Add";
		// 
		// addWithKeyRadioButton
		// 
		this.addWithKeyRadioButton.Location = new System.Drawing.Point(8, 48);
		this.addWithKeyRadioButton.Name = "addWithKeyRadioButton";
		this.addWithKeyRadioButton.Size = new System.Drawing.Size(104, 16);
		this.addWithKeyRadioButton.TabIndex = 2;
		this.addWithKeyRadioButton.Text = "AddWithKey";
		// 
		// errorRadioButton
		// 
		this.errorRadioButton.Location = new System.Drawing.Point(8, 72);
		this.errorRadioButton.Name = "errorRadioButton";
		this.errorRadioButton.Size = new System.Drawing.Size(104, 16);
		this.errorRadioButton.TabIndex = 3;
		this.errorRadioButton.Text = "Error";
		// 
		// ignoreRadioButton
		// 
		this.ignoreRadioButton.Location = new System.Drawing.Point(8, 96);
		this.ignoreRadioButton.Name = "ignoreRadioButton";
		this.ignoreRadioButton.Size = new System.Drawing.Size(104, 16);
		this.ignoreRadioButton.TabIndex = 4;
		this.ignoreRadioButton.Text = "Ignore";
		// 
		// MergingDataForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(592, 390);
		this.Controls.Add(this.groupBox1);
		this.Controls.Add(this.clearResultsButton);
		this.Controls.Add(this.mergeBIntoAButton);
		this.Controls.Add(this.mergeAIntoBButton);
		this.Controls.Add(this.dataGridMerge);
		this.Controls.Add(this.dataGridB);
		this.Controls.Add(this.dataGridA);
		this.Name = "MergingDataForm";
		this.Text = "5.06 MergingDataForm";
		this.Load += new System.EventHandler(this.MergingDataForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGridA)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.dataGridB)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.dataGridMerge)).EndInit();
		this.groupBox1.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion

	private void MergingDataForm_Load(object sender, System.EventArgs e)
	{
		// fill the schema and data for table A
		String sqlText = "SELECT EmployeeID, LastName, FirstName, Title " +
			"FROM Employees WHERE EmployeeID BETWEEN 1 AND 5";
		// set up the DataAdapter and CommandBuilder for table A
		SqlCommandBuilder cbA = new SqlCommandBuilder(daA);
		daA = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_SqlAuth_ConnectString"]);
		// define DataSet A and fill its table A with schema and data
		dsA = new DataSet("A");
		daA.FillSchema(dsA, SchemaType.Source, "Employees");
		daA.Fill(dsA, "Employees");
		// bind the default view for table A to the grid
		dataGridA.DataSource = dsA.Tables["Employees"].DefaultView;

		// fill the schema and data for table B
		sqlText = "SELECT EmployeeID, LastName, FirstName, " +
			"BirthDate, HireDate " +
			"FROM Employees WHERE EmployeeID BETWEEN 4 AND 8";
		// set up the DataAdapter and CommandBuilder for table B
		daB = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_SqlAuth_ConnectString"]);
		SqlCommandBuilder cbB = new SqlCommandBuilder(daB);
		// define DataSet B and fill its table B with schema and data
		dsB = new DataSet("B");
		daB.FillSchema(dsB, SchemaType.Source, "Employees");
		daB.Fill(dsB, "Employees");
		// bind the default view for table B to the grid
		dataGridB.DataSource = dsB.Tables["Employees"].DefaultView;
	}

	private void Merge(DataTable dtSource, DataTable dtDest)
	{
		// set the missing schema value to the default and read
		// actual value, if otherwise, from the radio buttons.
		MissingSchemaAction msa = MissingSchemaAction.Add;

		if(addWithKeyRadioButton.Checked)
			msa = MissingSchemaAction.AddWithKey;
		else if(errorRadioButton.Checked)
			msa = MissingSchemaAction.Error;
		else if(ignoreRadioButton.Checked)
			msa = MissingSchemaAction.Ignore;

		// create the merge DataSet and copy table B into it
		DataSet ds = new DataSet("Merge");
		ds.Tables.Add(dtDest.Copy());

		try
		{
			// merge table A into the DataSet
			ds.Merge(dtSource, false, msa);
		}
		catch (Exception ex)
		{ 
			MessageBox.Show(ex.Message);
		}

		// bind the merge result table default view to the grid
		dataGridMerge.DataSource = ds.Tables[0].DefaultView;
		dataGridMerge.CaptionText = "Merge Results: " + dtSource.DataSet.DataSetName + " into " + dtDest.DataSet.DataSetName;
	}

	private void mergeAIntoBButton_Click(object sender, System.EventArgs e)
	{
		Merge(dsA.Tables["Employees"], dsB.Tables["Employees"]);
	}

	private void mergeBIntoAButton_Click(object sender, System.EventArgs e)
	{
		Merge(dsB.Tables["Employees"], dsA.Tables["Employees"]);
	}

	private void clearResultsButton_Click(object sender, System.EventArgs e)
	{
		dataGridMerge.DataSource = null;
		dataGridMerge.CaptionText = "";
	}
}