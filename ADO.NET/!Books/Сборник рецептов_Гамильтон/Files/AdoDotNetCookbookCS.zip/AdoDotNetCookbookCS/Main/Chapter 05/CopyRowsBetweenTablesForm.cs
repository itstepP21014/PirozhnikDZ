using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class CopyRowsBetweenTablesForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";

	private System.Windows.Forms.Button copyButton;
	private System.Windows.Forms.RadioButton filteredDataViewRadioButton;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.RadioButton rowRadioButton;
	private System.Windows.Forms.RadioButton selectRadioButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public CopyRowsBetweenTablesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.copyButton = new System.Windows.Forms.Button();
		this.rowRadioButton = new System.Windows.Forms.RadioButton();
		this.selectRadioButton = new System.Windows.Forms.RadioButton();
		this.filteredDataViewRadioButton = new System.Windows.Forms.RadioButton();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// copyButton
		// 
		this.copyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.copyButton.Location = new System.Drawing.Point(408, 8);
		this.copyButton.Name = "copyButton";
		this.copyButton.TabIndex = 5;
		this.copyButton.Text = "Copy";
		this.copyButton.Click += new System.EventHandler(this.copyButton_Click);
		// 
		// rowRadioButton
		// 
		this.rowRadioButton.Location = new System.Drawing.Point(8, 8);
		this.rowRadioButton.Name = "rowRadioButton";
		this.rowRadioButton.Size = new System.Drawing.Size(184, 24);
		this.rowRadioButton.TabIndex = 2;
		this.rowRadioButton.Text = "First three rows";
		// 
		// selectRadioButton
		// 
		this.selectRadioButton.Location = new System.Drawing.Point(8, 32);
		this.selectRadioButton.Name = "selectRadioButton";
		this.selectRadioButton.Size = new System.Drawing.Size(256, 24);
		this.selectRadioButton.TabIndex = 3;
		this.selectRadioButton.Text = "DataTable.Select (OrderID<=10300)";
		// 
		// filteredDataViewRadioButton
		// 
		this.filteredDataViewRadioButton.Location = new System.Drawing.Point(8, 56);
		this.filteredDataViewRadioButton.Name = "filteredDataViewRadioButton";
		this.filteredDataViewRadioButton.Size = new System.Drawing.Size(320, 24);
		this.filteredDataViewRadioButton.TabIndex = 4;
		this.filteredDataViewRadioButton.Text = "Filtered DataView (OrderID>=10300 AND OrderID<10400)";
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 88);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 168);
		this.dataGrid.TabIndex = 6;
		// 
		// CopyRowsBetweenTablesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.filteredDataViewRadioButton);
		this.Controls.Add(this.selectRadioButton);
		this.Controls.Add(this.rowRadioButton);
		this.Controls.Add(this.copyButton);
		this.Name = "CopyRowsBetweenTablesForm";
		this.Text = "5.01 CopyRowsBetweenTablesForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void copyButton_Click(object sender, System.EventArgs e)
	{
		// fill the source table with schema and data
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable(ORDERS_TABLE);
		da.FillSchema(dt, SchemaType.Source);
		da.Fill(dt);

		// clone the schema to the copy table
		DataTable dtCopy = dt.Clone();

		if(rowRadioButton.Checked)
		{
			// use ImportRow method to import the first 3 rows
			for (int i = 0; i < 3; i++)
			{
				dtCopy.ImportRow(dt.Rows[i]);
			}
		}
		else if (selectRadioButton.Checked)
		{
			// copy using result of Select method
			foreach(DataRow row in dt.Select(ORDERID_FIELD + " <= 10300"))
			{
				dtCopy.ImportRow(row);
			}
		}
		else if (filteredDataViewRadioButton.Checked)
		{
			// copy using result of filtered DataView
			DataView categoryView = dt.DefaultView;
			categoryView.RowFilter = ORDERID_FIELD + " >= 10300 AND " + ORDERID_FIELD + " < 10400";
			for (int i = 0; i < categoryView.Count; i++)
			{
				dtCopy.ImportRow(categoryView[i].Row);
			}
		}

		// bind the default view of the copy table to the grid
		dataGrid.DataSource = dtCopy.DefaultView;
	}
}