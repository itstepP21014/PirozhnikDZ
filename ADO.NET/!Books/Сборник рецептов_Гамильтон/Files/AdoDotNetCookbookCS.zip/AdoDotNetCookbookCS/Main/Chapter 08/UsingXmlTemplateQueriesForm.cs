using System;
using System.Configuration;
using System.Windows.Forms;

using Microsoft.Data.SqlXml;

using System.Data;
using System.Data.SqlClient;

public class UsingXmlTemplateQueriesForm : System.Windows.Forms.Form
{
	private readonly String XMLQUERYFILENAME	= ConfigurationSettings.AppSettings["Project_Directory"] + @"Chapter 08\OrdersForCustomerQuery.xml";

	private System.Windows.Forms.DataGrid orderDataGrid;
	private System.Windows.Forms.DataGrid customerDataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public UsingXmlTemplateQueriesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.orderDataGrid = new System.Windows.Forms.DataGrid();
		this.customerDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.orderDataGrid)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.customerDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// orderDataGrid
		// 
		this.orderDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.orderDataGrid.CaptionText = "Orders";
		this.orderDataGrid.DataMember = "";
		this.orderDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.orderDataGrid.Location = new System.Drawing.Point(10, 216);
		this.orderDataGrid.Name = "orderDataGrid";
		this.orderDataGrid.ReadOnly = true;
		this.orderDataGrid.Size = new System.Drawing.Size(476, 192);
		this.orderDataGrid.TabIndex = 3;
		// 
		// customerDataGrid
		// 
		this.customerDataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.customerDataGrid.CaptionText = "Customers";
		this.customerDataGrid.DataMember = "";
		this.customerDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.customerDataGrid.Location = new System.Drawing.Point(10, 8);
		this.customerDataGrid.Name = "customerDataGrid";
		this.customerDataGrid.ReadOnly = true;
		this.customerDataGrid.Size = new System.Drawing.Size(476, 192);
		this.customerDataGrid.TabIndex = 2;
		this.customerDataGrid.CurrentCellChanged += new System.EventHandler(this.customerDataGrid_CurrentCellChanged);
		// 
		// UsingXmlTemplateQueriesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 416);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.orderDataGrid,
																		this.customerDataGrid});
		this.Name = "UsingXmlTemplateQueriesForm";
		this.Text = "8.10 UsingXmlTemplateQueriesForm";
		this.Load += new System.EventHandler(this.UsingXmlTemplateQueriesForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.orderDataGrid)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.customerDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void UsingXmlTemplateQueriesForm_Load(object sender, System.EventArgs e)
	{
		String sqlText = "SELECT * FROM Customers";
	
		// load the list of customers into a table
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable dt = new DataTable("Customers");
		da.Fill(dt);

		// bind the default view of the table to the customer grid
		customerDataGrid.DataSource = dt.DefaultView;
		// update orders grid based on the default row selected
		customerDataGrid_CurrentCellChanged(null, null);
	}

	private void customerDataGrid_CurrentCellChanged(object sender, System.EventArgs e)
	{
		// retrieve the selected row from the customer grid
		int row = customerDataGrid.CurrentRowIndex;
		// get the customer ID
		String customerId = ((DataView)customerDataGrid.DataSource).Table.Rows[row][0].ToString();
		// call method to load orders for selected customer
		LoadOrderGrid(customerId);
	}

	private void LoadOrderGrid(String customerId)
	{
		// create the SQL XML command
		SqlXmlCommand cmd = new SqlXmlCommand(ConfigurationSettings.AppSettings["OleDb_SqlAuth_ConnectString"]);
		cmd.CommandType = SqlXmlCommandType.TemplateFile;
		cmd.CommandText = XMLQUERYFILENAME;

		// set the customer ID parameter for the command
		SqlXmlParameter param = cmd.CreateParameter();
		param.Name = "@CustomerID";
		param.Value = customerId;

		// create the DataSet
		DataSet ds = new DataSet();

		// create the SQL XML DataAdapter 
		SqlXmlAdapter da = new SqlXmlAdapter(cmd);

		// fill the DataSet
		try
		{
			da.Fill(ds);
		}
		catch(Exception ex)
		{
			MessageBox.Show(ex.Message);
		}

		// bind the default view of the orders table to the orders grid
		orderDataGrid.DataSource = ds.Tables["Orders"].DefaultView;
		orderDataGrid.CaptionText = "Orders [CustomerID: " + customerId + "]";
	}
}