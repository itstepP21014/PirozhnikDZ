using System;
using System.Configuration;
using System.Windows.Forms;
using System.IO;

using System.Xml;

using System.Data;
using System.Data.SqlClient;

public class StoreXmlFieldForm : System.Windows.Forms.Form
{
	private DataTable dt;
	private SqlDataAdapter da;

	private const String TABLENAME	= "TBL0804";

	private System.Windows.Forms.TextBox idTextBox;
	private System.Windows.Forms.TextBox xmlTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Button writeButton;
	private System.Windows.Forms.Button readButton;
	private System.Windows.Forms.Button clearButton;
	private System.Windows.Forms.Button sampleXmlButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public StoreXmlFieldForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.idTextBox = new System.Windows.Forms.TextBox();
		this.xmlTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.writeButton = new System.Windows.Forms.Button();
		this.readButton = new System.Windows.Forms.Button();
		this.clearButton = new System.Windows.Forms.Button();
		this.sampleXmlButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// idTextBox
		// 
		this.idTextBox.Location = new System.Drawing.Point(72, 8);
		this.idTextBox.Name = "idTextBox";
		this.idTextBox.Size = new System.Drawing.Size(88, 20);
		this.idTextBox.TabIndex = 0;
		this.idTextBox.Text = "";
		// 
		// xmlTextBox
		// 
		this.xmlTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.xmlTextBox.Location = new System.Drawing.Point(72, 32);
		this.xmlTextBox.Multiline = true;
		this.xmlTextBox.Name = "xmlTextBox";
		this.xmlTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.xmlTextBox.Size = new System.Drawing.Size(408, 192);
		this.xmlTextBox.TabIndex = 1;
		this.xmlTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(48, 23);
		this.label1.TabIndex = 2;
		this.label1.Text = "ID";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 32);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(64, 16);
		this.label2.TabIndex = 3;
		this.label2.Text = "XML Field";
		// 
		// writeButton
		// 
		this.writeButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.writeButton.Location = new System.Drawing.Point(328, 232);
		this.writeButton.Name = "writeButton";
		this.writeButton.TabIndex = 4;
		this.writeButton.Text = "Write";
		this.writeButton.Click += new System.EventHandler(this.writeButton_Click);
		// 
		// readButton
		// 
		this.readButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.readButton.Location = new System.Drawing.Point(408, 232);
		this.readButton.Name = "readButton";
		this.readButton.TabIndex = 5;
		this.readButton.Text = "Read";
		this.readButton.Click += new System.EventHandler(this.readButton_Click);
		// 
		// clearButton
		// 
		this.clearButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.clearButton.Location = new System.Drawing.Point(72, 232);
		this.clearButton.Name = "clearButton";
		this.clearButton.TabIndex = 6;
		this.clearButton.Text = "Clear";
		this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
		// 
		// sampleXmlButton
		// 
		this.sampleXmlButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.sampleXmlButton.Location = new System.Drawing.Point(192, 232);
		this.sampleXmlButton.Name = "sampleXmlButton";
		this.sampleXmlButton.Size = new System.Drawing.Size(88, 23);
		this.sampleXmlButton.TabIndex = 7;
		this.sampleXmlButton.Text = "Sample XML";
		this.sampleXmlButton.Click += new System.EventHandler(this.sampleXmlButton_Click);
		// 
		// StoreXmlFieldForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.sampleXmlButton);
		this.Controls.Add(this.clearButton);
		this.Controls.Add(this.readButton);
		this.Controls.Add(this.writeButton);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.label1);
		this.Controls.Add(this.xmlTextBox);
		this.Controls.Add(this.idTextBox);
		this.Name = "StoreXmlFieldForm";
		this.Text = "8.04 StoreXmlFieldForm";
		this.Load += new System.EventHandler(this.StoreXmlFieldForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void StoreXmlFieldForm_Load(object sender, System.EventArgs e)
	{
		String selectText = "SELECT Id, XmlField FROM " + TABLENAME;
		String insertText = "INSERT " + TABLENAME + " (Id, XmlField) " + 
			"VALUES (@Id, @XmlField)";
		String updateText = "UPDATE " + TABLENAME + " " +
			"SET XmlField = @XmlField " +
			"WHERE Id = @Id";

		// create the data adapter
		da = new SqlDataAdapter(selectText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		da.UpdateCommand = new SqlCommand(updateText, da.SelectCommand.Connection);
		da.UpdateCommand.CommandType = CommandType.Text;
		da.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		da.UpdateCommand.Parameters.Add("@XmlField", SqlDbType.NText, 0, "XmlField");

		da.InsertCommand = new SqlCommand(insertText, da.SelectCommand.Connection);
		da.InsertCommand.CommandType = CommandType.Text;
		da.InsertCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		da.InsertCommand.Parameters.Add("@XmlField", SqlDbType.NText, 0, "XmlField");

		dt = new DataTable();
		da.FillSchema(dt, SchemaType.Source);
		da.Fill(dt);
	}

	private void writeButton_Click(object sender, System.EventArgs e)
	{
		// load the ID into variable and text box into XmlDoc
		int id = 0;
		XmlDocument xmlDoc = new XmlDocument();
		try
		{
			id = Int32.Parse(idTextBox.Text);
			xmlDoc.LoadXml(xmlTextBox.Text);
		}
		catch(Exception ex)
		{
			MessageBox.Show("ERROR: " + ex.Message);
			return;
		}

		// find the row with the Id entered
		DataRow row = dt.Rows.Find(new object[] {id});
		if(row != null)
			// for an existing row, update the XmlField
			row["XmlField"] = xmlDoc.InnerXml;
		else
			// for a new row, add the row with the Id and XmlField
			dt.Rows.Add(new object[] {id, xmlDoc.InnerXml});

		// update the database using the DataAdapter
		try
		{
			da.Update(dt);
		}
		catch(Exception ex)
		{
			MessageBox.Show("ERROR: " + ex.Message);
			return;
		}
	}

	private void readButton_Click(object sender, System.EventArgs e)
	{
		// load the ID into variable from text box
		int id = 0;
		try
		{
			id = Int32.Parse(idTextBox.Text);
		}
		catch(Exception ex)
		{
			MessageBox.Show("ERROR: " + ex.Message);
			return;
		}

		// find the row with the Id entered
		DataRow row = dt.Rows.Find(new object[] {id});
		if(row != null)
		{
			// if found, load the XML column value from the row
			XmlDocument xmlDoc = new XmlDocument();
			xmlDoc.LoadXml(row["XmlField"].ToString());

			// display the XML
			xmlTextBox.Text = xmlDoc.InnerXml;
		}
		else
			xmlTextBox.Text = "Record not found for Id = " + id;

	}

	private void sampleXmlButton_Click(object sender, System.EventArgs e)
	{
		DataSet ds = new DataSet();
		
		// fill the Categories table and add it to the DataSet
		SqlDataAdapter da = new SqlDataAdapter("SELECT TOP 3 * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.FillSchema(ds, SchemaType.Source, "Orders");
		da.Fill(ds, "Orders");

		// write the XML for the DataSet to a StringWriter, and output
		StringWriter sw = new StringWriter();
		ds.WriteXml(sw, XmlWriteMode.WriteSchema);
		xmlTextBox.Text = sw.ToString();
		ds.Dispose();

		idTextBox.Clear();
	}

	private void clearButton_Click(object sender, System.EventArgs e)
	{
		idTextBox.Clear();
		xmlTextBox.Clear();
	}
}