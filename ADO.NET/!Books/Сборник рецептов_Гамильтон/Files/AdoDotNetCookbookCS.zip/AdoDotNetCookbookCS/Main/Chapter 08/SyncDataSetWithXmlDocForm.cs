using System;
using System.Configuration;
using System.Windows.Forms;

using System.Xml;

using System.Data;
using System.Data.SqlClient;

public class SyncDataSetWithXmlDocForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";

	private readonly String XMLFILENAME		= ConfigurationSettings.AppSettings["Project_Directory"] + @"Chapter 08\Orders_OrderDetails.xml";

	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.RadioButton method1RadioButton;
	private System.Windows.Forms.RadioButton method2RadioButton;
	private System.Windows.Forms.RadioButton method3RadioButton;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button clearButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public SyncDataSetWithXmlDocForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.method1RadioButton = new System.Windows.Forms.RadioButton();
		this.method2RadioButton = new System.Windows.Forms.RadioButton();
		this.method3RadioButton = new System.Windows.Forms.RadioButton();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.clearButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(408, 432);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 3;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// method1RadioButton
		// 
		this.method1RadioButton.Checked = true;
		this.method1RadioButton.Location = new System.Drawing.Point(8, 8);
		this.method1RadioButton.Name = "method1RadioButton";
		this.method1RadioButton.Size = new System.Drawing.Size(80, 24);
		this.method1RadioButton.TabIndex = 0;
		this.method1RadioButton.TabStop = true;
		this.method1RadioButton.Text = "Method 1";
		// 
		// method2RadioButton
		// 
		this.method2RadioButton.Location = new System.Drawing.Point(104, 8);
		this.method2RadioButton.Name = "method2RadioButton";
		this.method2RadioButton.Size = new System.Drawing.Size(88, 24);
		this.method2RadioButton.TabIndex = 1;
		this.method2RadioButton.Text = "Method 2";
		// 
		// method3RadioButton
		// 
		this.method3RadioButton.Location = new System.Drawing.Point(200, 8);
		this.method3RadioButton.Name = "method3RadioButton";
		this.method3RadioButton.TabIndex = 2;
		this.method3RadioButton.Text = "Method 3";
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 40);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 176);
		this.resultTextBox.TabIndex = 4;
		this.resultTextBox.Text = "";
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 224);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 200);
		this.dataGrid.TabIndex = 5;
		// 
		// clearButton
		// 
		this.clearButton.Location = new System.Drawing.Point(328, 432);
		this.clearButton.Name = "clearButton";
		this.clearButton.TabIndex = 6;
		this.clearButton.Text = "Clear";
		this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
		// 
		// SyncDataSetWithXmlDocForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 466);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.clearButton,
																		this.dataGrid,
																		this.resultTextBox,
																		this.method3RadioButton,
																		this.method2RadioButton,
																		this.method1RadioButton,
																		this.goButton});
		this.Name = "SyncDataSetWithXmlDocForm";
		this.Text = "8.03 SyncDataSetWithXmlDocForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{	
		Cursor.Current = Cursors.WaitCursor;

		DataSet ds = null;
		XmlDataDocument xmlDoc = null;

		if (method1RadioButton.Checked)
		{
			// load DataSet with schema and data
			ds = FillDataSet(true);
			// get the XML document for the DataSet
			xmlDoc = new XmlDataDocument(ds);
		}
		else if(method2RadioButton.Checked)
		{
			// create DataSet with schema, but no data
			ds = FillDataSet(false);
			// get the XML document for the DataSet
			xmlDoc = new XmlDataDocument(ds);
			// load the data into the XML document from the XML file
			xmlDoc.Load(XMLFILENAME);
		}
		else if(method3RadioButton.Checked)
		{
			// create an XML document
			xmlDoc = new XmlDataDocument();
			// get the DataSet for the XML document
			ds = xmlDoc.DataSet;
			// get schema for the DataSet from the XSD inline schema
			ds.ReadXmlSchema(XMLFILENAME);
			// load the data into the XML document from the XML file
			xmlDoc.Load(XMLFILENAME);
		}

		// display the XML data
		resultTextBox.Text = xmlDoc.OuterXml;
		// bind the DataSet to the grid
		dataGrid.DataSource = ds.Tables[ORDERS_TABLE].DefaultView;

		Cursor.Current = Cursors.Default;
	}

	private void clearButton_Click(object sender, System.EventArgs e)
	{
		resultTextBox.Clear();
		dataGrid.DataSource = null;
	}

	private DataSet FillDataSet(bool includeData)
	{
		DataSet ds = new DataSet("Orders_OrderDetails");
		
		SqlDataAdapter da;

		// fill the Order table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders WHERE OrderID <= 10250", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.FillSchema(orderTable, SchemaType.Source);
		if (includeData)
			da.Fill(orderTable);
		ds.Tables.Add(orderTable);

		// fill the OrderDetails table with schema and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM [Order Details] WHERE OrderID <= 10250", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderDetailTable = new DataTable(ORDERDETAILS_TABLE);
		da.FillSchema(orderDetailTable, SchemaType.Source); 
		if (includeData)
			da.Fill(orderDetailTable);
		ds.Tables.Add(orderDetailTable);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
			ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
			true);

		return ds;
	}
}