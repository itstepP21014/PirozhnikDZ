using System;
using System.Configuration;
using System.IO;

using System.Xml;
using System.Xml.Xsl;

using System.Data;
using System.Data.SqlClient;

public class XslTransformForm : System.Windows.Forms.Form
{
	// table name constants
	private const String CATEGORIES_TABLE	= "Categories";

	private readonly String XSLTFILENAME	= ConfigurationSettings.AppSettings["Project_Directory"] + @"Chapter 08\Category.xslt";

	private DataSet ds;

	private System.Windows.Forms.Button transformButton;
	private System.Windows.Forms.TextBox resultTextBox;
	private AxSHDocVw.AxWebBrowser webBrowser;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public XslTransformForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(XslTransformForm));
		this.transformButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.webBrowser = new AxSHDocVw.AxWebBrowser();
		((System.ComponentModel.ISupportInitialize)(this.webBrowser)).BeginInit();
		this.SuspendLayout();
		// 
		// transformButton
		// 
		this.transformButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.transformButton.Location = new System.Drawing.Point(532, 436);
		this.transformButton.Name = "transformButton";
		this.transformButton.TabIndex = 0;
		this.transformButton.Text = "Transform";
		this.transformButton.Click += new System.EventHandler(this.transformButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 240);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(596, 184);
		this.resultTextBox.TabIndex = 3;
		this.resultTextBox.Text = "";
		// 
		// webBrowser
		// 
		this.webBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.webBrowser.Enabled = true;
		this.webBrowser.Location = new System.Drawing.Point(8, 8);
		this.webBrowser.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("webBrowser.OcxState")));
		this.webBrowser.Size = new System.Drawing.Size(596, 216);
		this.webBrowser.TabIndex = 4;
		this.webBrowser.DocumentComplete += new AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEventHandler(this.webBrowser_DocumentComplete);
		// 
		// XslTransformForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(616, 470);
		this.Controls.Add(this.webBrowser);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.transformButton);
		this.Name = "XslTransformForm";
		this.Text = "8.07 XslTransformForm";
		this.Load += new System.EventHandler(this.XslTransformForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.webBrowser)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void XslTransformForm_Load(object sender, System.EventArgs e)
	{
		// fill the Categories within a DataSet
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Categories", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		ds = new DataSet("CategoriesDS");			
		da.Fill(ds, CATEGORIES_TABLE);
	}

	private void transformButton_Click(object sender, System.EventArgs e)
	{
		// create parameters to create web browser
		String url = "about:blank";
		object flags = 0;
		object targetFrameName = String.Empty;
		object postData = String.Empty;
		object headers = String.Empty;

		// have to wait for the navigation to complete so use the DocumentComplete event for the rest of the processing
		webBrowser.Navigate(url, ref flags ,ref targetFrameName, ref postData, ref headers);
	}

	private void webBrowser_DocumentComplete(object sender, AxSHDocVw.DWebBrowserEvents2_DocumentCompleteEvent e)
	{
		// apply the XML transformation storing results to StringWriter
		XslTransform xslt = new XslTransform();
		xslt.Load(XSLTFILENAME);
		StringWriter sw = new StringWriter();
		xslt.Transform(new XmlDataDocument(ds), null, sw, (XmlResolver)null);

		// load the results of the transformation into the web browser
		mshtml.IHTMLDocument2 htmlDoc = (mshtml.IHTMLDocument2)webBrowser.Document;
		htmlDoc.body.innerHTML = sw.ToString();

		// display the results of the transformation
		resultTextBox.Text = sw.ToString();
	}
}