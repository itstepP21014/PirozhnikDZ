using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class XmlElementsOrAttributesForm : System.Windows.Forms.Form
{
	private DataSet ds;

	private System.Windows.Forms.TextBox xmlTextBox;
	private System.Windows.Forms.GroupBox groupBox1;
	private System.Windows.Forms.RadioButton tableAttributeRadioButton;
	private System.Windows.Forms.RadioButton tableElementRadioButton;
	private System.Windows.Forms.RadioButton tableHiddenRadioButton;
	private System.Windows.Forms.GroupBox groupBox2;
	private System.Windows.Forms.RadioButton columnAttributeRadioButton;
	private System.Windows.Forms.RadioButton columnHiddenRadioButton;
	private System.Windows.Forms.RadioButton columnElementRadioButton;
	private System.Windows.Forms.RadioButton columnSimpleContentRadioButton;
	private System.Windows.Forms.Button refreshButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public XmlElementsOrAttributesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.xmlTextBox = new System.Windows.Forms.TextBox();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.tableAttributeRadioButton = new System.Windows.Forms.RadioButton();
		this.tableElementRadioButton = new System.Windows.Forms.RadioButton();
		this.tableHiddenRadioButton = new System.Windows.Forms.RadioButton();
		this.groupBox2 = new System.Windows.Forms.GroupBox();
		this.columnAttributeRadioButton = new System.Windows.Forms.RadioButton();
		this.columnHiddenRadioButton = new System.Windows.Forms.RadioButton();
		this.columnElementRadioButton = new System.Windows.Forms.RadioButton();
		this.columnSimpleContentRadioButton = new System.Windows.Forms.RadioButton();
		this.refreshButton = new System.Windows.Forms.Button();
		this.groupBox1.SuspendLayout();
		this.groupBox2.SuspendLayout();
		this.SuspendLayout();
		// 
		// xmlTextBox
		// 
		this.xmlTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.xmlTextBox.Location = new System.Drawing.Point(8, 8);
		this.xmlTextBox.Multiline = true;
		this.xmlTextBox.Name = "xmlTextBox";
		this.xmlTextBox.ReadOnly = true;
		this.xmlTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.xmlTextBox.Size = new System.Drawing.Size(476, 152);
		this.xmlTextBox.TabIndex = 0;
		this.xmlTextBox.Text = "";
		// 
		// groupBox1
		// 
		this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.groupBox1.Controls.Add(this.tableHiddenRadioButton);
		this.groupBox1.Controls.Add(this.tableElementRadioButton);
		this.groupBox1.Controls.Add(this.tableAttributeRadioButton);
		this.groupBox1.Location = new System.Drawing.Point(8, 168);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(152, 88);
		this.groupBox1.TabIndex = 1;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Table ColumnMapping";
		// 
		// tableAttributeRadioButton
		// 
		this.tableAttributeRadioButton.Checked = true;
		this.tableAttributeRadioButton.Location = new System.Drawing.Point(8, 16);
		this.tableAttributeRadioButton.Name = "tableAttributeRadioButton";
		this.tableAttributeRadioButton.Size = new System.Drawing.Size(104, 16);
		this.tableAttributeRadioButton.TabIndex = 0;
		this.tableAttributeRadioButton.TabStop = true;
		this.tableAttributeRadioButton.Text = "Attribute";
		// 
		// tableElementRadioButton
		// 
		this.tableElementRadioButton.Location = new System.Drawing.Point(8, 32);
		this.tableElementRadioButton.Name = "tableElementRadioButton";
		this.tableElementRadioButton.Size = new System.Drawing.Size(104, 16);
		this.tableElementRadioButton.TabIndex = 1;
		this.tableElementRadioButton.Text = "Element";
		// 
		// tableHiddenRadioButton
		// 
		this.tableHiddenRadioButton.Location = new System.Drawing.Point(8, 48);
		this.tableHiddenRadioButton.Name = "tableHiddenRadioButton";
		this.tableHiddenRadioButton.Size = new System.Drawing.Size(104, 16);
		this.tableHiddenRadioButton.TabIndex = 2;
		this.tableHiddenRadioButton.Text = "Hidden";
		// 
		// groupBox2
		// 
		this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.groupBox2.Controls.Add(this.columnSimpleContentRadioButton);
		this.groupBox2.Controls.Add(this.columnHiddenRadioButton);
		this.groupBox2.Controls.Add(this.columnElementRadioButton);
		this.groupBox2.Controls.Add(this.columnAttributeRadioButton);
		this.groupBox2.Location = new System.Drawing.Point(168, 168);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new System.Drawing.Size(216, 88);
		this.groupBox2.TabIndex = 2;
		this.groupBox2.TabStop = false;
		this.groupBox2.Text = "ContactName Field ColumnMapping";
		// 
		// columnAttributeRadioButton
		// 
		this.columnAttributeRadioButton.Checked = true;
		this.columnAttributeRadioButton.Location = new System.Drawing.Point(8, 16);
		this.columnAttributeRadioButton.Name = "columnAttributeRadioButton";
		this.columnAttributeRadioButton.Size = new System.Drawing.Size(104, 16);
		this.columnAttributeRadioButton.TabIndex = 1;
		this.columnAttributeRadioButton.TabStop = true;
		this.columnAttributeRadioButton.Text = "Attribute";
		// 
		// columnHiddenRadioButton
		// 
		this.columnHiddenRadioButton.Location = new System.Drawing.Point(8, 48);
		this.columnHiddenRadioButton.Name = "columnHiddenRadioButton";
		this.columnHiddenRadioButton.Size = new System.Drawing.Size(104, 16);
		this.columnHiddenRadioButton.TabIndex = 4;
		this.columnHiddenRadioButton.Text = "Hidden";
		// 
		// columnElementRadioButton
		// 
		this.columnElementRadioButton.Location = new System.Drawing.Point(8, 32);
		this.columnElementRadioButton.Name = "columnElementRadioButton";
		this.columnElementRadioButton.Size = new System.Drawing.Size(104, 16);
		this.columnElementRadioButton.TabIndex = 3;
		this.columnElementRadioButton.Text = "Element";
		// 
		// columnSimpleContentRadioButton
		// 
		this.columnSimpleContentRadioButton.Location = new System.Drawing.Point(8, 64);
		this.columnSimpleContentRadioButton.Name = "columnSimpleContentRadioButton";
		this.columnSimpleContentRadioButton.Size = new System.Drawing.Size(104, 16);
		this.columnSimpleContentRadioButton.TabIndex = 5;
		this.columnSimpleContentRadioButton.Text = "SimpleContent";
		// 
		// refreshButton
		// 
		this.refreshButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.refreshButton.Location = new System.Drawing.Point(408, 232);
		this.refreshButton.Name = "refreshButton";
		this.refreshButton.TabIndex = 3;
		this.refreshButton.Text = "Refresh";
		this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
		// 
		// XmlElementsOrAttributesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.refreshButton);
		this.Controls.Add(this.groupBox2);
		this.Controls.Add(this.groupBox1);
		this.Controls.Add(this.xmlTextBox);
		this.Name = "XmlElementsOrAttributesForm";
		this.Text = "8.09 XmlElementsOrAttributesForm";
		this.Load += new System.EventHandler(this.XmlElementsOrAttributesForm_Load);
		this.groupBox1.ResumeLayout(false);
		this.groupBox2.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion

	private void XmlElementsOrAttributesForm_Load(object sender, System.EventArgs e)
	{
		ds = new DataSet("CustomersDataSet");
		
		// get the top 2 rows from the Customers table
		SqlDataAdapter da = new SqlDataAdapter("SELECT TOP 2 * FROM Customers", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(ds, "Customers");
		// display the XML
		xmlTextBox.Text = ds.GetXml();
	}

	private void refreshButton_Click(object sender, System.EventArgs e)
	{
		// set the mapping type for each column in the table
		foreach(DataTable table in ds.Tables)
			foreach(DataColumn column in table.Columns)
			{
				if(tableAttributeRadioButton.Checked)
					column.ColumnMapping = MappingType.Attribute;
				else if(tableElementRadioButton.Checked)
					column.ColumnMapping = MappingType.Element;
				else if(tableHiddenRadioButton.Checked)
					column.ColumnMapping = MappingType.Hidden;
			}

		// set the mapping type for the ContactName column
		DataColumn dc = ds.Tables["Customers"].Columns["ContactName"];
		if(columnAttributeRadioButton.Checked)
			dc.ColumnMapping = MappingType.Attribute;
		else if(columnElementRadioButton.Checked)
			dc.ColumnMapping = MappingType.Element;
		else if(columnHiddenRadioButton.Checked)
			dc.ColumnMapping = MappingType.Hidden;
		else if(columnSimpleContentRadioButton.Checked)
			dc.ColumnMapping = MappingType.SimpleContent;

		// display the XML
		xmlTextBox.Text = ds.GetXml();
	}
}