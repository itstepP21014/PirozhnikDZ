using System;
using System.Configuration;

using System.Xml;

using System.Data;
using System.Data.SqlClient;

public class ReadXmlDirectForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.Button readXmlButton;
	private System.Windows.Forms.TextBox xmlTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ReadXmlDirectForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.readXmlButton = new System.Windows.Forms.Button();
		this.xmlTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// readXmlButton
		// 
		this.readXmlButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.readXmlButton.Location = new System.Drawing.Point(408, 232);
		this.readXmlButton.Name = "readXmlButton";
		this.readXmlButton.TabIndex = 0;
		this.readXmlButton.Text = "Read XML";
		this.readXmlButton.Click += new System.EventHandler(this.readXmlButton_Click);
		// 
		// xmlTextBox
		// 
		this.xmlTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.xmlTextBox.Location = new System.Drawing.Point(8, 8);
		this.xmlTextBox.Multiline = true;
		this.xmlTextBox.Name = "xmlTextBox";
		this.xmlTextBox.ReadOnly = true;
		this.xmlTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.xmlTextBox.Size = new System.Drawing.Size(476, 216);
		this.xmlTextBox.TabIndex = 1;
		this.xmlTextBox.Text = "";
		// 
		// ReadXmlDirectForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.xmlTextBox,
																		this.readXmlButton});
		this.Name = "ReadXmlDirectForm";
		this.Text = "8.05 ReadXmlDirectForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void readXmlButton_Click(object sender, System.EventArgs e)
	{
		// select statement to read XML directly
		String sqlText = "SELECT * FROM Orders FOR XML AUTO, XMLDATA";

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		conn.Open();
		// create the command
		SqlCommand cmd = new SqlCommand(sqlText, conn);

		// read the XML data into a XML reader
		XmlReader xr = cmd.ExecuteXmlReader();

		// read the data from the XML reader into the DataSet
		DataSet ds = new DataSet();
		ds.ReadXml(xr, XmlReadMode.Fragment);
		xr.Close();
		conn.Close();

		xmlTextBox.Text = ds.GetXml();
	}
}