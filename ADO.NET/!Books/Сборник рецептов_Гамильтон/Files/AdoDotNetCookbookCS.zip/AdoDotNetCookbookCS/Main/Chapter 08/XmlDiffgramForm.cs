using System;
using System.Configuration;
using System.Text;
using System.IO;

using System.Xml;
using System.Xml.Schema;

using System.Data;
using System.Data.SqlClient;

public class XmlDiffgramForm : System.Windows.Forms.Form
{
	// table name constants
	private const String CATEGORIES_TABLE		= "Categories";

	// field name constants
	private const String CATEGORYNAME_FIELD		= "CategoryName";

	private readonly String XMLDIFFGRAMFILENAME	= ConfigurationSettings.AppSettings["Temp_Directory"] + "CategoriesDiffgram.xml";

	private DataSet ds;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button makeChangesButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public XmlDiffgramForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.makeChangesButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(9, 10);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 3;
		this.resultTextBox.Text = "";
		// 
		// makeChangesButton
		// 
		this.makeChangesButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.makeChangesButton.Location = new System.Drawing.Point(380, 234);
		this.makeChangesButton.Name = "makeChangesButton";
		this.makeChangesButton.Size = new System.Drawing.Size(104, 23);
		this.makeChangesButton.TabIndex = 2;
		this.makeChangesButton.Text = "Make Changes";
		this.makeChangesButton.Click += new System.EventHandler(this.makeChangesButton_Click);
		// 
		// XmlDiffgramForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.makeChangesButton);
		this.Name = "XmlDiffgramForm";
		this.Text = "8.08 XmlDiffgramForm";
		this.Load += new System.EventHandler(this.XmlDiffgramForm_Load);
		this.ResumeLayout(false);

	}
	#endregion

	private void XmlDiffgramForm_Load(object sender, System.EventArgs e)
	{
		// select fields from Categories table without the Picture BLOB
		String sqlText = "SELECT CategoryID, CategoryName, Description " +
			"FROM Categories";

		// load the Categories table into the DataSet
		SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		ds = new DataSet();
		da.Fill(ds, "Categories");
	
		DisplayDiffGram();
	}

	private void makeChangesButton_Click(object sender, System.EventArgs e)
	{
		// disable the make changes button
		makeChangesButton.Enabled = false;

		DataTable dt = ds.Tables["Categories"];

		// delete the first row
		dt.Rows[0].Delete();

		// modify the second row
		dt.Rows[1][CATEGORYNAME_FIELD] += "New ";

		// insert a row
		DataRow row = dt.NewRow();
		row.ItemArray = new object[] {0, "New Category0", "New Category0 Description"};
		dt.Rows.InsertAt(row, 0);

		// add a row
		dt.Rows.Add(new object[] {9, "New Category9", "New Category9 Description"});

		DisplayDiffGram();
	}

	private void DisplayDiffGram()
	{
		// write the XML diffgram to a memory stream
		MemoryStream ms = new MemoryStream();
		ds.WriteXml(ms, XmlWriteMode.DiffGram);
		
		// write the memory stream to a file
		FileStream fs = new FileStream(XMLDIFFGRAMFILENAME, FileMode.Create, FileAccess.Write);
		ms.WriteTo(fs);
		fs.Close();

		// display the XML diffgram
		byte[] result = ms.ToArray();
		ms.Close();
		resultTextBox.Text = Encoding.UTF8.GetString(result,0,result.Length);
	}
}