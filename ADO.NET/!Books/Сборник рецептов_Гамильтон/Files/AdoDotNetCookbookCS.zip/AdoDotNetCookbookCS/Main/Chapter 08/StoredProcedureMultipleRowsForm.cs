using System;
using System.Configuration;
using System.Windows.Forms;
using System.Text;
using System.IO;

using System.Data;
using System.Data.SqlClient;

public class StoredProcedureMultipleRowsForm : System.Windows.Forms.Form
{
	private DataSet ds;

	private const String TABLENAME				= "TBL0811";
	private const String STOREDPROCEDURE_NAME	= "SP0811_Update";

	private System.Windows.Forms.Button updateButton;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public StoredProcedureMultipleRowsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.updateButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// updateButton
		// 
		this.updateButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.updateButton.Location = new System.Drawing.Point(408, 232);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 0;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 1;
		// 
		// StoredProcedureMultipleRowsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.dataGrid,
																		this.updateButton});
		this.Name = "StoredProcedureMultipleRowsForm";
		this.Text = "6.12 StoredProcedureMultipleRowsForm";
		this.Load += new System.EventHandler(this.StoredProcedureMultipleRowsForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void StoredProcedureMultipleRowsForm_Load(object sender, System.EventArgs e)
	{
		ds = new DataSet();

		// create the DataAdapter
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM " + TABLENAME, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// load the schema and data for the table
		da.FillSchema(ds, SchemaType.Source, TABLENAME);
		da.Fill(ds, TABLENAME);

		// columns in XML representation of data as attributes
		foreach(DataColumn col in ds.Tables[TABLENAME].Columns)
			col.ColumnMapping = MappingType.Attribute;

		// this technique only supports update and insert; turn off delete
		// records in the default view
		//ds.Tables[TABLENAME].DefaultView.AllowDelete = false;
		// bind the default view of the table to the grid
		dataGrid.DataSource = ds.Tables[TABLENAME].DefaultView;
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder sb;
		StringWriter sw;

		// create a connection and command for the update stored procedure
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommand cmd = new SqlCommand();
		cmd.Connection = conn;
		cmd.CommandText = STOREDPROCEDURE_NAME;
		cmd.CommandType = CommandType.StoredProcedure;

		// inserted and updated records
		if (ds.HasChanges(DataRowState.Added | DataRowState.Modified))
		{
			sb = new StringBuilder();
			sw = new StringWriter(sb);

			ds.GetChanges(DataRowState.Added | DataRowState.Modified).WriteXml(sw, XmlWriteMode.WriteSchema);
			cmd.Parameters.Add("@data", SqlDbType.NText);
			cmd.Parameters["@data"].Value = sb.ToString();

			sw.Close();
		}

		// deleted records
		if (ds.HasChanges(DataRowState.Deleted))
		{
			sb = new StringBuilder();
			sw = new StringWriter(sb);

			// get the DataSet containing the records deleted and call
			// RejectChanges() so that the original version of those rows
			// are available so that WriteXml() works.
			DataSet dsChange = ds.GetChanges(DataRowState.Deleted);
			dsChange.RejectChanges();
			dsChange.WriteXml(sw, XmlWriteMode.WriteSchema);

			cmd.Parameters.Add("@datadelete", SqlDbType.NText);
			cmd.Parameters["@datadelete"].Value = sb.ToString();

			sw.Close();
		}

		// execute the stored procedure
		conn.Open();
		cmd.ExecuteNonQuery();
		conn.Close();

		ds.AcceptChanges();

		MessageBox.Show("Update completed.", "Multiple Row Update/Insert Stored Procedure", MessageBoxButtons.OK, MessageBoxIcon.Information);
	}
}