using System;
using System.Configuration;
using System.Windows.Forms;
using System.Text;
using System.IO;

using System.Xml;
using System.Xml.Schema;

using System.Data;
using System.Data.SqlClient;

public class XsdSchemaFileForm : System.Windows.Forms.Form
{
	// table name constants
	private const String ORDERS_TABLE		= "Orders";
	private const String ORDERDETAILS_TABLE	= "OrderDetails";

	// relation name constants
	private const String ORDERS_ORDERDETAILS_RELATION = "Orders_OrderDetails_Relation";

	// field name constants
	private const String ORDERID_FIELD		= "OrderID";

	private System.Windows.Forms.Button readSchemaButton;
	private System.Windows.Forms.Button writeSchemaButton;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button clearButton;
	private System.Windows.Forms.DataGrid resultDataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public XsdSchemaFileForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.readSchemaButton = new System.Windows.Forms.Button();
		this.writeSchemaButton = new System.Windows.Forms.Button();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.clearButton = new System.Windows.Forms.Button();
		this.resultDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// readSchemaButton
		// 
		this.readSchemaButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.readSchemaButton.Location = new System.Drawing.Point(408, 332);
		this.readSchemaButton.Name = "readSchemaButton";
		this.readSchemaButton.TabIndex = 1;
		this.readSchemaButton.Text = "Read";
		this.readSchemaButton.Click += new System.EventHandler(this.readSchemaButton_Click);
		// 
		// writeSchemaButton
		// 
		this.writeSchemaButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.writeSchemaButton.Location = new System.Drawing.Point(328, 332);
		this.writeSchemaButton.Name = "writeSchemaButton";
		this.writeSchemaButton.TabIndex = 0;
		this.writeSchemaButton.Text = "Write";
		this.writeSchemaButton.Click += new System.EventHandler(this.writeSchemaButton_Click);
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 184);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 136);
		this.resultTextBox.TabIndex = 2;
		this.resultTextBox.Text = "";
		// 
		// clearButton
		// 
		this.clearButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.clearButton.Location = new System.Drawing.Point(8, 332);
		this.clearButton.Name = "clearButton";
		this.clearButton.TabIndex = 3;
		this.clearButton.Text = "Clear";
		this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
		// 
		// resultDataGrid
		// 
		this.resultDataGrid.DataMember = "";
		this.resultDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.resultDataGrid.Location = new System.Drawing.Point(8, 8);
		this.resultDataGrid.Name = "resultDataGrid";
		this.resultDataGrid.Size = new System.Drawing.Size(472, 160);
		this.resultDataGrid.TabIndex = 4;
		// 
		// XsdSchemaFileForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 366);
		this.Controls.Add(this.resultDataGrid);
		this.Controls.Add(this.clearButton);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.writeSchemaButton);
		this.Controls.Add(this.readSchemaButton);
		this.Name = "XsdSchemaFileForm";
		this.Text = "8.01 XsdSchemaFileForm";
		((System.ComponentModel.ISupportInitialize)(this.resultDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void writeSchemaButton_Click(object sender, System.EventArgs e)
	{
		DataSet ds = new DataSet();
		
		SqlDataAdapter da;

		// fill the Order table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.FillSchema(orderTable, SchemaType.Source);
		da.Fill(orderTable);
		ds.Tables.Add(orderTable);

		// fill the OrderDetails table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM [Order Details]", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		DataTable orderDetailTable = new DataTable(ORDERDETAILS_TABLE);
		da.FillSchema(orderDetailTable, SchemaType.Source);
		da.Fill(orderDetailTable);
		ds.Tables.Add(orderDetailTable);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
			ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
			true);

		// bind the default view of the Orders table to the grid
		resultDataGrid.DataSource = ds.Tables[ORDERS_TABLE].DefaultView;

		// write the XSD schema to a file
		// display file dialog to select XSD file to write
		SaveFileDialog sfd = new SaveFileDialog();
		sfd.InitialDirectory = System.IO.Path.GetTempPath();
		sfd.Filter = "XSD Files (*.xsd)|*.xsd|All files (*.*)|*.*";
		sfd.FilterIndex = 1;

		if (sfd.ShowDialog() == DialogResult.OK)
		{
			FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write);
			// create an XmlTextWriter using the file stream
			XmlTextWriter xtw = new XmlTextWriter(fs, Encoding.Unicode);

			try
			{
				// write the XSD schema to the file
				ds.WriteXmlSchema(xtw);

				resultTextBox.Text = "XSD file written.";
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				xtw.Close();
			}
		}
	}

	private void readSchemaButton_Click(object sender, System.EventArgs e)
	{
		// write the XSD schema from a file
		// display file dialog to select XSD file to read
		OpenFileDialog ofd = new OpenFileDialog();
		ofd.InitialDirectory = System.IO.Path.GetTempPath();
		ofd.Filter = "XSD Files (*.xsd)|*.xsd|All files (*.*)|*.*";
		ofd.FilterIndex = 1;

		if (ofd.ShowDialog() == DialogResult.OK)
		{
			FileStream fs = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read);
			// create an XmlTextReader using the file stream
			XmlTextReader xtr = new XmlTextReader(fs);
			
			try
			{
				// read the schema into the DataSet
				DataSet ds = new DataSet();
				ds.ReadXmlSchema(xtr);

				// bind the default view of the Orders table to the grid
				resultDataGrid.DataSource = ds.Tables[ORDERS_TABLE].DefaultView;

				// write the XSD schema to a memory stream and display the XSD schema
				MemoryStream ms = new MemoryStream();
				ds.WriteXmlSchema(ms);
				byte[] result = ms.ToArray();
				ms.Close();

				resultTextBox.Text = Encoding.UTF8.GetString(result, 0, result.Length);
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				xtr.Close();
			}
		}
	}

	private void clearButton_Click(object sender, System.EventArgs e)
	{
		// clear the data grid and the result text box
		resultDataGrid.DataSource = null;
		resultTextBox.Clear();
	}
}