using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class EnforceBusinessRulesWithColumnExpressionsForm : System.Windows.Forms.Form
{
	private DataTable dt;
	private SqlDataAdapter da;

	private const String TABLENAME				= "TBL0607";

	// table column name constants 
	private const String ID_FIELD				= "Id";
	private const String FIELD1_FIELD			= "Field1";
	private const String FIELD2_FIELD			= "Field2";
	private const String CONSTRAINT_EXPRESSION	= "ConstraintExpression";

	// stored procedure name constants
	private const String DELETE_SP				= "SP0607_Delete";
	private const String GET_SP					= "SP0607_Get";
	private const String INSERT_SP				= "SP0607_Insert";
	private const String UPDATE_SP				= "SP0607_Update";

	// stored procedure parameter name constants for table
	private const String ID_PARM				= "@Id";
	private const String FIELD1_PARM			= "@Field1";
	private const String FIELD2_PARM			= "@Field2";

	private System.Windows.Forms.Button updateButton;
	private System.Windows.Forms.DataGrid dataGrid;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public EnforceBusinessRulesWithColumnExpressionsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.updateButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// updateButton
		// 
		this.updateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.updateButton.Location = new System.Drawing.Point(411, 234);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 3;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(7, 10);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(480, 216);
		this.dataGrid.TabIndex = 2;
		// 
		// EnforceBusinessRulesWithColumnExpressionsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.updateButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "EnforceBusinessRulesWithColumnExpressionsForm";
		this.Text = "6.07 EnforceBusinessRulesWithColumnExpressionsForm";
		this.Load += new System.EventHandler(this.EnforceBusinessRulesWithColumnExpressionsForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void EnforceBusinessRulesWithColumnExpressionsForm_Load(object sender, System.EventArgs e)
	{
		DataColumnCollection cols;

		// build the table
		dt = new DataTable(TABLENAME);
		cols = dt.Columns;
		cols.Add(ID_FIELD, typeof(Int32));
		cols.Add(FIELD1_FIELD, typeof(Int32));
		cols.Add(FIELD2_FIELD, typeof(Int32));
		// add the primary key
		dt.PrimaryKey = new DataColumn[] {cols[ID_FIELD]};
		// expression to evaluate whether the sum of Field1 and Field2 equals 10
		cols.Add(CONSTRAINT_EXPRESSION, typeof(Boolean), FIELD1_FIELD + "+" + FIELD2_FIELD + " = 10");

		// create the DataAdapter, handling the RowUpdating event
		da = new SqlDataAdapter();
		da.RowUpdating += new SqlRowUpdatingEventHandler(da_RowUpdating);
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// build the  select command
		SqlCommand selectCommand = new SqlCommand(GET_SP, conn);
		selectCommand.CommandType = CommandType.StoredProcedure;
		da.SelectCommand = selectCommand;

		// build the  delete command
		SqlCommand deleteCommand = new SqlCommand(DELETE_SP, conn);
		deleteCommand.CommandType = CommandType.StoredProcedure;
		deleteCommand.Parameters.Add(ID_PARM, SqlDbType.Int, 0, ID_FIELD);
		da.DeleteCommand = deleteCommand;

		// build the  insert command
		SqlCommand insertCommand = new SqlCommand(INSERT_SP, conn);
		insertCommand.CommandType = CommandType.StoredProcedure;
		insertCommand.Parameters.Add(ID_PARM, SqlDbType.Int, 0, ID_FIELD);
		insertCommand.Parameters.Add(FIELD1_PARM, SqlDbType.Int, 0, FIELD1_FIELD);
		insertCommand.Parameters.Add(FIELD2_PARM, SqlDbType.Int, 0, FIELD2_FIELD);
		da.InsertCommand = insertCommand;

		// build the  update command
		SqlCommand updateCommand = new SqlCommand(UPDATE_SP, conn);
		updateCommand.CommandType = CommandType.StoredProcedure;
		updateCommand.Parameters.Add(ID_PARM, SqlDbType.Int, 0, ID_FIELD);
		updateCommand.Parameters.Add(FIELD1_PARM, SqlDbType.Int, 0, FIELD1_FIELD);
		updateCommand.Parameters.Add(FIELD2_PARM, SqlDbType.Int, 0, FIELD2_FIELD);
		da.UpdateCommand = updateCommand;

		// fill the table
		da.Fill(dt);

		// bind the default view of the table to the grid
		dataGrid.DataSource = dt.DefaultView;
	}

	private void da_RowUpdating(object sender, SqlRowUpdatingEventArgs e)
	{
		// for insert or update statements, check that the
		// calculated constraint column is true
		if((e.StatementType == StatementType.Insert || e.StatementType == StatementType.Update) &&
			!(bool)e.Row[CONSTRAINT_EXPRESSION])
		{
			// constraint has not been met
			// set an error on the row and skip it
			e.Row.RowError = "Constraint error.";
			e.Status = UpdateStatus.SkipCurrentRow;
		}
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		try
		{
			da.Update(dt);
		}
		catch(Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}
}