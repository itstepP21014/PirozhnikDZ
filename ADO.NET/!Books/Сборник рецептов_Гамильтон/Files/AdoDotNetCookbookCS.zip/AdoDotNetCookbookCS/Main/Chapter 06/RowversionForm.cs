using System;
using System.Configuration;
using System.Windows.Forms;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class RowversionForm : System.Windows.Forms.Form
{
	private DataTable dtA, dtB;
	private SqlDataAdapter daA, daB;

	private const String TABLENAME = "TBL0610";

	private System.Windows.Forms.Button updateAButton;
	private System.Windows.Forms.TextBox aIdTextBox;
	private System.Windows.Forms.TextBox aField1TextBox;
	private System.Windows.Forms.TextBox aRowversionTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.Label label4;
	private System.Windows.Forms.Label label5;
	private System.Windows.Forms.Label label6;
	private System.Windows.Forms.TextBox bRowversionTextBox;
	private System.Windows.Forms.TextBox bField1TextBox;
	private System.Windows.Forms.TextBox bIdTextBox;
	private System.Windows.Forms.Button updateBButton;
	private System.Windows.Forms.Button refreshAButton;
	private System.Windows.Forms.Button refreshBButton;
	private System.Windows.Forms.GroupBox groupBox1;
	private System.Windows.Forms.GroupBox groupBox2;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public RowversionForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.updateAButton = new System.Windows.Forms.Button();
		this.updateBButton = new System.Windows.Forms.Button();
		this.aIdTextBox = new System.Windows.Forms.TextBox();
		this.aField1TextBox = new System.Windows.Forms.TextBox();
		this.aRowversionTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.label4 = new System.Windows.Forms.Label();
		this.label5 = new System.Windows.Forms.Label();
		this.label6 = new System.Windows.Forms.Label();
		this.bRowversionTextBox = new System.Windows.Forms.TextBox();
		this.bField1TextBox = new System.Windows.Forms.TextBox();
		this.bIdTextBox = new System.Windows.Forms.TextBox();
		this.refreshAButton = new System.Windows.Forms.Button();
		this.refreshBButton = new System.Windows.Forms.Button();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.groupBox2 = new System.Windows.Forms.GroupBox();
		this.groupBox1.SuspendLayout();
		this.groupBox2.SuspendLayout();
		this.SuspendLayout();
		// 
		// updateAButton
		// 
		this.updateAButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.updateAButton.Location = new System.Drawing.Point(280, 24);
		this.updateAButton.Name = "updateAButton";
		this.updateAButton.TabIndex = 2;
		this.updateAButton.Tag = "A";
		this.updateAButton.Text = "Update";
		this.updateAButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// updateBButton
		// 
		this.updateBButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.updateBButton.Location = new System.Drawing.Point(280, 24);
		this.updateBButton.Name = "updateBButton";
		this.updateBButton.TabIndex = 3;
		this.updateBButton.Tag = "B";
		this.updateBButton.Text = "Update";
		this.updateBButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// aIdTextBox
		// 
		this.aIdTextBox.Location = new System.Drawing.Point(88, 24);
		this.aIdTextBox.Name = "aIdTextBox";
		this.aIdTextBox.ReadOnly = true;
		this.aIdTextBox.Size = new System.Drawing.Size(176, 20);
		this.aIdTextBox.TabIndex = 4;
		this.aIdTextBox.Text = "";
		// 
		// aField1TextBox
		// 
		this.aField1TextBox.Location = new System.Drawing.Point(88, 48);
		this.aField1TextBox.Name = "aField1TextBox";
		this.aField1TextBox.Size = new System.Drawing.Size(176, 20);
		this.aField1TextBox.TabIndex = 5;
		this.aField1TextBox.Text = "";
		// 
		// aRowversionTextBox
		// 
		this.aRowversionTextBox.Location = new System.Drawing.Point(88, 72);
		this.aRowversionTextBox.Name = "aRowversionTextBox";
		this.aRowversionTextBox.ReadOnly = true;
		this.aRowversionTextBox.Size = new System.Drawing.Size(176, 20);
		this.aRowversionTextBox.TabIndex = 6;
		this.aRowversionTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(16, 24);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(72, 23);
		this.label1.TabIndex = 7;
		this.label1.Text = "Id:";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(16, 48);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(72, 23);
		this.label2.TabIndex = 8;
		this.label2.Text = "Field1:";
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(16, 72);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(72, 23);
		this.label3.TabIndex = 9;
		this.label3.Text = "rowversion:";
		// 
		// label4
		// 
		this.label4.Location = new System.Drawing.Point(8, 72);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(72, 23);
		this.label4.TabIndex = 15;
		this.label4.Text = "rowversion:";
		// 
		// label5
		// 
		this.label5.Location = new System.Drawing.Point(8, 48);
		this.label5.Name = "label5";
		this.label5.Size = new System.Drawing.Size(72, 23);
		this.label5.TabIndex = 14;
		this.label5.Text = "Field1:";
		// 
		// label6
		// 
		this.label6.Location = new System.Drawing.Point(8, 24);
		this.label6.Name = "label6";
		this.label6.Size = new System.Drawing.Size(72, 23);
		this.label6.TabIndex = 13;
		this.label6.Text = "Id:";
		// 
		// bRowversionTextBox
		// 
		this.bRowversionTextBox.Location = new System.Drawing.Point(88, 72);
		this.bRowversionTextBox.Name = "bRowversionTextBox";
		this.bRowversionTextBox.ReadOnly = true;
		this.bRowversionTextBox.Size = new System.Drawing.Size(176, 20);
		this.bRowversionTextBox.TabIndex = 12;
		this.bRowversionTextBox.Text = "";
		// 
		// bField1TextBox
		// 
		this.bField1TextBox.Location = new System.Drawing.Point(88, 48);
		this.bField1TextBox.Name = "bField1TextBox";
		this.bField1TextBox.Size = new System.Drawing.Size(176, 20);
		this.bField1TextBox.TabIndex = 11;
		this.bField1TextBox.Text = "";
		// 
		// bIdTextBox
		// 
		this.bIdTextBox.Location = new System.Drawing.Point(88, 24);
		this.bIdTextBox.Name = "bIdTextBox";
		this.bIdTextBox.ReadOnly = true;
		this.bIdTextBox.Size = new System.Drawing.Size(176, 20);
		this.bIdTextBox.TabIndex = 10;
		this.bIdTextBox.Text = "";
		// 
		// refreshAButton
		// 
		this.refreshAButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.refreshAButton.Location = new System.Drawing.Point(280, 56);
		this.refreshAButton.Name = "refreshAButton";
		this.refreshAButton.TabIndex = 16;
		this.refreshAButton.Tag = "A";
		this.refreshAButton.Text = "Refresh";
		this.refreshAButton.Click += new System.EventHandler(this.refreshButton_Click);
		// 
		// refreshBButton
		// 
		this.refreshBButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.refreshBButton.Location = new System.Drawing.Point(280, 56);
		this.refreshBButton.Name = "refreshBButton";
		this.refreshBButton.TabIndex = 17;
		this.refreshBButton.Tag = "B";
		this.refreshBButton.Text = "Refresh";
		this.refreshBButton.Click += new System.EventHandler(this.refreshButton_Click);
		// 
		// groupBox1
		// 
		this.groupBox1.Controls.Add(this.aRowversionTextBox);
		this.groupBox1.Controls.Add(this.label1);
		this.groupBox1.Controls.Add(this.label2);
		this.groupBox1.Controls.Add(this.label3);
		this.groupBox1.Controls.Add(this.aIdTextBox);
		this.groupBox1.Controls.Add(this.aField1TextBox);
		this.groupBox1.Controls.Add(this.updateAButton);
		this.groupBox1.Controls.Add(this.refreshAButton);
		this.groupBox1.Location = new System.Drawing.Point(8, 8);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(368, 104);
		this.groupBox1.TabIndex = 18;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "User A";
		// 
		// groupBox2
		// 
		this.groupBox2.Controls.Add(this.bRowversionTextBox);
		this.groupBox2.Controls.Add(this.label4);
		this.groupBox2.Controls.Add(this.label5);
		this.groupBox2.Controls.Add(this.label6);
		this.groupBox2.Controls.Add(this.bIdTextBox);
		this.groupBox2.Controls.Add(this.bField1TextBox);
		this.groupBox2.Controls.Add(this.updateBButton);
		this.groupBox2.Controls.Add(this.refreshBButton);
		this.groupBox2.Location = new System.Drawing.Point(8, 124);
		this.groupBox2.Name = "groupBox2";
		this.groupBox2.Size = new System.Drawing.Size(368, 104);
		this.groupBox2.TabIndex = 0;
		this.groupBox2.TabStop = false;
		this.groupBox2.Text = "User B";
		// 
		// RowversionForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(384, 238);
		this.Controls.Add(this.groupBox2);
		this.Controls.Add(this.groupBox1);
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
		this.MaximizeBox = false;
		this.Name = "RowversionForm";
		this.Text = "6.10 RowversionForm";
		this.Load += new System.EventHandler(this.RowversionForm_Load);
		this.groupBox1.ResumeLayout(false);
		this.groupBox2.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion

	private void RowversionForm_Load(object sender, System.EventArgs e)
	{
		// build statements to select only the row for ID = 1
		// and to update the data
		String selectText = "SELECT Id, Field1, rowversion FROM " +
			TABLENAME + " WHERE Id = 1";
		String updateText = "UPDATE " + TABLENAME + " " +
			"SET Field1 = @Field1 " +
			"WHERE Id = 1 AND rowversion = @rowversion";

		// create table A and fill it with the schema
		dtA = new DataTable("A");
		daA = new SqlDataAdapter(selectText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		daA.RowUpdated += new SqlRowUpdatedEventHandler(da_RowUpdated);
		daA.FillSchema(dtA, SchemaType.Source);
		dtA.Columns["rowversion"].ReadOnly = false;
		daA.Fill(dtA);

		// create the update command and define the parameters
		daA.UpdateCommand = new SqlCommand(updateText, daA.SelectCommand.Connection);
		daA.UpdateCommand.CommandType = CommandType.Text;
		daA.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		daA.UpdateCommand.Parameters["@Id"].SourceVersion = DataRowVersion.Original;
		daA.UpdateCommand.Parameters.Add("@Field1", SqlDbType.NVarChar, 50, "Field1");
		daA.UpdateCommand.Parameters["@Field1"].SourceVersion = DataRowVersion.Current;
		daA.UpdateCommand.Parameters.Add("@rowversion", SqlDbType.Timestamp, 0, "rowversion");
		daA.UpdateCommand.Parameters["@rowversion"].SourceVersion = DataRowVersion.Original;

		// create table B and fill it with the schema
		dtB = new DataTable("B");
		daB = new SqlDataAdapter(selectText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		daB.RowUpdated += new SqlRowUpdatedEventHandler(da_RowUpdated);
		daB.FillSchema(dtB, SchemaType.Source);
		dtB.Columns["rowversion"].ReadOnly = false;
		daB.Fill(dtB);

		// create the update command and define the parameters
		daB.UpdateCommand = new SqlCommand(updateText, daB.SelectCommand.Connection);
		daB.UpdateCommand.CommandType = CommandType.Text;
		daB.UpdateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		daB.UpdateCommand.Parameters["@Id"].SourceVersion = DataRowVersion.Original;
		daB.UpdateCommand.Parameters.Add("@Field1", SqlDbType.NVarChar, 50, "Field1");
		daB.UpdateCommand.Parameters["@Field1"].SourceVersion = DataRowVersion.Current;
		daB.UpdateCommand.Parameters.Add("@rowversion", SqlDbType.Timestamp, 0, "rowversion");
		daB.UpdateCommand.Parameters["@rowversion"].SourceVersion = DataRowVersion.Original;

		// display the first row (ID=1) from both tables on the form
		DisplayRow(dtA, 0);
		DisplayRow(dtB, 0);
	}

	private void da_RowUpdated(object sender, SqlRowUpdatedEventArgs e)
	{
		// check if an insert or update operation is being performed
		if(e.Status == UpdateStatus.Continue && 
			(e.StatementType == StatementType.Insert || e.StatementType == StatementType.Update))
		{
			// build a command object to retrieve the updated timestamp
			String sqlGetRowVersion = "SELECT rowversion FROM " + TABLENAME +
				" WHERE Id = " + e.Row["Id"];
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			SqlCommand cmd = new SqlCommand(sqlGetRowVersion, conn);

			// set the timestamp to the new value in the data source and call accept changes
			conn.Open();
			e.Row["rowversion"] = (Byte[])cmd.ExecuteScalar();
			conn.Close();
			e.Row.AcceptChanges();
		}
	}

	private void Update(SqlDataAdapter da, DataTable dt, TextBox field1TextBox)
	{
		// move the value for the field named Field1
		// from the form to the DataTable for updating
		dt.Rows[0]["Field1"] = field1TextBox.Text;

		// update the row table
		try
		{
			da.Update(dt);
		}
		catch (DBConcurrencyException ex)
		{
			// error if timestamp does not match
			MessageBox.Show(ex.Message);
			dt.RejectChanges();
		}
	}

	private void DisplayRow(DataTable dt, int index)
	{
		if (dt.TableName == "A")
		{
			aIdTextBox.Text = dt.Rows[index]["Id"].ToString();
			aField1TextBox.Text = dt.Rows[index]["Field1"].ToString();
			aRowversionTextBox.Text = Convert.ToBase64String((Byte[])dt.Rows[index]["rowversion"]);
		}
		else
		{
			bIdTextBox.Text = dt.Rows[index]["Id"].ToString();
			bField1TextBox.Text = dt.Rows[index]["Field1"].ToString();
			bRowversionTextBox.Text = Convert.ToBase64String((Byte[])dt.Rows[index]["rowversion"]);
		}
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		if(((Button)sender).Tag.ToString() == "A")
		{
			Update(daA, dtA, aField1TextBox);
			DisplayRow(dtA, 0);
		}
		else
		{
			Update(daB, dtB, bField1TextBox);
			DisplayRow(dtB, 0);
		}
	}

	private void refreshButton_Click(object sender, System.EventArgs e)
	{
		if(((Button)sender).Tag.ToString() == "A")
		{
			daA.Fill(dtA);
			DisplayRow(dtA, 0);
		}
		else
		{
			daB.Fill(dtB);
			DisplayRow(dtB, 0);
		}
	}
}
