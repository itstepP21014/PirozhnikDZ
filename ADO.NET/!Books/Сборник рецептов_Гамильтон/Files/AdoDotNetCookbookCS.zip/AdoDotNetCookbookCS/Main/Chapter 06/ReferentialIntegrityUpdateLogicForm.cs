using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class ReferentialIntegrityUpdateLogicForm : System.Windows.Forms.Form
{
	private DataSet ds;
	private SqlDataAdapter daParent, daChild, daGrandchild;

	private const String PARENTTABLENAME		= "TBL0606Parent";
	private const String CHILDTABLENAME			= "TBL0606Child";
	private const String GRANDCHILDTABLENAME	= "TBL0606Grandchild";

	// table column name constants for Parent table
	private const String PARENTID_FIELD			= "ParentId";
	private const String FIELD1_FIELD			= "Field1";
	private const String FIELD2_FIELD			= "Field2";

	// table column parameter name constants for Child table
	private const String CHILDID_FIELD			= "ChildId";
	private const String FIELD3_FIELD			= "Field3";
	private const String FIELD4_FIELD			= "Field4";

	// table column parameter name constants for Grandchild table
	private const String GRANDCHILDID_FIELD		= "GrandchildId";
	private const String FIELD5_FIELD			= "Field5";
	private const String FIELD6_FIELD			= "Field6";

	// stored procedure name constants
	private const String DELETEPARENT_SP		= "SP0606_DeleteParent";
	private const String GETPARENT_SP			= "SP0606_GetParent";
	private const String INSERTPARENT_SP		= "SP0606_InsertParent";
	private const String UPDATEPARENT_SP		= "SP0606_UpdateParent";
	private const String DELETECHILD_SP			= "SP0606_DeleteChild";
	private const String GETCHILD_SP			= "SP0606_GetChild";
	private const String INSERTCHILD_SP			= "SP0606_InsertChild";
	private const String UPDATECHILD_SP			= "SP0606_UpdateChild";
	private const String DELETEGRANDCHILD_SP	= "SP0606_DeleteGrandchild";
	private const String GETGRANDCHILD_SP		= "SP0606_GetGrandchild";
	private const String INSERTGRANDCHILD_SP	= "SP0606_InsertGrandchild";
	private const String UPDATEGRANDCHILD_SP	= "SP0606_UpdateGrandchild";

	// stored procedure parameter name constants for Parent table
	private const String PARENTID_PARM			= "@ParentId";
	private const String FIELD1_PARM			= "@Field1";
	private const String FIELD2_PARM			= "@Field2";

	// stored procedure parameter name constants for Child table
	private const String CHILDID_PARM			= "@ChildId";
	private const String FIELD3_PARM			= "@Field3";
	private const String FIELD4_PARM			= "@Field4";

	// stored procedure parameter name constants for Child table
	private const String GRANDCHILDID_PARM		= "@GrandchildId";
	private const String FIELD5_PARM			= "@Field5";
	private const String FIELD6_PARM			= "@Field6";

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button deleteButton;
	private System.Windows.Forms.Button modifyButton;
	private System.Windows.Forms.Button createDataButton;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ReferentialIntegrityUpdateLogicForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.createDataButton = new System.Windows.Forms.Button();
		this.deleteButton = new System.Windows.Forms.Button();
		this.modifyButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 0;
		// 
		// createDataButton
		// 
		this.createDataButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
		this.createDataButton.Location = new System.Drawing.Point(8, 232);
		this.createDataButton.Name = "createDataButton";
		this.createDataButton.TabIndex = 1;
		this.createDataButton.Text = "Create Data";
		this.createDataButton.Click += new System.EventHandler(this.createDataButton_Click);
		// 
		// deleteButton
		// 
		this.deleteButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
		this.deleteButton.Location = new System.Drawing.Point(168, 232);
		this.deleteButton.Name = "deleteButton";
		this.deleteButton.TabIndex = 3;
		this.deleteButton.Text = "Delete Data";
		this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
		// 
		// modifyButton
		// 
		this.modifyButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
		this.modifyButton.Location = new System.Drawing.Point(88, 232);
		this.modifyButton.Name = "modifyButton";
		this.modifyButton.TabIndex = 2;
		this.modifyButton.Text = "Modify Data";
		this.modifyButton.Click += new System.EventHandler(this.modifyButton_Click);
		// 
		// ReferentialIntegrityUpdateLogicForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.modifyButton,
																		this.deleteButton,
																		this.createDataButton,
																		this.dataGrid});
		this.Name = "ReferentialIntegrityUpdateLogicForm";
		this.Text = "6.06 ReferentialIntegrityUpdateLogicForm";
		this.Load += new System.EventHandler(this.ReferentialIntegrityUpdateLogicForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void ReferentialIntegrityUpdateLogicForm_Load(object sender, System.EventArgs e)
	{
		DataColumnCollection cols;
		DataColumn col;

		// build the parent table
		DataTable parentTable = new DataTable(PARENTTABLENAME);
		cols = parentTable.Columns;
		col = cols.Add(PARENTID_FIELD, typeof(Int32));
		col.AutoIncrement = true;
		col.AutoIncrementSeed = -1;
		col.AutoIncrementStep = -1;
		cols.Add(FIELD1_FIELD, typeof(String)).MaxLength = 50;
		cols.Add(FIELD2_FIELD, typeof(String)).MaxLength = 50;

		// build the child table
		DataTable childTable = new DataTable(CHILDTABLENAME);
		cols = childTable.Columns;
		col = cols.Add(CHILDID_FIELD, typeof(Int32));
		col.AutoIncrement = true;
		col.AutoIncrementSeed = -1;
		col.AutoIncrementStep = -1;
		cols.Add(PARENTID_FIELD, typeof(Int32)).AllowDBNull = false;
		cols.Add(FIELD3_FIELD, typeof(String)).MaxLength = 50;
		cols.Add(FIELD4_FIELD, typeof(String)).MaxLength = 50;

		// build the grandchild table
		DataTable grandchildTable = new DataTable(GRANDCHILDTABLENAME);
		cols = grandchildTable.Columns;
		col = cols.Add(GRANDCHILDID_FIELD, typeof(Int32));
		col.AutoIncrement = true;
		col.AutoIncrementSeed = -1;
		col.AutoIncrementStep = -1;
		cols.Add(CHILDID_FIELD, typeof(Int32)).AllowDBNull = false;
		cols.Add(FIELD5_FIELD, typeof(String)).MaxLength = 50;
		cols.Add(FIELD6_FIELD, typeof(String)).MaxLength = 50;

		// add the tables to the DataSet and create the relationship between them
		ds = new DataSet();
		ds.Tables.Add(parentTable);
		ds.Tables.Add(childTable);
		ds.Tables.Add(grandchildTable);
		ds.Relations.Add(new DataRelation("Parent_Child_Relation",
			parentTable.Columns[PARENTID_FIELD], childTable.Columns[PARENTID_FIELD], true));
		ds.Relations.Add(new DataRelation("Child_Grandchild_Relation",
			childTable.Columns[CHILDID_FIELD], grandchildTable.Columns[CHILDID_FIELD], true));

		// create the DataAdapter objects for the tables
		daParent = new SqlDataAdapter();
		daChild = new SqlDataAdapter();
		daGrandchild = new SqlDataAdapter();

		// build the parent select command
		SqlCommand selectCommand = new SqlCommand(GETPARENT_SP, new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]));
		selectCommand.CommandType = CommandType.StoredProcedure;
		daParent.SelectCommand = selectCommand;

		// build the parent delete command
		SqlCommand deleteCommand = new SqlCommand(DELETEPARENT_SP, daParent.SelectCommand.Connection);
		deleteCommand.CommandType = CommandType.StoredProcedure;
		deleteCommand.Parameters.Add(PARENTID_PARM, SqlDbType.Int, 0, PARENTID_FIELD);
		daParent.DeleteCommand = deleteCommand;

		// build the parent insert command
		SqlCommand insertCommand = new SqlCommand(INSERTPARENT_SP, daParent.SelectCommand.Connection);
		insertCommand.CommandType = CommandType.StoredProcedure;
		insertCommand.Parameters.Add(PARENTID_PARM, SqlDbType.Int, 0, PARENTID_FIELD);
		insertCommand.Parameters.Add(FIELD1_PARM, SqlDbType.NVarChar, 50, FIELD1_FIELD);
		insertCommand.Parameters.Add(FIELD2_PARM, SqlDbType.NVarChar, 50, FIELD2_FIELD);
		daParent.InsertCommand = insertCommand;

		// build the parent update command
		SqlCommand updateCommand = new SqlCommand(UPDATEPARENT_SP, daParent.SelectCommand.Connection);
		updateCommand.CommandType = CommandType.StoredProcedure;
		updateCommand.Parameters.Add(PARENTID_PARM, SqlDbType.Int, 0, PARENTID_FIELD);
		updateCommand.Parameters.Add(FIELD1_PARM, SqlDbType.NVarChar, 50, FIELD1_FIELD);
		updateCommand.Parameters.Add(FIELD2_PARM, SqlDbType.NVarChar, 50, FIELD2_FIELD);
		daParent.UpdateCommand = updateCommand;

		// Build the child select command
		selectCommand = new SqlCommand(GETCHILD_SP, new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]));
		selectCommand.CommandType = CommandType.StoredProcedure;
		daChild.SelectCommand = selectCommand;

		// build the child delete command
		deleteCommand = new SqlCommand(DELETECHILD_SP, daChild.SelectCommand.Connection);
		deleteCommand.CommandType = CommandType.StoredProcedure;
		deleteCommand.Parameters.Add(CHILDID_PARM, SqlDbType.Int, 0, CHILDID_FIELD);
		daChild.DeleteCommand = deleteCommand;

		// build the child insert command
		insertCommand = new SqlCommand(INSERTCHILD_SP, daChild.SelectCommand.Connection);
		insertCommand.CommandType = CommandType.StoredProcedure;
		insertCommand.Parameters.Add(CHILDID_PARM, SqlDbType.Int, 0, CHILDID_FIELD);
		insertCommand.Parameters.Add(PARENTID_PARM, SqlDbType.Int, 0, PARENTID_FIELD);
		insertCommand.Parameters.Add(FIELD3_PARM, SqlDbType.NVarChar, 50, FIELD3_FIELD);
		insertCommand.Parameters.Add(FIELD4_PARM, SqlDbType.NVarChar, 50, FIELD4_FIELD);
		daChild.InsertCommand = insertCommand;

		// build the child update command
		updateCommand = new SqlCommand(UPDATECHILD_SP, daChild.SelectCommand.Connection);
		updateCommand.CommandType = CommandType.StoredProcedure;
		updateCommand.Parameters.Add(CHILDID_PARM, SqlDbType.Int, 0, CHILDID_FIELD);
		updateCommand.Parameters.Add(PARENTID_PARM, SqlDbType.Int, 0, PARENTID_FIELD);
		updateCommand.Parameters.Add(FIELD3_PARM, SqlDbType.NVarChar, 50, FIELD3_FIELD);
		updateCommand.Parameters.Add(FIELD4_PARM, SqlDbType.NVarChar, 50, FIELD4_FIELD);
		daChild.UpdateCommand = updateCommand;

		// Build the grandchild select command
		selectCommand = new SqlCommand(GETGRANDCHILD_SP, new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]));
		selectCommand.CommandType = CommandType.StoredProcedure;
		daGrandchild.SelectCommand = selectCommand;

		// build the grandchild delete command
		deleteCommand = new SqlCommand(DELETEGRANDCHILD_SP, daGrandchild.SelectCommand.Connection);
		deleteCommand.CommandType = CommandType.StoredProcedure;
		deleteCommand.Parameters.Add(GRANDCHILDID_PARM, SqlDbType.Int, 0, GRANDCHILDID_FIELD);
		daGrandchild.DeleteCommand = deleteCommand;

		// build the grandchild insert command
		insertCommand = new SqlCommand(INSERTGRANDCHILD_SP, daGrandchild.SelectCommand.Connection);
		insertCommand.CommandType = CommandType.StoredProcedure;
		insertCommand.Parameters.Add(GRANDCHILDID_PARM, SqlDbType.Int, 0, GRANDCHILDID_FIELD);
		insertCommand.Parameters.Add(CHILDID_PARM, SqlDbType.Int, 0, CHILDID_FIELD);
		insertCommand.Parameters.Add(FIELD5_PARM, SqlDbType.NVarChar, 50, FIELD5_FIELD);
		insertCommand.Parameters.Add(FIELD6_PARM, SqlDbType.NVarChar, 50, FIELD6_FIELD);
		daGrandchild.InsertCommand = insertCommand;

		// build the grandchild update command
		updateCommand = new SqlCommand(UPDATEGRANDCHILD_SP, daGrandchild.SelectCommand.Connection);
		updateCommand.CommandType = CommandType.StoredProcedure;
		updateCommand.Parameters.Add(GRANDCHILDID_PARM, SqlDbType.Int, 0, GRANDCHILDID_FIELD);
		updateCommand.Parameters.Add(CHILDID_PARM, SqlDbType.Int, 0, CHILDID_FIELD);
		updateCommand.Parameters.Add(FIELD5_PARM, SqlDbType.NVarChar, 50, FIELD5_FIELD);
		updateCommand.Parameters.Add(FIELD6_PARM, SqlDbType.NVarChar, 50, FIELD6_FIELD);
		daGrandchild.UpdateCommand = updateCommand;

		// fill the parent and child table
		daParent.Fill(parentTable);
		daChild.Fill(childTable);
		daGrandchild.Fill(grandchildTable);

		// bind the default view of the data source to the grid
		dataGrid.DataSource = parentTable.DefaultView;

	}

	private void CreateData(int parentRows, int childRows, int grandchildRows)
	{
		// generate some data into each of the related tables
		for(int iParent = 0; iParent < parentRows; iParent++)
		{
			// generate parentRows of data in the parent table
			DataRow parentRow = ds.Tables[PARENTTABLENAME].NewRow();
			parentRow[FIELD1_FIELD] = Guid.NewGuid().ToString();
			parentRow[FIELD2_FIELD] = Guid.NewGuid().ToString();
			ds.Tables[PARENTTABLENAME].Rows.Add(parentRow);

			for(int iChild = 0; iChild < childRows; iChild++)
			{
				// generate childRows of data in the child table
				DataRow childRow = ds.Tables[CHILDTABLENAME].NewRow();
				childRow[PARENTID_FIELD] = (int)parentRow[PARENTID_FIELD];
				childRow[FIELD3_FIELD] = Guid.NewGuid().ToString();
				childRow[FIELD4_FIELD] = Guid.NewGuid().ToString();
				ds.Tables[CHILDTABLENAME].Rows.Add(childRow);
			
				for(int iGrandchild = 0; iGrandchild < grandchildRows; iGrandchild++)
				{
					// generate grandchildRows of data in the grandchild table
					DataRow grandchildRow = ds.Tables[GRANDCHILDTABLENAME].NewRow();
					grandchildRow[CHILDID_FIELD] = (int)childRow[CHILDID_FIELD];
					grandchildRow[FIELD5_FIELD] = Guid.NewGuid().ToString();
					grandchildRow[FIELD6_FIELD] = Guid.NewGuid().ToString();
					ds.Tables[GRANDCHILDTABLENAME].Rows.Add(grandchildRow);
				}
			}
		}
	}

	private void UpdateData()
	{
		// update the related tables
		daGrandchild.Update(ds.Tables[GRANDCHILDTABLENAME].Select(null, null, DataViewRowState.Deleted));
		daChild.Update(ds.Tables[CHILDTABLENAME].Select(null, null, DataViewRowState.Deleted));
		daParent.Update(ds.Tables[PARENTTABLENAME].Select(null, null, DataViewRowState.Deleted));
		daParent.Update(ds.Tables[PARENTTABLENAME].Select(null, null, DataViewRowState.ModifiedCurrent));
		daParent.Update(ds.Tables[PARENTTABLENAME].Select(null, null, DataViewRowState.Added));
		daChild.Update(ds.Tables[CHILDTABLENAME].Select(null, null, DataViewRowState.ModifiedCurrent));
		daChild.Update(ds.Tables[CHILDTABLENAME].Select(null, null, DataViewRowState.Added));
		daGrandchild.Update(ds.Tables[GRANDCHILDTABLENAME].Select(null, null, DataViewRowState.ModifiedCurrent));
		daGrandchild.Update(ds.Tables[GRANDCHILDTABLENAME].Select(null, null, DataViewRowState.Added));
	}

	private void createDataButton_Click(object sender, System.EventArgs e)
	{
		// create 4 rows of data in each parent, child, and grandchild
		CreateData(4, 4, 4);
		// update the data source with the new data
		UpdateData();

		MessageBox.Show("Data created.", "Referential Integrity", MessageBoxButtons.OK, MessageBoxIcon.Information);
	}

	private void modifyButton_Click(object sender, System.EventArgs e)
	{
		// randomly delete or modify rows from the grandchild, child, and parent rows
		Random r = new Random((int)DateTime.Now.Ticks);

		// modify grandchild rows
		for(int i = ds.Tables[GRANDCHILDTABLENAME].Rows.Count; i > 0; i--)
		{
			DataRow grandchildRow = ds.Tables[GRANDCHILDTABLENAME].Rows[i - 1];

			if(r.Next(2) == 0)
			{
				grandchildRow[FIELD5_FIELD] = Guid.NewGuid().ToString();
				grandchildRow[FIELD6_FIELD] = Guid.NewGuid().ToString();
			}
			else
				grandchildRow.Delete();
		}

		// modify or delete child rows
		for(int i = ds.Tables[CHILDTABLENAME].Rows.Count; i > 0; i--)
		{
			DataRow childRow = ds.Tables[CHILDTABLENAME].Rows[i - 1];

			if(r.Next(2) == 0)
			{
				childRow[FIELD3_FIELD] = Guid.NewGuid().ToString();
				childRow[FIELD4_FIELD] = Guid.NewGuid().ToString();
			}
			else
				childRow.Delete();
		}

		// modify or delete parent rows
		for(int i = ds.Tables[PARENTTABLENAME].Rows.Count; i > 0; i--)
		{
			DataRow parentRow = ds.Tables[PARENTTABLENAME].Rows[i - 1];

			if(r.Next(2) == 0)
			{
				parentRow[FIELD1_FIELD] = Guid.NewGuid().ToString();
				parentRow[FIELD2_FIELD] = Guid.NewGuid().ToString();
			}
			else
				parentRow.Delete();
				
		}

		// insert two rows into parent, child and grandchild
		CreateData(2 ,2, 2);

		// update the data source with the changes
		UpdateData();

		MessageBox.Show("Data randomly modified.", "Referential Integrity", MessageBoxButtons.OK, MessageBoxIcon.Information);		
	}

	private void deleteButton_Click(object sender, System.EventArgs e)
	{
		// delete the parent data which cascades by default
		// to child and grandchild records
		for(int i = ds.Tables[PARENTTABLENAME].Rows.Count; i > 0; i--)
			ds.Tables[PARENTTABLENAME].Rows[i - 1].Delete();

		// update the data source with the changes
		UpdateData();

		MessageBox.Show("Data deleted.", "Referential Integrity", MessageBoxButtons.OK, MessageBoxIcon.Information);
	}
}