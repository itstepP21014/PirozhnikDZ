using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

public class ConstraintForm : System.Windows.Forms.Form
{
	private const String GETPRIMARYKEYCONSTRAINTS =
		"SELECT tc.CONSTRAINT_NAME, tc.TABLE_NAME, " +
		"kcu.COLUMN_NAME, kcu.ORDINAL_POSITION " +
		"FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc " +
		"JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu ON " +
		"tc.CONSTRAINT_NAME=kcu.CONSTRAINT_NAME " +
		"WHERE tc.CONSTRAINT_TYPE='PRIMARY KEY' " +
		"ORDER BY tc.TABLE_NAME, kcu.COLUMN_NAME, kcu.ORDINAL_POSITION";

	private const String GETFOREIGNKEYCONSTRAINTS =
		"SELECT rc.CONSTRAINT_NAME, rc.UPDATE_RULE, rc.DELETE_RULE, " +
		"kcuP.TABLE_NAME ParentTable, kcuC.TABLE_NAME ChildTable, " +
		"kcuP.COLUMN_NAME ParentColumn, kcuC.COLUMN_NAME ChildColumn " +
		"FROM INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS rc " +
		"LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcuP ON " +
		"rc.UNIQUE_CONSTRAINT_NAME=kcuP.CONSTRAINT_NAME " +
		"LEFT JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcuC ON " +
		"rc.CONSTRAINT_NAME=kcuC.CONSTRAINT_NAME AND " +
		"kcuP.ORDINAL_POSITION=kcuC.ORDINAL_POSITION " +
		"ORDER BY kcuP.TABLE_NAME, kcuC.TABLE_NAME, kcuP.ORDINAL_POSITION";

	private const String GETCHECKCONSTRAINTS =
		"SELECT tc.TABLE_NAME, tc.CONSTRAINT_NAME, cc.CHECK_CLAUSE " +
		"FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc " +
		"JOIN INFORMATION_SCHEMA.CHECK_CONSTRAINTS cc ON " +
		"tc.CONSTRAINT_NAME=cc.CONSTRAINT_NAME " +
		"WHERE CONSTRAINT_TYPE='CHECK' " +
		"ORDER BY tc.TABLE_NAME, cc.CONSTRAINT_NAME";

	private System.Windows.Forms.Button getConstraintsButton;
	private System.Windows.Forms.DataGrid constraintsDataGrid;
	private System.Windows.Forms.RadioButton checkRadioButton;
	private System.Windows.Forms.RadioButton primaryKeyRadioButton;
	private System.Windows.Forms.RadioButton foreignKeyRadioButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ConstraintForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.getConstraintsButton = new System.Windows.Forms.Button();
		this.constraintsDataGrid = new System.Windows.Forms.DataGrid();
		this.checkRadioButton = new System.Windows.Forms.RadioButton();
		this.primaryKeyRadioButton = new System.Windows.Forms.RadioButton();
		this.foreignKeyRadioButton = new System.Windows.Forms.RadioButton();
		((System.ComponentModel.ISupportInitialize)(this.constraintsDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// getConstraintsButton
		// 
		this.getConstraintsButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.getConstraintsButton.Location = new System.Drawing.Point(378, 252);
		this.getConstraintsButton.Name = "getConstraintsButton";
		this.getConstraintsButton.Size = new System.Drawing.Size(104, 23);
		this.getConstraintsButton.TabIndex = 0;
		this.getConstraintsButton.Text = "Get Constraints";
		this.getConstraintsButton.Click += new System.EventHandler(this.getConstraintsButton_Click);
		// 
		// constraintsDataGrid
		// 
		this.constraintsDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.constraintsDataGrid.DataMember = "";
		this.constraintsDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.constraintsDataGrid.Location = new System.Drawing.Point(8, 8);
		this.constraintsDataGrid.Name = "constraintsDataGrid";
		this.constraintsDataGrid.Size = new System.Drawing.Size(476, 236);
		this.constraintsDataGrid.TabIndex = 1;
		// 
		// checkRadioButton
		// 
		this.checkRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.checkRadioButton.Location = new System.Drawing.Point(200, 248);
		this.checkRadioButton.Name = "checkRadioButton";
		this.checkRadioButton.Size = new System.Drawing.Size(64, 24);
		this.checkRadioButton.TabIndex = 4;
		this.checkRadioButton.Text = "Check";
		// 
		// primaryKeyRadioButton
		// 
		this.primaryKeyRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.primaryKeyRadioButton.Checked = true;
		this.primaryKeyRadioButton.Location = new System.Drawing.Point(8, 248);
		this.primaryKeyRadioButton.Name = "primaryKeyRadioButton";
		this.primaryKeyRadioButton.Size = new System.Drawing.Size(88, 24);
		this.primaryKeyRadioButton.TabIndex = 5;
		this.primaryKeyRadioButton.TabStop = true;
		this.primaryKeyRadioButton.Text = "Primary Key";
		// 
		// foreignKeyRadioButton
		// 
		this.foreignKeyRadioButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
		this.foreignKeyRadioButton.Location = new System.Drawing.Point(104, 248);
		this.foreignKeyRadioButton.Name = "foreignKeyRadioButton";
		this.foreignKeyRadioButton.Size = new System.Drawing.Size(88, 24);
		this.foreignKeyRadioButton.TabIndex = 6;
		this.foreignKeyRadioButton.Text = "Foreign Key";
		// 
		// ConstraintForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 286);
		this.Controls.Add(this.foreignKeyRadioButton);
		this.Controls.Add(this.primaryKeyRadioButton);
		this.Controls.Add(this.checkRadioButton);
		this.Controls.Add(this.constraintsDataGrid);
		this.Controls.Add(this.getConstraintsButton);
		this.Name = "ConstraintForm";
		this.Text = "6.09 ConstraintForm";
		((System.ComponentModel.ISupportInitialize)(this.constraintsDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void getConstraintsButton_Click(object sender, System.EventArgs e)
	{
		// create the DataAdapter to retrieve schema information
		SqlDataAdapter da = null;
		if (primaryKeyRadioButton.Checked)
			da = new SqlDataAdapter(GETPRIMARYKEYCONSTRAINTS, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		else if (foreignKeyRadioButton.Checked)
			da = new SqlDataAdapter(GETFOREIGNKEYCONSTRAINTS, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		else if (checkRadioButton.Checked)
			da = new SqlDataAdapter(GETCHECKCONSTRAINTS, ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// create and fill table with schema information
		DataTable dt = new DataTable();
		da.Fill(dt);

		// bind the default view of the table with the grid
		constraintsDataGrid.DataSource = dt.DefaultView;
	}
}