using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class DbmsTransactionForm : System.Windows.Forms.Form
{
	private SqlDataAdapter da;
	private DataTable dt;

	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Button insertButton;
	private System.Windows.Forms.CheckBox forceDbmsRollbackCheckBox;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.TextBox descriptionTextBox;
	private System.Windows.Forms.TextBox categoryNameTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public DbmsTransactionForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.insertButton = new System.Windows.Forms.Button();
		this.label3 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.descriptionTextBox = new System.Windows.Forms.TextBox();
		this.categoryNameTextBox = new System.Windows.Forms.TextBox();
		this.forceDbmsRollbackCheckBox = new System.Windows.Forms.CheckBox();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// insertButton
		// 
		this.insertButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.insertButton.Location = new System.Drawing.Point(308, 8);
		this.insertButton.Name = "insertButton";
		this.insertButton.TabIndex = 4;
		this.insertButton.Text = "Insert";
		this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(8, 32);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(64, 16);
		this.label3.TabIndex = 16;
		this.label3.Text = "Description:";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 8);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(88, 16);
		this.label2.TabIndex = 15;
		this.label2.Text = "Category Name:";
		// 
		// descriptionTextBox
		// 
		this.descriptionTextBox.Location = new System.Drawing.Point(104, 32);
		this.descriptionTextBox.Name = "descriptionTextBox";
		this.descriptionTextBox.TabIndex = 2;
		this.descriptionTextBox.Text = "";
		// 
		// categoryNameTextBox
		// 
		this.categoryNameTextBox.Location = new System.Drawing.Point(104, 8);
		this.categoryNameTextBox.Name = "categoryNameTextBox";
		this.categoryNameTextBox.TabIndex = 1;
		this.categoryNameTextBox.Text = "";
		// 
		// forceDbmsRollbackCheckBox
		// 
		this.forceDbmsRollbackCheckBox.Location = new System.Drawing.Point(8, 64);
		this.forceDbmsRollbackCheckBox.Name = "forceDbmsRollbackCheckBox";
		this.forceDbmsRollbackCheckBox.Size = new System.Drawing.Size(136, 24);
		this.forceDbmsRollbackCheckBox.TabIndex = 3;
		this.forceDbmsRollbackCheckBox.Text = "Force DBMS Rollback";
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 104);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(376, 152);
		this.dataGrid.TabIndex = 21;
		// 
		// DbmsTransactionForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(392, 266);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.forceDbmsRollbackCheckBox);
		this.Controls.Add(this.label3);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.descriptionTextBox);
		this.Controls.Add(this.categoryNameTextBox);
		this.Controls.Add(this.insertButton);
		this.Name = "DbmsTransactionForm";
		this.Text = "6.04 DbmsTransactionForm";
		this.Load += new System.EventHandler(this.DbmsTransactionForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void DbmsTransactionForm_Load(object sender, System.EventArgs e)
	{
		// fill the table
		String sqlText = "SELECT CategoryID, CategoryName, Description " +
			"FROM Categories";
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		dt = new DataTable("Categories");
		da.FillSchema(dt, SchemaType.Source);
		da.Fill(dt);

		// bind the default view of the table to the grid
		dataGrid.DataSource = dt.DefaultView;
	}

	private void insertButton_Click(object sender, System.EventArgs e)
	{
		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// create the transaction
		conn.Open();
		SqlTransaction tran = conn.BeginTransaction();

		// create command in the transaction with parameters
		SqlCommand cmd = new SqlCommand("InsertCategories_Transacted", conn, tran);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@CategoryID", SqlDbType.Int).Direction = ParameterDirection.Output;
		cmd.Parameters.Add("@CategoryName", SqlDbType.NVarChar, 15);
		cmd.Parameters.Add("@Description", SqlDbType.NText);
		cmd.Parameters.Add("@Rollback", SqlDbType.Bit);

		try
		{
			// set the parameters to the user-entered values
			// set the CategoryName to DBNull if not entered
			if(categoryNameTextBox.Text.Trim().Length == 0)
				cmd.Parameters["@CategoryName"].Value = DBNull.Value;
			else
				cmd.Parameters["@CategoryName"].Value = categoryNameTextBox.Text;
			cmd.Parameters["@Description"].Value = descriptionTextBox.Text;
			cmd.Parameters["@Rollback"].Value = forceDbmsRollbackCheckBox.Checked ? 1 : 0;

			// attempt to insert the record
			cmd.ExecuteNonQuery();

			// success - commit the transaction
			tran.Commit();
			MessageBox.Show("Transaction committed.");
		}
		catch (SqlException ex)
		{
			bool spRollback = false;
			foreach (SqlError err in ex.Errors)
			{
				// check if transaction rolled back in the stored procedure
				if(err.Number == 266)
				{
					MessageBox.Show(ex.Message, "DBMS transaction rolled back in stored procedure", MessageBoxButtons.OK, MessageBoxIcon.Error);
					spRollback = true;
					break;
				}
			}
			if (!spRollback)
			{
				// transaction was not rolled back by the DBMS
				// SqlException error - roll back the transaction
				tran.Rollback();
				MessageBox.Show(ex.Message);
			}
		}
		catch (Exception ex)
		{
			// other Exception - roll back the transaction
			tran.Rollback();
			MessageBox.Show(ex.Message);
		}
		finally
		{
			conn.Close();
		}

		// refresh the data
		da.Fill(dt);
	}
}