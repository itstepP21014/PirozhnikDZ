using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class UsingLockingHintsForPessimisticLockingForm : System.Windows.Forms.Form
{
	private SqlConnection conn;
	private SqlTransaction tran;

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button cancelButton;
	private System.Windows.Forms.Button startButton;
	private System.Windows.Forms.GroupBox groupBox1;
	private System.Windows.Forms.RadioButton updLockRadioButton;
	private System.Windows.Forms.RadioButton holdLockRadioButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public UsingLockingHintsForPessimisticLockingForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.cancelButton = new System.Windows.Forms.Button();
		this.startButton = new System.Windows.Forms.Button();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.updLockRadioButton = new System.Windows.Forms.RadioButton();
		this.holdLockRadioButton = new System.Windows.Forms.RadioButton();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.groupBox1.SuspendLayout();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 88);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(476, 168);
		this.dataGrid.TabIndex = 3;
		// 
		// cancelButton
		// 
		this.cancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.cancelButton.Enabled = false;
		this.cancelButton.Location = new System.Drawing.Point(408, 40);
		this.cancelButton.Name = "cancelButton";
		this.cancelButton.TabIndex = 4;
		this.cancelButton.Text = "Cancel";
		this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
		// 
		// startButton
		// 
		this.startButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.startButton.Location = new System.Drawing.Point(408, 8);
		this.startButton.Name = "startButton";
		this.startButton.TabIndex = 2;
		this.startButton.Text = "Start Tran";
		this.startButton.Click += new System.EventHandler(this.startButton_Click);
		// 
		// groupBox1
		// 
		this.groupBox1.Controls.Add(this.updLockRadioButton);
		this.groupBox1.Controls.Add(this.holdLockRadioButton);
		this.groupBox1.Location = new System.Drawing.Point(8, 8);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(168, 72);
		this.groupBox1.TabIndex = 5;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Locking Hint";
		// 
		// updLockRadioButton
		// 
		this.updLockRadioButton.Checked = true;
		this.updLockRadioButton.Location = new System.Drawing.Point(12, 16);
		this.updLockRadioButton.Name = "updLockRadioButton";
		this.updLockRadioButton.TabIndex = 2;
		this.updLockRadioButton.TabStop = true;
		this.updLockRadioButton.Text = "UPDLOCK";
		// 
		// holdLockRadioButton
		// 
		this.holdLockRadioButton.Location = new System.Drawing.Point(12, 40);
		this.holdLockRadioButton.Name = "holdLockRadioButton";
		this.holdLockRadioButton.TabIndex = 3;
		this.holdLockRadioButton.Text = "HOLDLOCK";
		// 
		// UsingLockingHintsForPessimisticLockingForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.groupBox1);
		this.Controls.Add(this.startButton);
		this.Controls.Add(this.cancelButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "UsingLockingHintsForPessimisticLockingForm";
		this.Text = "6.14 UsingLockingHintsForPessimisticLockingForm";
		this.Closing += new System.ComponentModel.CancelEventHandler(this.UsingLockingHintsForPessimisticLockingForm_Closing);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.groupBox1.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion

	private void startButton_Click(object sender, System.EventArgs e)
	{
		startButton.Enabled = false;
		
		String sqlText = "SELECT * FROM Orders WITH ";

		// add pessimistic locking as specified by user
		if(updLockRadioButton.Checked)
			sqlText += "(UPDLOCK)";
		else if(holdLockRadioButton.Checked)
			sqlText += "(HOLDLOCK)";

		// create connection
		conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		conn.Open();
		// start the transaction
		tran = conn.BeginTransaction(IsolationLevel.ReadCommitted);
		// create the command
		SqlCommand cmd = new SqlCommand(sqlText, conn, tran);
		// create the DataAdapter and CommandBuilder
		SqlDataAdapter da = new SqlDataAdapter(cmd);
		SqlCommandBuilder cb = new SqlCommandBuilder(da);
		// fill table using the DataAdapter
		DataTable dt = new DataTable();
		da.Fill(dt);

		// bind the default view of the table to the grid
		dataGrid.DataSource = dt.DefaultView;
		
		cancelButton.Enabled = true;
		dataGrid.ReadOnly = false;
	}

	private void cancelButton_Click(object sender, System.EventArgs e)
	{
		cancelButton.Enabled = false;

		// unbind the table from the grid
		dataGrid.DataSource = null;

		// roll back the transaction and close the connection
		tran.Rollback();
		conn.Close();

		startButton.Enabled = true;
	}

	private void UsingLockingHintsForPessimisticLockingForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
	{
		// roll back the transaction and close the connection
		if (tran != null && tran.Connection != null)
			tran.Rollback();
		if (conn != null)
			conn.Close();
	}
}