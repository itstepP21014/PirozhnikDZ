using System;
using System.Text;

using System.Data;

public class MultiColumnConstraintAndRelationForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Button goButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public MultiColumnConstraintAndRelationForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.goButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 8);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(476, 216);
		this.resultTextBox.TabIndex = 0;
		this.resultTextBox.Text = "";
		// 
		// goButton
		// 
		this.goButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.goButton.Location = new System.Drawing.Point(408, 232);
		this.goButton.Name = "goButton";
		this.goButton.TabIndex = 1;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// MultiColumnConstraintAndRelationForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.goButton);
		this.Controls.Add(this.resultTextBox);
		this.Name = "MultiColumnConstraintAndRelationForm";
		this.Text = "6.08 MultiColumnConstraintAndRelationForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder result = new StringBuilder();

		DataSet ds = new DataSet();

		// create the parent table
		result.Append("Creating parent table." + Environment.NewLine);
		DataTable dtParent = new DataTable("Parent");
		DataColumnCollection pCols = dtParent.Columns;
		pCols.Add("ParentKey1", typeof(Int32));
		pCols.Add("ParentKey2", typeof(Int32));
		pCols.Add("ParentData1", typeof(String));
		pCols.Add("ParentData2", typeof(String));

		// set the multi-column unique constraint
		result.Append("Creating unique constraint on parent table." + Environment.NewLine);
		dtParent.Constraints.Add(new UniqueConstraint("UConstraint", new DataColumn[] {pCols["ParentKey1"], pCols["ParentKey2"]}, false));

		// set the multi-column primary key
		result.Append("Creating primary key on parent table." + Environment.NewLine);
		dtParent.PrimaryKey = new DataColumn[] {pCols["ParentKey1"], pCols["ParentKey2"]};

		// add the parent table to the DataSet
		ds.Tables.Add(dtParent);

		// create the child table
		result.Append("Creating child table." + Environment.NewLine);
		DataTable dtChild = new DataTable("Child");
		DataColumnCollection cCols = dtChild.Columns;
		cCols.Add("ChildIndex1", typeof(Int32)).Unique = true;
		cCols.Add("ParentKey1", typeof(Int32));
		cCols.Add("ParentKey2", typeof(Int32));
		cCols.Add("ChildData1", typeof(String));
		cCols.Add("ChildData2", typeof(String));
		ds.Tables.Add(dtChild);

		// set the foreign-key constraint
		result.Append("Creating foreign key contraint." + Environment.NewLine);
		dtChild.Constraints.Add("FKConstraint",
			new DataColumn[] {pCols["ParentKey1"], pCols["ParentKey2"]},
			new DataColumn[] {cCols["ParentKey1"], cCols["ParentKey2"]});

		// create the relation between parent and child
		result.Append("Creating relationship." + Environment.NewLine);
		ds.Relations.Add("Relation",
			new DataColumn[] {dtParent.Columns["ParentKey1"], dtParent.Columns["ParentKey2"]},
			new DataColumn[] {dtChild.Columns["ParentKey1"], dtChild.Columns["ParentKey2"]},
			true);

		resultTextBox.Text = result.ToString() + Environment.NewLine + "Done.";
	}
}