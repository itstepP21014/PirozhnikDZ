using System;
using System.Configuration;
using System.Windows.Forms;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class PessimisticUpdatesForm : System.Windows.Forms.Form
{
	private DataTable dt;
	private SqlDataAdapter da;

	private const String TABLENAME="TBL0613";

	// table column name constants 
	private const String ID_FIELD				= "Id";
	private const String FIELD1_FIELD			= "Field1";
	private const String FIELD2_FIELD			= "Field2";
	private const String LOCKID_FIELD			= "LockId";
	private const String LOCKDATETIME_FIELD		= "LockDateTime";
	// expression in table
	private const String ISLOCKED_FIELD			= "IsLocked";

	// stored procedure name constants
	private const String DELETE_SP				= "SP0613_Delete";
	private const String GET_SP					= "SP0613_Get";
	private const String INSERT_SP				= "SP0613_Insert";
	private const String UPDATE_SP				= "SP0613_Update";

	private const String ACQUIRELOCK_SP			= "SP0613_AcquireLock";
	private const String RELEASELOCK_SP			= "SP0613_ReleaseLock";

	// stored procedure parameter name constants for  table
	private const String ID_PARM				= "@Id";
	private const String FIELD1_PARM			= "@Field1";
	private const String FIELD2_PARM			= "@Field2";
	private const String LOCKID_PARM			= "@LockId";
	
	private const String RETVAL_PARM			= "@RetVal";

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button updateButton;
	private System.Windows.Forms.Button refreshButton;
	private System.Windows.Forms.Button lockButton;
	private System.Windows.Forms.Button releaseButton;
	private System.Windows.Forms.Button forceReleaseButton;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public PessimisticUpdatesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.updateButton = new System.Windows.Forms.Button();
		this.refreshButton = new System.Windows.Forms.Button();
		this.lockButton = new System.Windows.Forms.Button();
		this.releaseButton = new System.Windows.Forms.Button();
		this.forceReleaseButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 40);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 0;
		// 
		// updateButton
		// 
		this.updateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.updateButton.Location = new System.Drawing.Point(184, 8);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 2;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// refreshButton
		// 
		this.refreshButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.refreshButton.Location = new System.Drawing.Point(264, 8);
		this.refreshButton.Name = "refreshButton";
		this.refreshButton.TabIndex = 3;
		this.refreshButton.Text = "Refresh";
		this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
		// 
		// lockButton
		// 
		this.lockButton.Location = new System.Drawing.Point(8, 8);
		this.lockButton.Name = "lockButton";
		this.lockButton.TabIndex = 0;
		this.lockButton.Text = "Lock";
		this.lockButton.Click += new System.EventHandler(this.lockButton_Click);
		// 
		// releaseButton
		// 
		this.releaseButton.Location = new System.Drawing.Point(88, 8);
		this.releaseButton.Name = "releaseButton";
		this.releaseButton.TabIndex = 1;
		this.releaseButton.Text = "Release";
		this.releaseButton.Click += new System.EventHandler(this.releaseButton_Click);
		// 
		// forceReleaseButton
		// 
		this.forceReleaseButton.Location = new System.Drawing.Point(392, 8);
		this.forceReleaseButton.Name = "forceReleaseButton";
		this.forceReleaseButton.Size = new System.Drawing.Size(88, 23);
		this.forceReleaseButton.TabIndex = 4;
		this.forceReleaseButton.Text = "Force Release";
		this.forceReleaseButton.Click += new System.EventHandler(this.forceReleaseButton_Click);
		// 
		// PessimisticUpdatesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.forceReleaseButton);
		this.Controls.Add(this.releaseButton);
		this.Controls.Add(this.lockButton);
		this.Controls.Add(this.refreshButton);
		this.Controls.Add(this.updateButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "PessimisticUpdatesForm";
		this.Text = "6.13 PessimisticUpdatesForm";
		this.Load += new System.EventHandler(this.PessimisticUpdatesForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void PessimisticUpdatesForm_Load(object sender, System.EventArgs e)
	{
		// build the table
		dt = new DataTable(TABLENAME);

		// create the DataAdapter
		da = new SqlDataAdapter();
		// add a handler for the RowUpdated event
		da.RowUpdated += new SqlRowUpdatedEventHandler(da_RowUpdated);

		// create a connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// build the  select command
		SqlCommand selectCommand = new SqlCommand(GET_SP, conn);
		selectCommand.CommandType = CommandType.StoredProcedure;
		da.SelectCommand = selectCommand;

		// build the  delete command
		SqlCommand deleteCommand = new SqlCommand(DELETE_SP, conn);
		deleteCommand.CommandType = CommandType.StoredProcedure;
		deleteCommand.Parameters.Add(ID_PARM, SqlDbType.Int, 0, ID_FIELD);
		deleteCommand.Parameters.Add(LOCKID_PARM, SqlDbType.UniqueIdentifier, 0, LOCKID_FIELD);
		deleteCommand.Parameters.Add(RETVAL_PARM, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
		da.DeleteCommand = deleteCommand;

		// build the  insert command
		SqlCommand insertCommand = new SqlCommand(INSERT_SP, conn);
		insertCommand.CommandType = CommandType.StoredProcedure;
		insertCommand.Parameters.Add(ID_PARM, SqlDbType.Int, 0, ID_FIELD);
		insertCommand.Parameters.Add(FIELD1_PARM, SqlDbType.NVarChar, 50, FIELD1_FIELD);
		insertCommand.Parameters.Add(FIELD2_PARM, SqlDbType.NVarChar, 50, FIELD2_FIELD);
		da.InsertCommand = insertCommand;

		// build the  update command
		SqlCommand updateCommand = new SqlCommand(UPDATE_SP, conn);
		updateCommand.CommandType = CommandType.StoredProcedure;
		updateCommand.Parameters.Add(ID_PARM, SqlDbType.Int, 0, ID_FIELD);
		updateCommand.Parameters.Add(FIELD1_PARM, SqlDbType.NVarChar, 50, FIELD1_FIELD);
		updateCommand.Parameters.Add(FIELD2_PARM, SqlDbType.NVarChar, 50, FIELD2_FIELD);
		updateCommand.Parameters.Add(LOCKID_PARM, SqlDbType.UniqueIdentifier, 0, LOCKID_FIELD);
		updateCommand.Parameters.Add(RETVAL_PARM, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
		da.UpdateCommand = updateCommand;

		// fill the table
		da.FillSchema(dt, SchemaType.Source);
		da.Fill(dt);

		// unlock the IsLocked expression column
		dt.Columns[ISLOCKED_FIELD].ReadOnly = false;

		// add a column to the table to control the locking
		dt.Columns.Add("LockId", typeof(Guid));

		// bind the default view of the table to the grid
		dataGrid.DataSource = dt.DefaultView;
	}

	private void lockButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder sb = new StringBuilder();

		// lock all of the rows in the table
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// create a command for the lock stored procedure
		SqlCommand cmd = new SqlCommand();
		cmd.Connection = conn;
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.CommandText = ACQUIRELOCK_SP;
		cmd.Parameters.Add(ID_PARM, SqlDbType.Int);
		cmd.Parameters.Add(LOCKID_PARM, SqlDbType.UniqueIdentifier);
		cmd.Parameters.Add(RETVAL_PARM, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;

		conn.Open();
		// iterate over the row collection for the table
		foreach(DataRow row in dt.Rows)
		{
			// generate a lock ID
			Guid lockId = Guid.NewGuid();

			// execute the lock command to acquire a lock on the row
			cmd.Parameters[ID_PARM].Value = row[ID_FIELD];
			cmd.Parameters[LOCKID_PARM].Value = lockId;
			cmd.ExecuteNonQuery();
			if((int)cmd.Parameters[RETVAL_PARM].Value == 0)
			{
				// row lock could not be acquired
				sb.Append("Could not aquire lock on row [ID = " + row[ID_FIELD] + "]." + Environment.NewLine);
				row[LOCKID_FIELD] = DBNull.Value;
			}
			else
				// row lock acquired
				row[LOCKID_FIELD] = lockId;
				row[ISLOCKED_FIELD] = 1;
		}
		conn.Close();

		// display an error message for locks that could not be acquired
		if(sb.Length > 0)
			MessageBox.Show(sb.ToString(), "Simulate Pessimistic Locking", MessageBoxButtons.OK, MessageBoxIcon.Error);
	}

	private void releaseButton_Click(object sender, System.EventArgs e)
	{
		StringBuilder sb = new StringBuilder();

		// release lock on all of the rows in the table
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// create a command for the release stored procedure
		SqlCommand cmd = new SqlCommand();
		cmd.Connection = conn;
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.CommandText = RELEASELOCK_SP;
		cmd.Parameters.Add(ID_PARM, SqlDbType.Int);
		cmd.Parameters.Add(LOCKID_PARM, SqlDbType.UniqueIdentifier);
		cmd.Parameters.Add(RETVAL_PARM, SqlDbType.Int).Direction = ParameterDirection.ReturnValue;

		conn.Open();
		// iterate over the collection of rows in the table
		foreach(DataRow row in dt.Rows)
		{
			// execute the command to release the lock on the row
			cmd.Parameters[ID_PARM].Value = row[ID_FIELD];
			cmd.Parameters[LOCKID_PARM].Value = row[LOCKID_FIELD];
			cmd.ExecuteNonQuery();
			if((int)cmd.Parameters[RETVAL_PARM].Value == 0)
				// row lock could not be released
				sb.Append("Could not release lock on row [ID = " + row[ID_FIELD] + "]." + Environment.NewLine);
			else
			{
				// row lock released
				row[LOCKID_FIELD] = DBNull.Value;
				row[ISLOCKED_FIELD] = 0;
			}
		}
		conn.Close();

		// display an error message for locks which could not be released
		if(sb.Length > 0)
			MessageBox.Show(sb.ToString(), "Simulate Pessimistic Locking", MessageBoxButtons.OK, MessageBoxIcon.Error);
	}

	private void forceReleaseButton_Click(object sender, System.EventArgs e)
	{
		// normally security would be used to block this statement
		// from being executed
		// clear all of the locks that exist on the table

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		String sqlText = "UPDATE " + TABLENAME + " SET " + LOCKID_FIELD + " = NULL, " + LOCKDATETIME_FIELD + " = NULL";
		// create and execute the command to force release on all rows
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		conn.Open();
		cmd.ExecuteNonQuery();
		conn.Close();

		// update the lock ID
		foreach(DataRow row in dt.Rows)
		{
			row[LOCKID_FIELD] = DBNull.Value;
			row[ISLOCKED_FIELD] = 0;
		}

		MessageBox.Show("All row locks on table released.", "Simulate Pessimistic Locking", MessageBoxButtons.OK, MessageBoxIcon.Information);
	}
	
	private void updateButton_Click(object sender, System.EventArgs e)
	{
		try
		{
			// use the DataAdapter to update the table
			da.Update(dt);
		}
		catch(Exception ex)
		{
			// display error message if the row is not locked for update
			MessageBox.Show("ERROR: " + ex.Message, "Simulate Pessimistic Locking", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}
	}

	private void refreshButton_Click(object sender, System.EventArgs e)
	{
		// refresh the data from the source
		dt.Clear();
		da.Fill(dt);		
	}

	private void da_RowUpdated(object sender, SqlRowUpdatedEventArgs e)
	{
		if(e.StatementType == StatementType.Update && (int)e.Command.Parameters[RETVAL_PARM].Value == 0)
		{
			// row error if row could not be updated without lock
			e.Row.RowError = "Lock required to update this row.";
			// continue processing the update for the other rows
			e.Status = UpdateStatus.Continue;
		}

		if(e.StatementType == StatementType.Delete && (int)e.Command.Parameters[RETVAL_PARM].Value == 0)
		{
			// row error if row could not be deleted without lock
			e.Row.RowError = "Lock required to delete this row.";
			// continue processing the update for the other rows
			e.Status = UpdateStatus.Continue;
		}
	}
}