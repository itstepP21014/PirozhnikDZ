using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class NestedManualTransactionForm : System.Windows.Forms.Form
{
	private const String CATEGORIES_TABLE	= "Categories";

	private DataTable dt;
	private SqlDataAdapter da;

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.TextBox description2TextBox;
	private System.Windows.Forms.TextBox categoryName2TextBox;
	private System.Windows.Forms.TextBox description1TextBox;
	private System.Windows.Forms.TextBox categoryName1TextBox;
	private System.Windows.Forms.Button insertButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public NestedManualTransactionForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.label3 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.description2TextBox = new System.Windows.Forms.TextBox();
		this.categoryName2TextBox = new System.Windows.Forms.TextBox();
		this.description1TextBox = new System.Windows.Forms.TextBox();
		this.categoryName1TextBox = new System.Windows.Forms.TextBox();
		this.insertButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 113);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(476, 344);
		this.dataGrid.TabIndex = 19;
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(120, 17);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(232, 16);
		this.label3.TabIndex = 18;
		this.label3.Text = "Description";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 17);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(100, 16);
		this.label2.TabIndex = 17;
		this.label2.Text = "Category Name";
		// 
		// description2TextBox
		// 
		this.description2TextBox.Location = new System.Drawing.Point(120, 73);
		this.description2TextBox.Name = "description2TextBox";
		this.description2TextBox.Size = new System.Drawing.Size(362, 20);
		this.description2TextBox.TabIndex = 15;
		this.description2TextBox.Text = "";
		// 
		// categoryName2TextBox
		// 
		this.categoryName2TextBox.Location = new System.Drawing.Point(8, 73);
		this.categoryName2TextBox.Name = "categoryName2TextBox";
		this.categoryName2TextBox.TabIndex = 14;
		this.categoryName2TextBox.Text = "";
		// 
		// description1TextBox
		// 
		this.description1TextBox.Location = new System.Drawing.Point(120, 41);
		this.description1TextBox.Name = "description1TextBox";
		this.description1TextBox.Size = new System.Drawing.Size(362, 20);
		this.description1TextBox.TabIndex = 13;
		this.description1TextBox.Text = "";
		// 
		// categoryName1TextBox
		// 
		this.categoryName1TextBox.Location = new System.Drawing.Point(8, 41);
		this.categoryName1TextBox.Name = "categoryName1TextBox";
		this.categoryName1TextBox.TabIndex = 12;
		this.categoryName1TextBox.Text = "";
		// 
		// insertButton
		// 
		this.insertButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.insertButton.Location = new System.Drawing.Point(408, 9);
		this.insertButton.Name = "insertButton";
		this.insertButton.TabIndex = 16;
		this.insertButton.Text = "Insert";
		this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
		// 
		// NestedManualTransactionForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 466);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.dataGrid,
																		this.label3,
																		this.label2,
																		this.description2TextBox,
																		this.categoryName2TextBox,
																		this.description1TextBox,
																		this.categoryName1TextBox,
																		this.insertButton});
		this.Name = "NestedManualTransactionForm";
		this.Text = "6.03 NestedManualTransactionForm";
		this.Load += new System.EventHandler(this.NestedTransactionForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void NestedTransactionForm_Load(object sender, System.EventArgs e)
	{
		// fill the categories table
		String sqlText = "SELECT CategoryID, CategoryName, Description FROM Categories";
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		dt = new DataTable(CATEGORIES_TABLE);
		da.FillSchema(dt, SchemaType.Source);
		da.Fill(dt);

		// bind the default view of the table to the grid
		dataGrid.DataSource = dt.DefaultView;		
	}

	private void insertButton_Click(object sender, System.EventArgs e)
	{
		String sqlText = "INSERT " + CATEGORIES_TABLE + " "+ 
			"(CategoryName, Description) VALUES " +
			"(@CategoryName, @Description)";

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// create the transaction
		conn.Open();
		SqlTransaction tran = conn.BeginTransaction();

		// create command in the transaction with parameters
		SqlCommand cmd = new SqlCommand(sqlText, conn, tran);
		cmd.Parameters.Add(new SqlParameter("@CategoryName", SqlDbType.NVarChar, 15));
		cmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar, 100));

		try
		{
			// insert the records into the table
			if (categoryName1TextBox.Text.Trim().Length == 0)
				// if CategoryName is empty, make it null (invalid)
				cmd.Parameters["@CategoryName"].Value = DBNull.Value;
			else
				cmd.Parameters["@CategoryName"].Value = categoryName1TextBox.Text;
			cmd.Parameters["@Description"].Value = description1TextBox.Text;
			cmd.ExecuteNonQuery();
		}
		catch (Exception ex)
		{
			// exception occurred - roll back the transaction
			tran.Rollback();
			MessageBox.Show(ex.Message + Environment.NewLine + 
				"Transaction rollback (records 1 and 2).");
			conn.Close();
			return;
		}

		tran.Save("SavePoint1");

		try
		{
			// insert the records into the table
			if (categoryName2TextBox.Text.Trim().Length == 0)
				// if CategoryName is empty, make it null (invalid)
				cmd.Parameters["@CategoryName"].Value = DBNull.Value;
			else
				cmd.Parameters["@CategoryName"].Value = categoryName2TextBox.Text;
			cmd.Parameters["@Description"].Value = description2TextBox.Text;
			cmd.ExecuteNonQuery();
			
			//if okay to here, commit the transaction
			tran.Commit();

			MessageBox.Show("Transaction committed (records 1 and 2).");
		}
		catch (SqlException ex)
		{
			tran.Rollback("SavePoint1");
			tran.Commit();
			MessageBox.Show(ex.Message + Environment.NewLine + 
				"Transaction commit (record 1)." + Environment.NewLine +
				"Transaction rollback (record 2).");
		}
		finally
		{
			conn.Close();
		}

		// refresh the data
		da.Fill(dt);
	}
}