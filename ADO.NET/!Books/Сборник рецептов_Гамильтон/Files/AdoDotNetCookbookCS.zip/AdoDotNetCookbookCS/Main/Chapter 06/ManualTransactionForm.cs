using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class ManualTransactionForm : System.Windows.Forms.Form
{
	private const String CATEGORIES_TABLE	= "Categories";

	private DataTable dt;
	private SqlDataAdapter da;

	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Label label3;
	private System.Windows.Forms.Button insertButton;
	private System.Windows.Forms.TextBox categoryName1TextBox;
	private System.Windows.Forms.TextBox description1TextBox;
	private System.Windows.Forms.TextBox description2TextBox;
	private System.Windows.Forms.TextBox categoryName2TextBox;
	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ManualTransactionForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.insertButton = new System.Windows.Forms.Button();
		this.categoryName1TextBox = new System.Windows.Forms.TextBox();
		this.description1TextBox = new System.Windows.Forms.TextBox();
		this.description2TextBox = new System.Windows.Forms.TextBox();
		this.categoryName2TextBox = new System.Windows.Forms.TextBox();
		this.label2 = new System.Windows.Forms.Label();
		this.label3 = new System.Windows.Forms.Label();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// insertButton
		// 
		this.insertButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.insertButton.Location = new System.Drawing.Point(408, 8);
		this.insertButton.Name = "insertButton";
		this.insertButton.TabIndex = 7;
		this.insertButton.Text = "Insert";
		this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
		// 
		// categoryName1TextBox
		// 
		this.categoryName1TextBox.Location = new System.Drawing.Point(8, 40);
		this.categoryName1TextBox.Name = "categoryName1TextBox";
		this.categoryName1TextBox.TabIndex = 2;
		this.categoryName1TextBox.Text = "";
		// 
		// description1TextBox
		// 
		this.description1TextBox.Location = new System.Drawing.Point(120, 40);
		this.description1TextBox.Name = "description1TextBox";
		this.description1TextBox.Size = new System.Drawing.Size(362, 20);
		this.description1TextBox.TabIndex = 3;
		this.description1TextBox.Text = "";
		// 
		// description2TextBox
		// 
		this.description2TextBox.Location = new System.Drawing.Point(120, 72);
		this.description2TextBox.Name = "description2TextBox";
		this.description2TextBox.Size = new System.Drawing.Size(362, 20);
		this.description2TextBox.TabIndex = 6;
		this.description2TextBox.Text = "";
		// 
		// categoryName2TextBox
		// 
		this.categoryName2TextBox.Location = new System.Drawing.Point(8, 72);
		this.categoryName2TextBox.Name = "categoryName2TextBox";
		this.categoryName2TextBox.TabIndex = 5;
		this.categoryName2TextBox.Text = "";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 16);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(100, 16);
		this.label2.TabIndex = 9;
		this.label2.Text = "Category Name";
		// 
		// label3
		// 
		this.label3.Location = new System.Drawing.Point(120, 16);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(72, 16);
		this.label3.TabIndex = 10;
		this.label3.Text = "Description";
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 112);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(476, 344);
		this.dataGrid.TabIndex = 11;
		// 
		// ManualTransactionForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 466);
		this.Controls.Add(this.dataGrid);
		this.Controls.Add(this.label3);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.description2TextBox);
		this.Controls.Add(this.categoryName2TextBox);
		this.Controls.Add(this.description1TextBox);
		this.Controls.Add(this.categoryName1TextBox);
		this.Controls.Add(this.insertButton);
		this.Name = "ManualTransactionForm";
		this.Text = "6.02 ManualTransactionForm";
		this.Load += new System.EventHandler(this.ManualTransactionForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void ManualTransactionForm_Load(object sender, System.EventArgs e)
	{
		// fill the categories table
		String sqlText = "SELECT CategoryID, CategoryName, Description FROM Categories";
		da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		dt = new DataTable(CATEGORIES_TABLE);
		da.FillSchema(dt, SchemaType.Source);
		da.Fill(dt);

		// bind the default view of the table to the grid
		dataGrid.DataSource = dt.DefaultView;		
	}

	private void insertButton_Click(object sender, System.EventArgs e)
	{
		String sqlText = "INSERT " + CATEGORIES_TABLE + " "+ 
			"(CategoryName, Description) VALUES " +
			"(@CategoryName, @Description)";

		// create the connection
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// create the transaction
		conn.Open();
		SqlTransaction tran = conn.BeginTransaction();

		// create command in the transaction with parameters
		SqlCommand cmd = new SqlCommand(sqlText, conn, tran);
		cmd.Parameters.Add(new SqlParameter("@CategoryName", SqlDbType.NVarChar, 15));
		cmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar, 100));

		try
		{
			// insert the records into the table
			if (categoryName1TextBox.Text.Trim().Length == 0)
				// if CategoryName is empty, make it null (invalid)
				cmd.Parameters["@CategoryName"].Value = DBNull.Value;
			else
				cmd.Parameters["@CategoryName"].Value = categoryName1TextBox.Text;
			cmd.Parameters["@Description"].Value = description1TextBox.Text;
			cmd.ExecuteNonQuery();

			if (categoryName2TextBox.Text.Trim().Length == 0)
				cmd.Parameters["@CategoryName"].Value = DBNull.Value;
			else
				cmd.Parameters["@CategoryName"].Value = categoryName2TextBox.Text;
			cmd.Parameters["@Description"].Value = description2TextBox.Text;
			cmd.ExecuteNonQuery();

			//if okay to here, commit the transaction
			tran.Commit();

			MessageBox.Show("Transaction committed.");
		}
		catch (Exception ex)
		{
			// exception occurred - roll back the transaction
			tran.Rollback();
			MessageBox.Show(ex.Message + Environment.NewLine + 
				"Transaction rollback.");
		}
		finally
		{
			conn.Close();
		}

		// refresh the data
		da.Fill(dt);
	}
}