using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class TransactionIsolationLevelsForm : System.Windows.Forms.Form
{
	private SqlConnection conn;
	private SqlTransaction tran;

	private System.Windows.Forms.Button startButton;
	private System.Windows.Forms.Button cancelButton;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.GroupBox groupBox1;
	private System.Windows.Forms.RadioButton chaosRadioButton;
	private System.Windows.Forms.RadioButton readCommittedRadioButton;
	private System.Windows.Forms.RadioButton readUncommittedRadioButton;
	private System.Windows.Forms.RadioButton repeatableReadRadioButton;
	private System.Windows.Forms.RadioButton serializableRadioButton;
	private System.Windows.Forms.RadioButton unspecifiedRadioButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public TransactionIsolationLevelsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.startButton = new System.Windows.Forms.Button();
		this.cancelButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.unspecifiedRadioButton = new System.Windows.Forms.RadioButton();
		this.serializableRadioButton = new System.Windows.Forms.RadioButton();
		this.repeatableReadRadioButton = new System.Windows.Forms.RadioButton();
		this.readUncommittedRadioButton = new System.Windows.Forms.RadioButton();
		this.readCommittedRadioButton = new System.Windows.Forms.RadioButton();
		this.chaosRadioButton = new System.Windows.Forms.RadioButton();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.groupBox1.SuspendLayout();
		this.SuspendLayout();
		// 
		// startButton
		// 
		this.startButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.startButton.Location = new System.Drawing.Point(409, 9);
		this.startButton.Name = "startButton";
		this.startButton.TabIndex = 7;
		this.startButton.Text = "Start Tran";
		this.startButton.Click += new System.EventHandler(this.startButton_Click);
		// 
		// cancelButton
		// 
		this.cancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
		this.cancelButton.Enabled = false;
		this.cancelButton.Location = new System.Drawing.Point(409, 41);
		this.cancelButton.Name = "cancelButton";
		this.cancelButton.TabIndex = 10;
		this.cancelButton.Text = "Cancel";
		this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(9, 144);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(476, 212);
		this.dataGrid.TabIndex = 9;
		// 
		// groupBox1
		// 
		this.groupBox1.Controls.Add(this.unspecifiedRadioButton);
		this.groupBox1.Controls.Add(this.serializableRadioButton);
		this.groupBox1.Controls.Add(this.repeatableReadRadioButton);
		this.groupBox1.Controls.Add(this.readUncommittedRadioButton);
		this.groupBox1.Controls.Add(this.readCommittedRadioButton);
		this.groupBox1.Controls.Add(this.chaosRadioButton);
		this.groupBox1.Location = new System.Drawing.Point(8, 8);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(192, 120);
		this.groupBox1.TabIndex = 11;
		this.groupBox1.TabStop = false;
		this.groupBox1.Text = "Isolation Level";
		// 
		// unspecifiedRadioButton
		// 
		this.unspecifiedRadioButton.Checked = true;
		this.unspecifiedRadioButton.Location = new System.Drawing.Point(8, 96);
		this.unspecifiedRadioButton.Name = "unspecifiedRadioButton";
		this.unspecifiedRadioButton.Size = new System.Drawing.Size(144, 16);
		this.unspecifiedRadioButton.TabIndex = 5;
		this.unspecifiedRadioButton.TabStop = true;
		this.unspecifiedRadioButton.Text = "Unspecified";
		// 
		// serializableRadioButton
		// 
		this.serializableRadioButton.Location = new System.Drawing.Point(8, 80);
		this.serializableRadioButton.Name = "serializableRadioButton";
		this.serializableRadioButton.Size = new System.Drawing.Size(144, 16);
		this.serializableRadioButton.TabIndex = 4;
		this.serializableRadioButton.Text = "Serializable";
		// 
		// repeatableReadRadioButton
		// 
		this.repeatableReadRadioButton.Location = new System.Drawing.Point(8, 64);
		this.repeatableReadRadioButton.Name = "repeatableReadRadioButton";
		this.repeatableReadRadioButton.Size = new System.Drawing.Size(144, 16);
		this.repeatableReadRadioButton.TabIndex = 3;
		this.repeatableReadRadioButton.Text = "Repeatable Read";
		// 
		// readUncommittedRadioButton
		// 
		this.readUncommittedRadioButton.Location = new System.Drawing.Point(8, 48);
		this.readUncommittedRadioButton.Name = "readUncommittedRadioButton";
		this.readUncommittedRadioButton.Size = new System.Drawing.Size(144, 16);
		this.readUncommittedRadioButton.TabIndex = 2;
		this.readUncommittedRadioButton.Text = "Read Uncommitted";
		// 
		// readCommittedRadioButton
		// 
		this.readCommittedRadioButton.Location = new System.Drawing.Point(8, 32);
		this.readCommittedRadioButton.Name = "readCommittedRadioButton";
		this.readCommittedRadioButton.Size = new System.Drawing.Size(144, 16);
		this.readCommittedRadioButton.TabIndex = 1;
		this.readCommittedRadioButton.Text = "Read Committed";
		// 
		// chaosRadioButton
		// 
		this.chaosRadioButton.Location = new System.Drawing.Point(8, 16);
		this.chaosRadioButton.Name = "chaosRadioButton";
		this.chaosRadioButton.Size = new System.Drawing.Size(144, 16);
		this.chaosRadioButton.TabIndex = 0;
		this.chaosRadioButton.Text = "Chaos";
		// 
		// TransactionIsolationLevelsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 366);
		this.Controls.Add(this.groupBox1);
		this.Controls.Add(this.startButton);
		this.Controls.Add(this.cancelButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "TransactionIsolationLevelsForm";
		this.Text = "6.12 TransactionIsolationLevelsForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.groupBox1.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion

	private void startButton_Click(object sender, System.EventArgs e)
	{
		startButton.Enabled = false;

		// get the user defined isolation level
		IsolationLevel il = IsolationLevel.Unspecified;
		if(chaosRadioButton.Checked)
			il = IsolationLevel.Chaos;
		else if(readCommittedRadioButton.Checked)
			il = IsolationLevel.ReadCommitted;
		else if(readUncommittedRadioButton.Checked)
			il = IsolationLevel.ReadUncommitted;
		else if(repeatableReadRadioButton.Checked)
			il = IsolationLevel.RepeatableRead;
		else if(serializableRadioButton.Checked)
			il = IsolationLevel.Serializable;
		else if(unspecifiedRadioButton.Checked)
			il = IsolationLevel.Unspecified;
		
		// open a connection
		conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		conn.Open();
		try
		{
			// start a transaction
			tran = conn.BeginTransaction(il);
		}
		catch(Exception ex)
		{
			// could not start the transaction - close the connection
			conn.Close();

			MessageBox.Show(ex.Message,"Transaction Isolation Levels", MessageBoxButtons.OK, MessageBoxIcon.Error);
			startButton.Enabled = true;
			return;
		}

		String sqlText = "SELECT * FROM Orders";
		// create a command using the transaction
		SqlCommand cmd = new SqlCommand(sqlText, conn, tran);
		// create a DataAdapter to retrieve all Orders
		SqlDataAdapter da = new SqlDataAdapter(cmd);
		// define a CommandBuilder for the DataAdapter
		SqlCommandBuilder cb = new SqlCommandBuilder(da);
		// fill table with Orders
		DataTable dt = new DataTable();
		da.Fill(dt);

		// bind the default view of the table to the grid
		dataGrid.DataSource = dt.DefaultView;
					
		cancelButton.Enabled = true;
		dataGrid.ReadOnly = false;
	}

	private void cancelButton_Click(object sender, System.EventArgs e)
	{
		cancelButton.Enabled = false;
		dataGrid.ReadOnly = true;

		// roll back the transaction and close the connection
		tran.Rollback();
		conn.Close();

		// unbind the grid
		dataGrid.DataSource = null;

		startButton.Enabled = true;
	}

	private void UsingLockingHintsForPessimisticLockingForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
	{
		// roll back the transaction and close the connection
		tran.Rollback();
		conn.Close();
	}
}