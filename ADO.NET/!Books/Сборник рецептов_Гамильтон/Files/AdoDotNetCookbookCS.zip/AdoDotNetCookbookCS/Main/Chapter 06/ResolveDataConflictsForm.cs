using System;
using System.Configuration;
using System.Text;

using System.Data;
using System.Data.SqlClient;

public class ResolveDataConflictsForm : System.Windows.Forms.Form
{
	private const String TABLENAME	= "TBL0611";

	private SqlDataAdapter daA, daB;
	private DataSet dsA, dsB;

	private SqlDataAdapter conflictDaA, conflictDaB;
	private DataSet conflictDsA, conflictDsB;

	private System.Windows.Forms.DataGrid dataGridA;
	private System.Windows.Forms.DataGrid dataGridB;
	private System.Windows.Forms.Button refreshAButton;
	private System.Windows.Forms.Button refreshBButton;
	private System.Windows.Forms.Button updateAButton;
	private System.Windows.Forms.Button updateBButton;
	private System.Windows.Forms.DataGrid conflictDataGridA;
	private System.Windows.Forms.DataGrid conflictDataGridB;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public ResolveDataConflictsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGridA = new System.Windows.Forms.DataGrid();
		this.dataGridB = new System.Windows.Forms.DataGrid();
		this.refreshAButton = new System.Windows.Forms.Button();
		this.refreshBButton = new System.Windows.Forms.Button();
		this.updateAButton = new System.Windows.Forms.Button();
		this.updateBButton = new System.Windows.Forms.Button();
		this.conflictDataGridA = new System.Windows.Forms.DataGrid();
		this.conflictDataGridB = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGridA)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.dataGridB)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.conflictDataGridA)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.conflictDataGridB)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGridA
		// 
		this.dataGridA.CaptionText = "Client A";
		this.dataGridA.DataMember = "";
		this.dataGridA.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGridA.Location = new System.Drawing.Point(10, 10);
		this.dataGridA.Name = "dataGridA";
		this.dataGridA.Size = new System.Drawing.Size(280, 150);
		this.dataGridA.TabIndex = 0;
		// 
		// dataGridB
		// 
		this.dataGridB.CaptionText = "Client B";
		this.dataGridB.DataMember = "";
		this.dataGridB.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGridB.Location = new System.Drawing.Point(305, 10);
		this.dataGridB.Name = "dataGridB";
		this.dataGridB.Size = new System.Drawing.Size(280, 150);
		this.dataGridB.TabIndex = 1;
		// 
		// refreshAButton
		// 
		this.refreshAButton.Location = new System.Drawing.Point(10, 168);
		this.refreshAButton.Name = "refreshAButton";
		this.refreshAButton.TabIndex = 2;
		this.refreshAButton.Text = "Refresh A";
		this.refreshAButton.Click += new System.EventHandler(this.refreshAButton_Click);
		// 
		// refreshBButton
		// 
		this.refreshBButton.Location = new System.Drawing.Point(305, 168);
		this.refreshBButton.Name = "refreshBButton";
		this.refreshBButton.TabIndex = 4;
		this.refreshBButton.Text = "Refresh B";
		this.refreshBButton.Click += new System.EventHandler(this.refreshBButton_Click);
		// 
		// updateAButton
		// 
		this.updateAButton.Location = new System.Drawing.Point(88, 168);
		this.updateAButton.Name = "updateAButton";
		this.updateAButton.TabIndex = 3;
		this.updateAButton.Text = "Update A";
		this.updateAButton.Click += new System.EventHandler(this.updateAButton_Click);
		// 
		// updateBButton
		// 
		this.updateBButton.Location = new System.Drawing.Point(384, 168);
		this.updateBButton.Name = "updateBButton";
		this.updateBButton.TabIndex = 5;
		this.updateBButton.Text = "Update B";
		this.updateBButton.Click += new System.EventHandler(this.updateBButton_Click);
		// 
		// conflictDataGridA
		// 
		this.conflictDataGridA.CaptionText = "Conflicts A - Original Values";
		this.conflictDataGridA.DataMember = "";
		this.conflictDataGridA.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.conflictDataGridA.Location = new System.Drawing.Point(10, 200);
		this.conflictDataGridA.Name = "conflictDataGridA";
		this.conflictDataGridA.ReadOnly = true;
		this.conflictDataGridA.Size = new System.Drawing.Size(280, 150);
		this.conflictDataGridA.TabIndex = 6;
		// 
		// conflictDataGridB
		// 
		this.conflictDataGridB.CaptionText = "Conflicts B - Original Values";
		this.conflictDataGridB.DataMember = "";
		this.conflictDataGridB.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.conflictDataGridB.Location = new System.Drawing.Point(305, 200);
		this.conflictDataGridB.Name = "conflictDataGridB";
		this.conflictDataGridB.ReadOnly = true;
		this.conflictDataGridB.Size = new System.Drawing.Size(280, 150);
		this.conflictDataGridB.TabIndex = 7;
		// 
		// ResolveDataConflictsForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(592, 358);
		this.Controls.Add(this.conflictDataGridB);
		this.Controls.Add(this.conflictDataGridA);
		this.Controls.Add(this.updateBButton);
		this.Controls.Add(this.updateAButton);
		this.Controls.Add(this.refreshBButton);
		this.Controls.Add(this.refreshAButton);
		this.Controls.Add(this.dataGridB);
		this.Controls.Add(this.dataGridA);
		this.Name = "ResolveDataConflictsForm";
		this.Text = "6.11 ResolveDataConflictsForm";
		this.Load += new System.EventHandler(this.ResolveDataConflictsForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGridA)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.dataGridB)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.conflictDataGridA)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.conflictDataGridB)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void ResolveDataConflictsForm_Load(object sender, System.EventArgs e)
	{
		// table A and B are filled from the same data source table
		String sqlText = "SELECT * FROM " + TABLENAME;

		// create the DataAdapter for table A
		daA = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_SqlAuth_ConnectString"]);
		daA.ContinueUpdateOnError = true;
		// handle the RowUpdated event
		daA.RowUpdated += new SqlRowUpdatedEventHandler(daA_RowUpdated);
		// get the schema and data for table A in the DataSet
		dsA = new DataSet("A");
		daA.FillSchema(dsA, SchemaType.Source, TABLENAME);
		daA.Fill(dsA, TABLENAME);
		// create the command builder
		SqlCommandBuilder cbA = new SqlCommandBuilder(daA);
		// bind the default view for table A to the grid
		dataGridA.DataSource = dsA.Tables[TABLENAME].DefaultView;

		// create a DataAdapter to retrieve original rows
		// for conflicts when updating table A
		conflictDaA = new SqlDataAdapter(sqlText + " WHERE Id = @Id", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		conflictDaA.SelectCommand.Parameters.Add("@Id", SqlDbType.Int, 0);
		// create a DataSet with the conflict table schema
		conflictDsA = new DataSet();
		daA.FillSchema(conflictDsA, SchemaType.Source, TABLENAME);
		// bind the default view for conflict table B to the grid
		conflictDataGridA.DataSource = conflictDsA.Tables[TABLENAME].DefaultView;

		// create the DataAdapter for table B
		daB = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_SqlAuth_ConnectString"]);
		daB.ContinueUpdateOnError = true;
		// handle the RowUpdated event
		daB.RowUpdated += new SqlRowUpdatedEventHandler(daB_RowUpdated);
		// get the schema and data for table A in the DataSet
		dsB = new DataSet("B");
		daB.FillSchema(dsB,SchemaType.Source,TABLENAME);
		daB.Fill(dsB, TABLENAME);
		// create the command builder
		SqlCommandBuilder cbB = new SqlCommandBuilder(daB);
		// bind the default view for table A to the grid
		dataGridB.DataSource = dsB.Tables[TABLENAME].DefaultView;

		// create a DataAdapter to retrieve original rows
		// for conflicts when updating table B
		conflictDaB = new SqlDataAdapter(sqlText + " WHERE Id = @Id", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		conflictDaB.SelectCommand.Parameters.Add("@Id", SqlDbType.Int, 0);
		// create a DataSet with the conflict table schema
		conflictDsB = new DataSet();
		daB.FillSchema(conflictDsB,SchemaType.Source,TABLENAME);
		// bind the default view for conflict table B to the grid
		conflictDataGridB.DataSource = conflictDsB.Tables[TABLENAME].DefaultView;
	}

	private void refreshAButton_Click(object sender, System.EventArgs e)
	{
		// clear the conflict table and reload the data
		conflictDsA.Clear();

		dsA.Clear();
		daA.Fill(dsA, TABLENAME);
	}

	private void refreshBButton_Click(object sender, System.EventArgs e)
	{
		// clear the conflict table and reload the data
		conflictDsB.Clear();

		dsB.Clear();
		daB.Fill(dsB, TABLENAME);		
	}

	private void updateAButton_Click(object sender, System.EventArgs e)
	{
		// clear the conflict table and update table A to data source
		conflictDsA.Clear();
		daA.Update(dsA, TABLENAME);
	}

	private void updateBButton_Click(object sender, System.EventArgs e)
	{
		// clear the conflict table and update table B to data source
		conflictDsB.Clear();
		daB.Update(dsB, TABLENAME);
	}

	private void daA_RowUpdated(object sender, SqlRowUpdatedEventArgs e)
	{
		// check if a concurrency exception occurred
		if (e.Status == UpdateStatus.ErrorsOccurred && e.Errors.GetType() == typeof(DBConcurrencyException))
		{
			// if the row was deleted, reject the delete
			if(e.Row.RowState == DataRowState.Deleted)
				e.Row.RejectChanges();

			// get the row ID
			conflictDaA.SelectCommand.Parameters["@Id"].Value = e.Row["ID"];
			// get the row from the data source for the conflicts table
			if(conflictDaA.Fill(conflictDsA, TABLENAME) == 1)
				e.Row.RowError = "Row has been changed in the database.";
			else
				e.Row.RowError = "Row has been deleted from the database.";
		}
	}

	private void daB_RowUpdated(object sender, SqlRowUpdatedEventArgs e)
	{
		// check if a concurrency exception occurred
		if (e.Status == UpdateStatus.ErrorsOccurred && e.Errors.GetType() == typeof(DBConcurrencyException))
		{
			// if the row was deleted, reject the delete
			if(e.Row.RowState == DataRowState.Deleted)
				e.Row.RejectChanges();
			
			// get the row ID
			conflictDaB.SelectCommand.Parameters["@Id"].Value = e.Row["ID"];
			// get the row from the data source for the conflicts table
			if(conflictDaB.Fill(conflictDsB, TABLENAME) == 1)
				e.Row.RowError = "Row has been changed in the database.";
			else
				e.Row.RowError = "Row has been deleted from the database.";
		}
	}
}