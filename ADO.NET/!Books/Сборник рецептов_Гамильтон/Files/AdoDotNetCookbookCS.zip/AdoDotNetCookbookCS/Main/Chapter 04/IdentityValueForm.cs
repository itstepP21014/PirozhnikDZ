using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class IdentityValueForm : System.Windows.Forms.Form
{
	// table name constants
	private const String CATEGORIES_TABLE		= "Categories";

	// field name constants
	private const String CATEGORYID_FIELD		= "CategoryID";
	private const String CATEGORYNAME_FIELD		= "CategoryName";
	private const String DESCRIPTION_FIELD		= "Description";

	// stored procedure name constants
	public const String GETCATEGORIES_SP		= "GetCategories";
	public const String INSERTCATEGORIES_SP		= "InsertCategories";

	// stored procedure parameter name constants for Categories table
	public const String CATEGORYID_PARM			= "@CategoryID";
	public const String CATEGORYNAME_PARM		= "@CategoryName";
	public const String DESCRIPTION_PARM		= "@Description";

	private DataTable dt;
	private SqlDataAdapter da;

	private System.Windows.Forms.Button addButton;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.TextBox categoryNameTextBox;
	private System.Windows.Forms.TextBox descriptionTextBox;
	private System.Windows.Forms.CheckBox outputParametersCheckBox;
	private System.Windows.Forms.CheckBox firstReturnedRecordCheckBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public IdentityValueForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.addButton = new System.Windows.Forms.Button();
		this.categoryNameTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.label2 = new System.Windows.Forms.Label();
		this.descriptionTextBox = new System.Windows.Forms.TextBox();
		this.outputParametersCheckBox = new System.Windows.Forms.CheckBox();
		this.firstReturnedRecordCheckBox = new System.Windows.Forms.CheckBox();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// addButton
		// 
		this.addButton.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
		this.addButton.Location = new System.Drawing.Point(312, 8);
		this.addButton.Name = "addButton";
		this.addButton.TabIndex = 4;
		this.addButton.Text = "Add";
		this.addButton.Click += new System.EventHandler(this.addButton_Click);
		// 
		// categoryNameTextBox
		// 
		this.categoryNameTextBox.Location = new System.Drawing.Point(104, 48);
		this.categoryNameTextBox.Name = "categoryNameTextBox";
		this.categoryNameTextBox.Size = new System.Drawing.Size(144, 20);
		this.categoryNameTextBox.TabIndex = 2;
		this.categoryNameTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 48);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(88, 16);
		this.label1.TabIndex = 2;
		this.label1.Text = "Category Name:";
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 104);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(376, 48);
		this.resultTextBox.TabIndex = 3;
		this.resultTextBox.Text = "";
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 160);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(378, 96);
		this.dataGrid.TabIndex = 4;
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 72);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(88, 16);
		this.label2.TabIndex = 6;
		this.label2.Text = "Description:";
		// 
		// descriptionTextBox
		// 
		this.descriptionTextBox.Location = new System.Drawing.Point(104, 72);
		this.descriptionTextBox.Name = "descriptionTextBox";
		this.descriptionTextBox.Size = new System.Drawing.Size(280, 20);
		this.descriptionTextBox.TabIndex = 3;
		this.descriptionTextBox.Text = "";
		// 
		// outputParametersCheckBox
		// 
		this.outputParametersCheckBox.Checked = true;
		this.outputParametersCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
		this.outputParametersCheckBox.Location = new System.Drawing.Point(8, 8);
		this.outputParametersCheckBox.Name = "outputParametersCheckBox";
		this.outputParametersCheckBox.Size = new System.Drawing.Size(120, 24);
		this.outputParametersCheckBox.TabIndex = 0;
		this.outputParametersCheckBox.Text = "OutputParameters";
		// 
		// firstReturnedRecordCheckBox
		// 
		this.firstReturnedRecordCheckBox.Location = new System.Drawing.Point(136, 8);
		this.firstReturnedRecordCheckBox.Name = "firstReturnedRecordCheckBox";
		this.firstReturnedRecordCheckBox.Size = new System.Drawing.Size(128, 24);
		this.firstReturnedRecordCheckBox.TabIndex = 1;
		this.firstReturnedRecordCheckBox.Text = "FirstReturnedRecord";
		// 
		// IdentityValueForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(392, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.firstReturnedRecordCheckBox,
																		this.outputParametersCheckBox,
																		this.label2,
																		this.descriptionTextBox,
																		this.dataGrid,
																		this.resultTextBox,
																		this.label1,
																		this.categoryNameTextBox,
																		this.addButton});
		this.Name = "IdentityValueForm";
		this.Text = "4.02 IdentityValueForm";
		this.Load += new System.EventHandler(this.IdentityValueForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void IdentityValueForm_Load(object sender, System.EventArgs e)
	{
		// create the Categories table
		dt = new DataTable(CATEGORIES_TABLE);

		// add the identity column
		DataColumn col = dt.Columns.Add(CATEGORYID_FIELD, typeof(System.Int32));            
		col.AllowDBNull = false;
		col.AutoIncrement = true;
		col.AutoIncrementSeed = -1;
		col.AutoIncrementStep = -1;
		// set the primary key
		dt.PrimaryKey = new DataColumn[] {col};

		// add the other columns
		col = dt.Columns.Add(CATEGORYNAME_FIELD, typeof(System.String));
		col.AllowDBNull = false;
		col.MaxLength = 15;
		dt.Columns.Add(DESCRIPTION_FIELD, typeof(System.String));

		// create the DataAdapter
		da = new SqlDataAdapter(GETCATEGORIES_SP, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.SelectCommand.CommandType = CommandType.StoredProcedure;

		// create the insert command for the DataAdapter
		da.InsertCommand = new SqlCommand(INSERTCATEGORIES_SP, da.SelectCommand.Connection);
		da.InsertCommand.CommandType = CommandType.StoredProcedure;
		// add the output parameter
		SqlParameter param = da.InsertCommand.Parameters.Add(CATEGORYID_PARM, SqlDbType.Int, 0, CATEGORYID_FIELD);
		param.Direction = ParameterDirection.Output;
		// add the other parameters
		da.InsertCommand.Parameters.Add(CATEGORYNAME_PARM, SqlDbType.NVarChar, 15, CATEGORYNAME_FIELD);
		da.InsertCommand.Parameters.Add(DESCRIPTION_PARM, SqlDbType.NText, 0, DESCRIPTION_FIELD);

		// fill the table with data
		da.Fill(dt);

		// bind the default table view to the grid
		dataGrid.DataSource = dt.DefaultView;
	}

	private void addButton_Click(object sender, System.EventArgs e)
	{
		// add the row to the Category table
		DataRow row = dt.NewRow();
		row[CATEGORYNAME_FIELD] = categoryNameTextBox.Text;
		row[DESCRIPTION_FIELD] = descriptionTextBox.Text;
		dt.Rows.Add(row);

		resultTextBox.Text = "Identity value before update = " + row[CATEGORYID_FIELD] + Environment.NewLine;

		// set the method used to return the data source identity value
		if(outputParametersCheckBox.Checked && firstReturnedRecordCheckBox.Checked)
			da.InsertCommand.UpdatedRowSource = UpdateRowSource.Both;
		else if(outputParametersCheckBox.Checked)
			da.InsertCommand.UpdatedRowSource = UpdateRowSource.OutputParameters;
		else if(firstReturnedRecordCheckBox.Checked)
			da.InsertCommand.UpdatedRowSource = UpdateRowSource.FirstReturnedRecord;
		else
			da.InsertCommand.UpdatedRowSource = UpdateRowSource.None;

		// update the data source
		da.Update(dt);

		resultTextBox.Text += "Identity value after update = " + row[CATEGORYID_FIELD];
	}
}