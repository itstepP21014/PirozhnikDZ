using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class UpdatePrimaryKeyForm : System.Windows.Forms.Form
{
	private const String TABLENAME = "TBL0408";

	private DataTable dt;
	private SqlDataAdapter da;

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button updateButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public UpdatePrimaryKeyForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.updateButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(276, 216);
		this.dataGrid.TabIndex = 0;
		// 
		// updateButton
		// 
		this.updateButton.Location = new System.Drawing.Point(208, 232);
		this.updateButton.Name = "updateButton";
		this.updateButton.TabIndex = 1;
		this.updateButton.Text = "Update";
		this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
		// 
		// UpdatePrimaryKeyForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.updateButton,
																		this.dataGrid});
		this.Name = "UpdatePrimaryKeyForm";
		this.Text = "4.08 UpdatePrimaryKeyForm";
		this.Load += new System.EventHandler(this.UpdatePrimaryKeyForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void UpdatePrimaryKeyForm_Load(object sender, System.EventArgs e)
	{
		// define the table
		dt = new DataTable(TABLENAME);
		DataColumnCollection cols;
		cols = dt.Columns;
		DataColumn col = cols.Add("Id", typeof(Int32));
		dt.PrimaryKey = new DataColumn[] {col};
		cols.Add("Field1", typeof(String)).MaxLength = 50;
		cols.Add("Field2", typeof(String)).MaxLength = 50;

		// create the DataAdapter and connection
		da = new SqlDataAdapter();
		SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);

		// build the select command
		String sqlText = "SELECT Id, Field1, Field2 FROM " + TABLENAME;
		da.SelectCommand = new SqlCommand(sqlText, conn);

		// build the delete command
		sqlText = "DELETE FROM " + TABLENAME + " WHERE Id=@Id";
		SqlCommand deleteCommand = new SqlCommand(sqlText, conn);
		deleteCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		da.DeleteCommand = deleteCommand;

		// build the insert command
		sqlText = "INSERT " + TABLENAME + " (Id, Field1, Field2) VALUES " +
			"(@Id, @Field1, @Field2)";
		SqlCommand insertCommand = new SqlCommand(sqlText, conn);
		insertCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		insertCommand.Parameters.Add("@Field1", SqlDbType.NVarChar, 50, "Field1");
		insertCommand.Parameters.Add("@Field2", SqlDbType.NVarChar, 50, "Field2");
		da.InsertCommand = insertCommand;

		// build the update command
		sqlText="UPDATE " + TABLENAME + " SET " +
			"Id=@Id, Field1=@Field1, Field2=@Field2 WHERE Id=@IdOriginal";
		SqlCommand updateCommand = new SqlCommand(sqlText, conn);
		updateCommand.Parameters.Add("@Id", SqlDbType.Int, 0, "Id");
		updateCommand.Parameters.Add("@Field1", SqlDbType.NVarChar, 50, "Field1");
		updateCommand.Parameters.Add("@Field2", SqlDbType.NVarChar, 50, "Field2");
		updateCommand.Parameters.Add("@IdOriginal", SqlDbType.Int, 0, "Id");
		updateCommand.Parameters["@IdOriginal"].SourceVersion = DataRowVersion.Original;
		da.UpdateCommand = updateCommand;

		// fill the table from the data source
		da.Fill(dt);
		
		// bind the default view for the table to the grid
		dataGrid.DataSource = dt.DefaultView;
	}

	private void updateButton_Click(object sender, System.EventArgs e)
	{
		// update the table to the data source
		da.Update(dt);
	}
}