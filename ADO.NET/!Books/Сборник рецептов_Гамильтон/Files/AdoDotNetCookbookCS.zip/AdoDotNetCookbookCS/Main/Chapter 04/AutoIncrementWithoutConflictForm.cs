using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class AutoIncrementWithoutConflictForm : System.Windows.Forms.Form
{
	// table name constants
	private const String CATEGORIES_TABLE		= "Categories";

	// field name constants
	private const String CATEGORYID_FIELD		= "CategoryID";
	private const String CATEGORYNAME_FIELD		= "CategoryName";
	private const String DESCRIPTION_FIELD		= "Description";

	private DataTable dt;

	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Button addButton;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.TextBox descriptionTextBox;
	private System.Windows.Forms.DataGrid categoryDataGrid;
	private System.Windows.Forms.TextBox categoryNameTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AutoIncrementWithoutConflictForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.label1 = new System.Windows.Forms.Label();
		this.categoryNameTextBox = new System.Windows.Forms.TextBox();
		this.addButton = new System.Windows.Forms.Button();
		this.label2 = new System.Windows.Forms.Label();
		this.descriptionTextBox = new System.Windows.Forms.TextBox();
		this.categoryDataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.categoryDataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 8);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(56, 16);
		this.label1.TabIndex = 5;
		this.label1.Text = "Name:";
		// 
		// categoryNameTextBox
		// 
		this.categoryNameTextBox.Location = new System.Drawing.Point(88, 8);
		this.categoryNameTextBox.Name = "categoryNameTextBox";
		this.categoryNameTextBox.TabIndex = 4;
		this.categoryNameTextBox.Text = "";
		// 
		// addButton
		// 
		this.addButton.Location = new System.Drawing.Point(208, 8);
		this.addButton.Name = "addButton";
		this.addButton.TabIndex = 3;
		this.addButton.Text = "Add";
		this.addButton.Click += new System.EventHandler(this.addButton_Click);
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 32);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(72, 16);
		this.label2.TabIndex = 7;
		this.label2.Text = "Description:";
		// 
		// descriptionTextBox
		// 
		this.descriptionTextBox.Location = new System.Drawing.Point(88, 32);
		this.descriptionTextBox.Name = "descriptionTextBox";
		this.descriptionTextBox.TabIndex = 6;
		this.descriptionTextBox.Text = "";
		// 
		// categoryDataGrid
		// 
		this.categoryDataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.categoryDataGrid.DataMember = "";
		this.categoryDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.categoryDataGrid.Location = new System.Drawing.Point(8, 64);
		this.categoryDataGrid.Name = "categoryDataGrid";
		this.categoryDataGrid.ReadOnly = true;
		this.categoryDataGrid.Size = new System.Drawing.Size(388, 268);
		this.categoryDataGrid.TabIndex = 8;
		// 
		// AutoIncrementWithoutConflictForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(408, 342);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.categoryDataGrid,
																		this.label2,
																		this.descriptionTextBox,
																		this.label1,
																		this.categoryNameTextBox,
																		this.addButton});
		this.Name = "AutoIncrementWithoutConflictForm";
		this.Text = "4.01 AutoIncrementWithoutConflictForm";
		this.Load += new System.EventHandler(this.AutoIncrementWithoutConflictForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.categoryDataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void AutoIncrementWithoutConflictForm_Load(object sender, System.EventArgs e)
	{
		// create the Categories table
		dt = new DataTable(CATEGORIES_TABLE);

		// add the identity column
		DataColumn col = dt.Columns.Add(CATEGORYID_FIELD, typeof(System.Int32));            
		col.AllowDBNull = false;
		col.AutoIncrement = true;
		col.AutoIncrementSeed = -1;
		col.AutoIncrementStep = -1;
		// set the primary key
		dt.PrimaryKey = new DataColumn[] {col};

		// add the other columns
		col = dt.Columns.Add(CATEGORYNAME_FIELD, typeof(System.String));
		col.AllowDBNull = false;
		col.MaxLength = 15;
		dt.Columns.Add(DESCRIPTION_FIELD, typeof(System.String));

		// fill the table
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Categories", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		da.Fill(dt);

		// bind the default view for the table to the grid
		categoryDataGrid.DataSource = dt.DefaultView;		
	}

	private void addButton_Click(object sender, System.EventArgs e)
	{
		// add a new row
		DataRow row = dt.NewRow();
		row[CATEGORYNAME_FIELD] = categoryNameTextBox.Text;
		row[DESCRIPTION_FIELD] = descriptionTextBox.Text;
		dt.Rows.Add(row);
	}
}