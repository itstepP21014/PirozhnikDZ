using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

public class SpParameterForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button goButton;
	private System.Windows.Forms.RadioButton commandBuilderRadioButton;
	private System.Windows.Forms.RadioButton spRadioButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public SpParameterForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.goButton = new System.Windows.Forms.Button();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.commandBuilderRadioButton = new System.Windows.Forms.RadioButton();
		this.spRadioButton = new System.Windows.Forms.RadioButton();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// goButton
		// 
		this.goButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.goButton.Location = new System.Drawing.Point(392, 8);
		this.goButton.Name = "goButton";
		this.goButton.Size = new System.Drawing.Size(88, 23);
		this.goButton.TabIndex = 0;
		this.goButton.Text = "Go";
		this.goButton.Click += new System.EventHandler(this.goButton_Click);
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 64);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.ReadOnly = true;
		this.dataGrid.Size = new System.Drawing.Size(476, 192);
		this.dataGrid.TabIndex = 1;
		// 
		// commandBuilderRadioButton
		// 
		this.commandBuilderRadioButton.Checked = true;
		this.commandBuilderRadioButton.Location = new System.Drawing.Point(8, 8);
		this.commandBuilderRadioButton.Name = "commandBuilderRadioButton";
		this.commandBuilderRadioButton.Size = new System.Drawing.Size(208, 24);
		this.commandBuilderRadioButton.TabIndex = 0;
		this.commandBuilderRadioButton.TabStop = true;
		this.commandBuilderRadioButton.Text = "CommandBuilder.DeriveParameters";
		// 
		// spRadioButton
		// 
		this.spRadioButton.Location = new System.Drawing.Point(8, 32);
		this.spRadioButton.Name = "spRadioButton";
		this.spRadioButton.Size = new System.Drawing.Size(208, 24);
		this.spRadioButton.TabIndex = 1;
		this.spRadioButton.Text = "sp_sproc_columns";
		// 
		// SpParameterForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.spRadioButton,
																		this.commandBuilderRadioButton,
																		this.dataGrid,
																		this.goButton});
		this.Name = "SpParameterForm";
		this.Text = "4.09 GetSPParameterForm";
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void goButton_Click(object sender, System.EventArgs e)
	{
		String procedureName = "Sales by Year";

		// create the table to hold the results
		DataTable dt = new DataTable();

		if(commandBuilderRadioButton.Checked)
		{
			// build a command object for the 'Sales by Year' stored procedure
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);				
			SqlCommand cmd = new SqlCommand(procedureName, conn);
			cmd.CommandType = CommandType.StoredProcedure;
			
			// get the parameters
			conn.Open();
			SqlCommandBuilder.DeriveParameters(cmd);
			conn.Close();

			// define table columns to hold the results
			dt.Columns.Add("Name");
			dt.Columns.Add("Direction");
			dt.Columns.Add("SqlType");

			// retrieve the results from the command object to the table
			foreach (SqlParameter param in cmd.Parameters)
				dt.Rows.Add(new object[] {param.ParameterName, param.Direction.ToString(), param.SqlDbType.ToString()});

			dataGrid.CaptionText = "Stored procedure '" + procedureName + "' parameters using CommandBuilder.DeriveParameters";
		}
		else if(spRadioButton.Checked)
		{
			// build an command object to use SQL Server stored procedure
			// to retrieve parameters
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			SqlCommand cmd = new SqlCommand("sp_sproc_columns", conn);
			cmd.CommandType = CommandType.StoredProcedure;
			SqlParameter param = cmd.Parameters.Add("@procedure_name", SqlDbType.NVarChar, 390);
			param.Value = procedureName;

			// fill the results table
			SqlDataAdapter da = new SqlDataAdapter(cmd);
			da.Fill(dt);

			dataGrid.CaptionText = "Stored procedure '" + procedureName + "' parameters using sp_proc_columns.";
		}

		// bind the default view of the results table to the grid
		dataGrid.DataSource = dt.DefaultView;
	}
}