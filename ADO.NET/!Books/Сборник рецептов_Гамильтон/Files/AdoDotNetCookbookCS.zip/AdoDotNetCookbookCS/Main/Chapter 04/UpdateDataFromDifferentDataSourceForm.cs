using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;

public class UpdateDataFromDifferentDataSourceForm : System.Windows.Forms.Form
{
	private DataSet dsSource, dsDest;
	private SqlDataAdapter daSource, daDest;

	private System.Windows.Forms.DataGrid dataGridSource;
	private System.Windows.Forms.DataGrid dataGridDest;
	private System.Windows.Forms.Button updateDestButton;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public UpdateDataFromDifferentDataSourceForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGridSource = new System.Windows.Forms.DataGrid();
		this.dataGridDest = new System.Windows.Forms.DataGrid();
		this.updateDestButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGridSource)).BeginInit();
		((System.ComponentModel.ISupportInitialize)(this.dataGridDest)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGridSource
		// 
		this.dataGridSource.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGridSource.CaptionText = "Source";
		this.dataGridSource.DataMember = "";
		this.dataGridSource.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGridSource.Location = new System.Drawing.Point(8, 8);
		this.dataGridSource.Name = "dataGridSource";
		this.dataGridSource.Size = new System.Drawing.Size(504, 150);
		this.dataGridSource.TabIndex = 0;
		// 
		// dataGridDest
		// 
		this.dataGridDest.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGridDest.CaptionText = "Destination";
		this.dataGridDest.DataMember = "";
		this.dataGridDest.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGridDest.Location = new System.Drawing.Point(8, 168);
		this.dataGridDest.Name = "dataGridDest";
		this.dataGridDest.ReadOnly = true;
		this.dataGridDest.Size = new System.Drawing.Size(504, 150);
		this.dataGridDest.TabIndex = 1;
		// 
		// updateDestButton
		// 
		this.updateDestButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.updateDestButton.Location = new System.Drawing.Point(400, 328);
		this.updateDestButton.Name = "updateDestButton";
		this.updateDestButton.Size = new System.Drawing.Size(112, 23);
		this.updateDestButton.TabIndex = 6;
		this.updateDestButton.Text = "Update Destination";
		this.updateDestButton.Click += new System.EventHandler(this.updateDestButton_Click);
		// 
		// UpdateDataFromDifferentDataSourceForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(520, 358);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.updateDestButton,
																		this.dataGridDest,
																		this.dataGridSource});
		this.Name = "UpdateDataFromDifferentDataSourceForm";
		this.Text = "4.07 UpdateDataFromDifferentDataSourceForm";
		this.Load += new System.EventHandler(this.UpdateDataFromDifferentDataSourceForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGridSource)).EndInit();
		((System.ComponentModel.ISupportInitialize)(this.dataGridDest)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void UpdateDataFromDifferentDataSourceForm_Load(object sender, System.EventArgs e)
	{
		// create the DataAdapter for the source records
		daSource = new SqlDataAdapter("SELECT * FROM Customers", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommandBuilder cbSource = new SqlCommandBuilder(daSource);
		dsSource = new DataSet();
		// get the schema and data for the source
		daSource.FillSchema(dsSource, SchemaType.Source, "Customers");
		daSource.Fill(dsSource, "Customers");
		// bind the default view of the customers table to the grid
		dataGridSource.DataSource = dsSource.Tables["Customers"].DefaultView;

		// create the DataAdapter for the destination records
		daDest = new SqlDataAdapter("SELECT * FROM Customers", ConfigurationSettings.AppSettings["Sql_Msde_ConnectString"]);
		SqlCommandBuilder cbDest = new SqlCommandBuilder(daDest);
		dsDest = new DataSet();
		// get the schema and data for the destination
		daDest.FillSchema(dsDest, SchemaType.Source, "Customers");
		daDest.Fill(dsDest, "Customers");
		// bind the default view of the customers table to the grid
		dataGridDest.DataSource = dsDest.Tables["Customers"].DefaultView;
	}

	private void updateDestButton_Click(object sender, System.EventArgs e)
	{
		try
		{
			// create a DataSet of the added, modified, and deleted records
			DataSet dsDelta = dsSource.GetChanges();
			if (dsDelta != null)
				// update the destination with the delta DataSet
				daDest.Update(dsDelta, "Customers");

			// reload the destination DataSet
			dsDest.Clear();
			daDest.Fill(dsDest, "Customers");

			// update the source
			daSource.Update(dsSource, "Customers");
		}
		catch(Exception ex)
		{
			MessageBox.Show("ERROR: " + ex.Message, "Fill Destination", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}
	}
}