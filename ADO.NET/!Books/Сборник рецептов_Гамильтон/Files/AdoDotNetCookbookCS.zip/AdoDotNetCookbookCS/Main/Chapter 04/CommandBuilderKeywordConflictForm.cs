using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

public class CommandBuilderKeywordConflictForm : System.Windows.Forms.Form
{
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox quotePrefixTextBox;
	private System.Windows.Forms.TextBox quoteSuffixTextBox;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.Button previewButton;
	private System.Windows.Forms.RadioButton oleDbRadioButton;
	private System.Windows.Forms.RadioButton sqlRadioButton;
	private System.Windows.Forms.Button retrieveOleDbButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public CommandBuilderKeywordConflictForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.quotePrefixTextBox = new System.Windows.Forms.TextBox();
		this.quoteSuffixTextBox = new System.Windows.Forms.TextBox();
		this.label2 = new System.Windows.Forms.Label();
		this.previewButton = new System.Windows.Forms.Button();
		this.oleDbRadioButton = new System.Windows.Forms.RadioButton();
		this.sqlRadioButton = new System.Windows.Forms.RadioButton();
		this.retrieveOleDbButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.resultTextBox.Location = new System.Drawing.Point(8, 64);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
		this.resultTextBox.Size = new System.Drawing.Size(476, 242);
		this.resultTextBox.TabIndex = 6;
		this.resultTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 12);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(72, 16);
		this.label1.TabIndex = 2;
		this.label1.Text = "Quote Prefix:";
		// 
		// quotePrefixTextBox
		// 
		this.quotePrefixTextBox.Location = new System.Drawing.Point(88, 8);
		this.quotePrefixTextBox.Name = "quotePrefixTextBox";
		this.quotePrefixTextBox.Size = new System.Drawing.Size(48, 20);
		this.quotePrefixTextBox.TabIndex = 0;
		this.quotePrefixTextBox.Text = "";
		// 
		// quoteSuffixTextBox
		// 
		this.quoteSuffixTextBox.Location = new System.Drawing.Point(88, 32);
		this.quoteSuffixTextBox.Name = "quoteSuffixTextBox";
		this.quoteSuffixTextBox.Size = new System.Drawing.Size(48, 20);
		this.quoteSuffixTextBox.TabIndex = 1;
		this.quoteSuffixTextBox.Text = "";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 36);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(72, 16);
		this.label2.TabIndex = 4;
		this.label2.Text = "Quote Suffix:";
		// 
		// previewButton
		// 
		this.previewButton.Location = new System.Drawing.Point(296, 8);
		this.previewButton.Name = "previewButton";
		this.previewButton.TabIndex = 4;
		this.previewButton.Text = "Preview";
		this.previewButton.Click += new System.EventHandler(this.previewButton_Click);
		// 
		// oleDbRadioButton
		// 
		this.oleDbRadioButton.Checked = true;
		this.oleDbRadioButton.Location = new System.Drawing.Point(160, 8);
		this.oleDbRadioButton.Name = "oleDbRadioButton";
		this.oleDbRadioButton.Size = new System.Drawing.Size(64, 24);
		this.oleDbRadioButton.TabIndex = 2;
		this.oleDbRadioButton.TabStop = true;
		this.oleDbRadioButton.Text = "OLE DB";
		// 
		// sqlRadioButton
		// 
		this.sqlRadioButton.Location = new System.Drawing.Point(160, 32);
		this.sqlRadioButton.Name = "sqlRadioButton";
		this.sqlRadioButton.TabIndex = 3;
		this.sqlRadioButton.Text = "SQL Server";
		// 
		// retrieveOleDbButton
		// 
		this.retrieveOleDbButton.Location = new System.Drawing.Point(376, 8);
		this.retrieveOleDbButton.Name = "retrieveOleDbButton";
		this.retrieveOleDbButton.Size = new System.Drawing.Size(104, 23);
		this.retrieveOleDbButton.TabIndex = 5;
		this.retrieveOleDbButton.Text = "Retrieve OLE DB";
		this.retrieveOleDbButton.Click += new System.EventHandler(this.retrieveOleDbButton_Click);
		// 
		// CommandBuilderKeywordConflictForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 316);
		this.Controls.Add(this.retrieveOleDbButton);
		this.Controls.Add(this.sqlRadioButton);
		this.Controls.Add(this.oleDbRadioButton);
		this.Controls.Add(this.previewButton);
		this.Controls.Add(this.quoteSuffixTextBox);
		this.Controls.Add(this.quotePrefixTextBox);
		this.Controls.Add(this.resultTextBox);
		this.Controls.Add(this.label2);
		this.Controls.Add(this.label1);
		this.Name = "CommandBuilderKeywordConflictForm";
		this.Text = "4.13 CommandBuilderKeywordConflictForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void previewButton_Click(object sender, System.EventArgs e)
	{
		String sqlText = "SELECT OrderID, ProductID, Quantity, UnitPrice, " +
			"Discount FROM [Order Details]";

		if (oleDbRadioButton.Checked)
		{
			// build the DataAdapter and the CommandBuilder
			OleDbDataAdapter da = new OleDbDataAdapter(sqlText, ConfigurationSettings.AppSettings["OleDb_ConnectString"]);
			OleDbCommandBuilder cb = new OleDbCommandBuilder(da);

			// set the prefix and suffix
			cb.QuotePrefix = quotePrefixTextBox.Text;
			cb.QuoteSuffix = quoteSuffixTextBox.Text;

			// display CommandBuilder commands with the prefix and suffix
			resultTextBox.Text =
				"DeleteCommand: " + cb.GetDeleteCommand().CommandText + Environment.NewLine + Environment.NewLine +
				"InsertCommand: " + cb.GetInsertCommand().CommandText + Environment.NewLine + Environment.NewLine +
				"UpdateCommand: " + cb.GetUpdateCommand().CommandText;		
		}
		else
		{
			// build the DataAdapter and the CommandBuilder
			SqlDataAdapter da = new SqlDataAdapter(sqlText, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
			SqlCommandBuilder cb = new SqlCommandBuilder(da);

			// set the prefix and suffix
			cb.QuotePrefix = quotePrefixTextBox.Text;
			cb.QuoteSuffix = quoteSuffixTextBox.Text;

			// display the CommandBuilder commands with the prefix and suffix
			resultTextBox.Text =
				"DeleteCommand: " + cb.GetDeleteCommand().CommandText + Environment.NewLine + Environment.NewLine +
				"InsertCommand: " + cb.GetInsertCommand().CommandText + Environment.NewLine + Environment.NewLine +
				"UpdateCommand: " + cb.GetUpdateCommand().CommandText;		
		}
	}

	private void retrieveOleDbButton_Click(object sender, System.EventArgs e)
	{
		// retrieve the quote prefix and suffix for the server
		OleDbConnection conn = new OleDbConnection(ConfigurationSettings.AppSettings["OleDb_ConnectString"]);
		conn.Open();
		DataTable tableSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.DbInfoLiterals, new object[] {});
		conn.Close();

		// set the primary key to enable find on LiteralName column
		tableSchema.PrimaryKey = new DataColumn[] {tableSchema.Columns["LiteralName"]};
		
		// get the prefix and suffix from the OleDbLiteral enumeration
		DataRow row;
		row = tableSchema.Rows.Find("Quote_Prefix");
		quotePrefixTextBox.Text = ((row == null) ? "" : row["LiteralValue"].ToString());
		row = tableSchema.Rows.Find("Quote_Suffix");
		quoteSuffixTextBox.Text = ((row == null) ? "" : row["LiteralValue"].ToString());		
	}
}