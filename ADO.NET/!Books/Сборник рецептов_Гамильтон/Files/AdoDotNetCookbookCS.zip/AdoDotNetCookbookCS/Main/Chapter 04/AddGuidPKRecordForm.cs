using System;

using System.Data;
using System.Data.SqlClient;

public class AddGuidPKRecordForm : System.Windows.Forms.Form
{
	// table name constants
	private const String PARENTTABLENAME	= "ParentTable";
	private const String CHILDTABLENAME		= "ChildTable";

	// table column name constants for Parent table
	private const String PARENTID_FIELD		= "ParentId";
	private const String FIELD1_FIELD		= "Field1";
	private const String FIELD2_FIELD		= "Field2";

	// table column parameter name constants for Parent table
	private const String CHILDID_FIELD		= "ChildId";
	private const String FIELD3_FIELD		= "Field3";
	private const String FIELD4_FIELD		= "Field4";

	private DataSet ds;

	private System.Windows.Forms.DataGrid dataGrid;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public AddGuidPKRecordForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 248);
		this.dataGrid.TabIndex = 2;
		// 
		// AddGuidPKRecordForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.dataGrid});
		this.Name = "AddGuidPKRecordForm";
		this.Text = "4.06 AddGuidPKRecordForm";
		this.Load += new System.EventHandler(this.AddGuidPKRecordForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void AddGuidPKRecordForm_Load(object sender, System.EventArgs e)
	{
		DataColumnCollection cols;
		DataColumn col;

		// build the parent table
		DataTable parentTable = new DataTable(PARENTTABLENAME);
		cols = parentTable.Columns;
		col = cols.Add(PARENTID_FIELD, typeof(Guid));
		col.DefaultValue = Guid.NewGuid();
		parentTable.PrimaryKey = new DataColumn[] {col};
		cols.Add(FIELD1_FIELD, typeof(String)).MaxLength = 50;
		cols.Add(FIELD2_FIELD, typeof(String)).MaxLength = 50;

		// build the child table
		DataTable childTable = new DataTable(CHILDTABLENAME);
		cols = childTable.Columns;
		col = cols.Add(CHILDID_FIELD, typeof(Guid));
		col.DefaultValue = Guid.NewGuid();
		childTable.PrimaryKey = new DataColumn[] {col};
		cols.Add(PARENTID_FIELD, typeof(Guid)).AllowDBNull = false;
		cols.Add(FIELD3_FIELD, typeof(String)).MaxLength = 50;
		cols.Add(FIELD4_FIELD, typeof(String)).MaxLength = 50;

		// add the tables to the DataSet and create the relationship between them
		ds = new DataSet();
		ds.Tables.Add(parentTable);
		ds.Tables.Add(childTable);
		ds.Relations.Add(new DataRelation("Parent_Child_Relation",
			parentTable.Columns[PARENTID_FIELD], childTable.Columns[PARENTID_FIELD], true));

		// bind the parent table default view to the grid
		dataGrid.DataSource = parentTable.DefaultView;

		// event handlers to generate new GUIDs for primary keys
		parentTable.RowChanging += new DataRowChangeEventHandler(parentTable_RowChanging);
		childTable.RowChanging += new DataRowChangeEventHandler(childTable_RowChanging);
	}

	private void parentTable_RowChanging(object sender, DataRowChangeEventArgs e)
	{
		if(e.Action == DataRowAction.Add)
			ds.Tables[PARENTTABLENAME].Columns[PARENTID_FIELD].DefaultValue = Guid.NewGuid();
	}

	private void childTable_RowChanging(object sender, DataRowChangeEventArgs e)
	{
		if(e.Action == DataRowAction.Add)
			ds.Tables[CHILDTABLENAME].Columns[CHILDID_FIELD].DefaultValue = Guid.NewGuid();
	}
}