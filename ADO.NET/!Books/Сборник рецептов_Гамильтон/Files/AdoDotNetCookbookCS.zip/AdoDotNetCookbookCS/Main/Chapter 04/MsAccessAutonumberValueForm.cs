using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.OleDb;

public class MsAccessAutonumberValueForm : System.Windows.Forms.Form
{
	// dt name constants
	private const String CATEGORIES_TABLE		= "Categories";

	// field name constants
	private const String CATEGORYID_FIELD		= "CategoryID";
	private const String CATEGORYNAME_FIELD		= "CategoryName";
	private const String DESCRIPTION_FIELD		= "Description";

	// stored procedure name constants
	public const String GETCATEGORIES_SP		= "GetCategories";
	public const String INSERTCATEGORIES_SP		= "InsertCategories";

	// stored procedure parameter name constants for Categories dt
	public const String CATEGORYID_PARM			= "@CategoryID";
	public const String CATEGORYNAME_PARM		= "@CategoryName";
	public const String DESCRIPTION_PARM		= "@Description";

	private DataTable dt;
	private OleDbDataAdapter da;

	private System.Windows.Forms.Button addButton;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.TextBox descriptionTextBox;
	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.TextBox resultTextBox;
	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.TextBox categoryNameTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public MsAccessAutonumberValueForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.addButton = new System.Windows.Forms.Button();
		this.label2 = new System.Windows.Forms.Label();
		this.descriptionTextBox = new System.Windows.Forms.TextBox();
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.resultTextBox = new System.Windows.Forms.TextBox();
		this.label1 = new System.Windows.Forms.Label();
		this.categoryNameTextBox = new System.Windows.Forms.TextBox();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// addButton
		// 
		this.addButton.Location = new System.Drawing.Point(260, 8);
		this.addButton.Name = "addButton";
		this.addButton.TabIndex = 2;
		this.addButton.Text = "Add";
		this.addButton.Click += new System.EventHandler(this.addButton_Click);
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 41);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(88, 16);
		this.label2.TabIndex = 12;
		this.label2.Text = "Description:";
		// 
		// descriptionTextBox
		// 
		this.descriptionTextBox.Location = new System.Drawing.Point(104, 41);
		this.descriptionTextBox.Name = "descriptionTextBox";
		this.descriptionTextBox.Size = new System.Drawing.Size(228, 20);
		this.descriptionTextBox.TabIndex = 1;
		this.descriptionTextBox.Text = "";
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 161);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(326, 96);
		this.dataGrid.TabIndex = 3;
		// 
		// resultTextBox
		// 
		this.resultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.resultTextBox.Location = new System.Drawing.Point(8, 81);
		this.resultTextBox.Multiline = true;
		this.resultTextBox.Name = "resultTextBox";
		this.resultTextBox.ReadOnly = true;
		this.resultTextBox.Size = new System.Drawing.Size(326, 72);
		this.resultTextBox.TabIndex = 10;
		this.resultTextBox.Text = "";
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 9);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(88, 16);
		this.label1.TabIndex = 9;
		this.label1.Text = "Category Name:";
		// 
		// categoryNameTextBox
		// 
		this.categoryNameTextBox.Location = new System.Drawing.Point(104, 9);
		this.categoryNameTextBox.Name = "categoryNameTextBox";
		this.categoryNameTextBox.Size = new System.Drawing.Size(144, 20);
		this.categoryNameTextBox.TabIndex = 0;
		this.categoryNameTextBox.Text = "";
		// 
		// MsAccessAutonumberValueForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(342, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.label2,
																		this.descriptionTextBox,
																		this.dataGrid,
																		this.resultTextBox,
																		this.label1,
																		this.categoryNameTextBox,
																		this.addButton});
		this.Name = "MsAccessAutonumberValueForm";
		this.Text = "4.03 MsAccessAutonumberValueForm";
		this.Load += new System.EventHandler(this.MsAccessAutonumberValueForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void MsAccessAutonumberValueForm_Load(object sender, System.EventArgs e)
	{
		// create the Categories dt
		dt = new DataTable(CATEGORIES_TABLE);

		// add the identity column
		DataColumn col = dt.Columns.Add(CATEGORYID_FIELD, typeof(System.Int32));            
		col.AllowDBNull = false;
		col.AutoIncrement = true;
		col.AutoIncrementSeed = -1;
		col.AutoIncrementStep = -1;
		// set the primary key
		dt.PrimaryKey = new DataColumn[] {col};

		// add the other columns
		col = dt.Columns.Add(CATEGORYNAME_FIELD, typeof(System.String));
		col.AllowDBNull = false;
		col.MaxLength = 15;
		dt.Columns.Add(DESCRIPTION_FIELD, typeof(System.String));

		// create the DataAdapter
		String sqlSelect = "SELECT CategoryID, CategoryName, Description FROM Categories";
		da = new OleDbDataAdapter(sqlSelect, ConfigurationSettings.AppSettings["MsAccess_ConnectString"]);

		// create the insert command for the DataAdapter
		String sqlInsert = "INSERT INTO Categories(CategoryName, Description) VALUES (?, ?)";
		da.InsertCommand = new OleDbCommand(sqlInsert, da.SelectCommand.Connection);
		da.InsertCommand.Parameters.Add(CATEGORYNAME_PARM, OleDbType.Char, 15, CATEGORYNAME_FIELD);
		da.InsertCommand.Parameters.Add(DESCRIPTION_PARM, OleDbType.VarChar, 100, DESCRIPTION_FIELD);

		// handle this event to retrieve the autonumber value
		da.RowUpdated += new OleDbRowUpdatedEventHandler(OnRowUpdated);

		// fill the table with data
		try
		{
			da.Fill(dt);
		}
		catch (OleDbException ex)
		{
			MessageBox.Show(ex.Message);
		}

		// bind the default dt view to the grid
		dataGrid.DataSource = dt.DefaultView;		
	}

	private void addButton_Click(object sender, System.EventArgs e)
	{
		// add the row to the Category table
		DataRow row = dt.NewRow();
		row[CATEGORYNAME_FIELD] = categoryNameTextBox.Text;
		row[DESCRIPTION_FIELD] = descriptionTextBox.Text;
		dt.Rows.Add(row);

		resultTextBox.Text = "Identity value before update = " + row[CATEGORYID_FIELD] + Environment.NewLine;

		// update the table with the new row
		try
		{
			da.Update(dt);
			resultTextBox.Text += "Identity value after update = " + row[CATEGORYID_FIELD] + Environment.NewLine + Environment.NewLine;
		}
		catch(OleDbException ex)
		{
			MessageBox.Show(ex.Message);
		}
	}

	private void OnRowUpdated(object Sender, OleDbRowUpdatedEventArgs args)
	{
		// retrieve autonumber value for inserts only
		if(args.StatementType == StatementType.Insert)
		{
			// SQL command to retrieve the identity value created
			OleDbCommand cmd = new OleDbCommand("SELECT @@IDENTITY", da.SelectCommand.Connection);

			// store the new identity value to the CategoryID in the table
			args.Row[CATEGORYID_FIELD] = (int)cmd.ExecuteScalar();
		}
	}
}