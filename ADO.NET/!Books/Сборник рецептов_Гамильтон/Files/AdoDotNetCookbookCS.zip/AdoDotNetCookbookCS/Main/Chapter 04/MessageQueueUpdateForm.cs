using System;
using System.Configuration;
using System.Windows.Forms;

using System.Messaging;

using System.Data;
using System.Data.SqlClient;

public class MessageQueueUpdateForm : System.Windows.Forms.Form
{
	private const String CUSTOMERS_TABLE	= "Customers";

	private const String QUEUENAMEUPDATE	= @".\Private$\adodotnetcb0413update";
	private const String QUEUENAMERESULT	= @".\Private$\adodotnetcb0413result";

	private DataSet ds;

	private System.Windows.Forms.DataGrid dataGrid;
	private System.Windows.Forms.Button sendUpdateButton;
	private System.Windows.Forms.Button processUpdateButton;
	private System.Windows.Forms.Button receiveUpdateButton;

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public MessageQueueUpdateForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.dataGrid = new System.Windows.Forms.DataGrid();
		this.sendUpdateButton = new System.Windows.Forms.Button();
		this.processUpdateButton = new System.Windows.Forms.Button();
		this.receiveUpdateButton = new System.Windows.Forms.Button();
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
		this.SuspendLayout();
		// 
		// dataGrid
		// 
		this.dataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
		this.dataGrid.DataMember = "";
		this.dataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
		this.dataGrid.Location = new System.Drawing.Point(8, 8);
		this.dataGrid.Name = "dataGrid";
		this.dataGrid.Size = new System.Drawing.Size(476, 216);
		this.dataGrid.TabIndex = 0;
		// 
		// sendUpdateButton
		// 
		this.sendUpdateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.sendUpdateButton.Location = new System.Drawing.Point(156, 232);
		this.sendUpdateButton.Name = "sendUpdateButton";
		this.sendUpdateButton.Size = new System.Drawing.Size(104, 23);
		this.sendUpdateButton.TabIndex = 1;
		this.sendUpdateButton.Text = "Send Update";
		this.sendUpdateButton.Click += new System.EventHandler(this.sendUpdateButton_Click);
		// 
		// processUpdateButton
		// 
		this.processUpdateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.processUpdateButton.Location = new System.Drawing.Point(268, 232);
		this.processUpdateButton.Name = "processUpdateButton";
		this.processUpdateButton.Size = new System.Drawing.Size(104, 23);
		this.processUpdateButton.TabIndex = 2;
		this.processUpdateButton.Text = "Process Update";
		this.processUpdateButton.Click += new System.EventHandler(this.processUpdateButton_Click);
		// 
		// receiveUpdateButton
		// 
		this.receiveUpdateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
		this.receiveUpdateButton.Location = new System.Drawing.Point(380, 232);
		this.receiveUpdateButton.Name = "receiveUpdateButton";
		this.receiveUpdateButton.Size = new System.Drawing.Size(104, 23);
		this.receiveUpdateButton.TabIndex = 3;
		this.receiveUpdateButton.Text = "Receive Update";
		this.receiveUpdateButton.Click += new System.EventHandler(this.receiveUpdateButton_Click);
		// 
		// MessageQueueUpdateForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.Add(this.receiveUpdateButton);
		this.Controls.Add(this.processUpdateButton);
		this.Controls.Add(this.sendUpdateButton);
		this.Controls.Add(this.dataGrid);
		this.Name = "MessageQueueUpdateForm";
		this.Text = "4.13 MessageQueueUpdateForm";
		this.Load += new System.EventHandler(this.MessageQueueUpdateForm_Load);
		((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
		this.ResumeLayout(false);

	}
	#endregion

	private void MessageQueueUpdateForm_Load(object sender, System.EventArgs e)
	{
		// as a starting point, load the data directly
		// create the DataAdapter to load customers data
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Customers", ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		// get the schema and data for the customers table
		ds = new DataSet();
		da.FillSchema(ds, SchemaType.Source, CUSTOMERS_TABLE);
		da.Fill(ds, CUSTOMERS_TABLE);

		// bind the default view of the customers table to the grid
		dataGrid.DataSource = ds.Tables[CUSTOMERS_TABLE].DefaultView;
	}

	private void sendUpdateButton_Click(object sender, System.EventArgs e)
	{
		// create the result queue if it does not exist
		if(!MessageQueue.Exists(QUEUENAMEUPDATE))
			MessageQueue.Create(QUEUENAMEUPDATE);
	
		// create an object to access the result queue
		MessageQueue mq = new MessageQueue(QUEUENAMEUPDATE);
		// set the formatter for serialization of message bodies
		mq.Formatter = new XmlMessageFormatter(new Type[] {typeof(DataSet)});

		// create a message containing the changes
		mq.Send(ds.GetChanges());

		MessageBox.Show("Update message sent.","MessageQueue Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
	}

	private void processUpdateButton_Click(object sender, System.EventArgs e)
	{
		// create the result queue if it does not exist
		if(!MessageQueue.Exists(QUEUENAMEUPDATE))
			MessageQueue.Create(QUEUENAMEUPDATE);
	
		// create an object to access the result queue
		MessageQueue mq = new MessageQueue(QUEUENAMEUPDATE);
		// set the formatter for deserialization of message bodies
		mq.Formatter = new XmlMessageFormatter(new Type[] {typeof(DataSet)});

		// receive a message from the query queue
		System.Messaging.Message msg;
		try
		{
			msg = mq.Receive(new TimeSpan(0,0,1));
		}
		catch(MessageQueueException ex)
		{
			MessageBox.Show(ex.Message, "MessageQueue Receive Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return;
		}

		// create the DataAdapter and CommandBuilder to update
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM " + CUSTOMERS_TABLE, ConfigurationSettings.AppSettings["Sql_ConnectString"]);
		SqlCommandBuilder cb = new SqlCommandBuilder(da);

		if (msg.BodyStream.Length > 0)
		{
			// get the DataSet of changes from the message body
			DataSet dsChanges = (DataSet)msg.Body;
			
			// process the updates
			da.Update(dsChanges, CUSTOMERS_TABLE);
		}

		// get the updated DataSet
		DataSet dsUpdate = new DataSet();
		da.Fill(dsUpdate, CUSTOMERS_TABLE);

		// create the result queue if it does not exist
		if(!MessageQueue.Exists(QUEUENAMERESULT))
			MessageQueue.Create(QUEUENAMERESULT);

		// create an object to access the result queue
		mq = new MessageQueue(QUEUENAMERESULT);
		// send a message with the update DataSet to the queue
		mq.Send(dsUpdate);

		MessageBox.Show("Update processed. Refreshed DataSet sent.", "MessageQueue Process", MessageBoxButtons.OK, MessageBoxIcon.Information);
	}

	private void receiveUpdateButton_Click(object sender, System.EventArgs e)
	{
		// create the result queue if it does not exist
		if(!MessageQueue.Exists(QUEUENAMERESULT))
			MessageQueue.Create(QUEUENAMERESULT);

		// create an object to access the result queue
		MessageQueue mq = new MessageQueue(QUEUENAMERESULT);
		// set the formatter for deserialization of message bodies
		mq.Formatter = new XmlMessageFormatter(new Type[] {typeof(DataSet)});

		// receive a message from the result queue
		System.Messaging.Message msg;
		try
		{
			msg = mq.Receive(new TimeSpan(0,0,1));
		}
		catch(MessageQueueException ex)
		{
			MessageBox.Show("ERROR: " + ex.Message, "MessageQueue Receive", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return;
		}

		// refresh the DataSet underlying the DataGrid
		ds = (DataSet)msg.Body;
		dataGrid.DataSource = ds.Tables[CUSTOMERS_TABLE].DefaultView;

		MessageBox.Show("Retrieved and loaded refreshed data.", "MessageQueue Receive", MessageBoxButtons.OK, MessageBoxIcon.Information);
	}
}