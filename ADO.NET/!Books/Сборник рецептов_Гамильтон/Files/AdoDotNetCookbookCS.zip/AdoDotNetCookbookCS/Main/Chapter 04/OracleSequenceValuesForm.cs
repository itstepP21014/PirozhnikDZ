using System;
using System.Configuration;
using System.Windows.Forms;

using System.Data;
using System.Data.OracleClient;

public class OracleSequenceValuesForm : System.Windows.Forms.Form
{
	private const String STOREDPROCEDURENAME	= "SP0404_INSERT";

	// stored procedure parameter name constants for table
	private const String ID_PARM				= "pID";
	private const String FIELD1_PARM			= "pField1";
	private const String FIELD2_PARM			= "pField2";

	private System.Windows.Forms.Label label1;
	private System.Windows.Forms.Label label2;
	private System.Windows.Forms.TextBox field1TextBox;
	private System.Windows.Forms.TextBox field2TextBox;
	private System.Windows.Forms.Button insertButton;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public OracleSequenceValuesForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.field1TextBox = new System.Windows.Forms.TextBox();
		this.field2TextBox = new System.Windows.Forms.TextBox();
		this.insertButton = new System.Windows.Forms.Button();
		this.SuspendLayout();
		// 
		// label1
		// 
		this.label1.Location = new System.Drawing.Point(8, 16);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(40, 24);
		this.label1.TabIndex = 0;
		this.label1.Text = "Field1:";
		// 
		// label2
		// 
		this.label2.Location = new System.Drawing.Point(8, 40);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(40, 24);
		this.label2.TabIndex = 1;
		this.label2.Text = "Field2:";
		// 
		// field1TextBox
		// 
		this.field1TextBox.Location = new System.Drawing.Point(56, 16);
		this.field1TextBox.Name = "field1TextBox";
		this.field1TextBox.TabIndex = 2;
		this.field1TextBox.Text = "";
		// 
		// field2TextBox
		// 
		this.field2TextBox.Location = new System.Drawing.Point(56, 40);
		this.field2TextBox.Name = "field2TextBox";
		this.field2TextBox.TabIndex = 3;
		this.field2TextBox.Text = "";
		// 
		// insertButton
		// 
		this.insertButton.Location = new System.Drawing.Point(208, 16);
		this.insertButton.Name = "insertButton";
		this.insertButton.TabIndex = 4;
		this.insertButton.Text = "Insert";
		this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
		// 
		// OracleSequenceValuesForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(292, 74);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.insertButton,
																		this.field2TextBox,
																		this.field1TextBox,
																		this.label2,
																		this.label1});
		this.Name = "OracleSequenceValuesForm";
		this.Text = "4.04 OracleSequenceValuesForm";
		this.ResumeLayout(false);

	}
	#endregion

	private void insertButton_Click(object sender, System.EventArgs e)
	{
		// create the connection
		OracleConnection conn = new OracleConnection(ConfigurationSettings.AppSettings["Oracle_ConnectString"]);

		// create the command for the insert stored procedure
		OracleCommand cmd = new OracleCommand();
		cmd.Connection = conn;
		cmd.CommandText = STOREDPROCEDURENAME;
		cmd.CommandType = CommandType.StoredProcedure;
		// add the parameters and set values for them
		cmd.Parameters.Add(ID_PARM, OracleType.Int32).Direction = ParameterDirection.Output;
		cmd.Parameters.Add(FIELD1_PARM, OracleType.NVarChar, 50);
		cmd.Parameters.Add(FIELD2_PARM, OracleType.NVarChar, 50);
		cmd.Parameters[FIELD1_PARM].Value = field1TextBox.Text;
		cmd.Parameters[FIELD2_PARM].Value = field2TextBox.Text;

		// execute the insert query
		conn.Open();
		try
		{
			cmd.ExecuteNonQuery();
		}
		catch(Exception ex)
		{
			MessageBox.Show(ex.Message, "Retrieving Oracle Sequence Values", MessageBoxButtons.OK, MessageBoxIcon.Error);
			return;
		}
		finally
		{
			conn.Close();
		}

		// retrieve and display the sequence value
		int sequenceValue = (int)cmd.Parameters[ID_PARM].Value;
		MessageBox.Show("Inserted record with ID = " + sequenceValue, "Retrieving Oracle Sequence Values", MessageBoxButtons.OK, MessageBoxIcon.Information);
	}
}