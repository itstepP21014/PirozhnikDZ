using System.EnterpriseServices;
using System.Runtime.CompilerServices;
using System.Reflection;

[Transaction(TransactionOption.Required)]
public class SC0601 : ServicedComponent
{
	[AutoComplete]
	public void TranTest(bool success)
	{
		// ... do some work

		if(success)
		{
			// don't need the next line since AutoComplete
			// ContextUtil.SetComplete();
		}
		else
		{
			// vote to abort
			ContextUtil.SetAbort();
			// raise an exception
			throw new System.Exception("Error in Serviced Component 0601. Transaction aborted.");
		}
	}
}