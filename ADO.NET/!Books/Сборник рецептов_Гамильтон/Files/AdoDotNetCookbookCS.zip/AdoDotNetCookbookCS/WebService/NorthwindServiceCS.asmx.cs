using System;
using System.ComponentModel;
using System.Web.Services;

using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class NorthwindServiceCS : System.Web.Services.WebService
{
	public const String ORDERS_TABLE		= "Orders";
	public const String ORDERDETAILS_TABLE	= "OrderDetails";

	public const String ORDERID_FIELD		= "OrderID";

	public const String ORDERS_ORDERDETAILS_RELATION = "Order_OrderDetails_Relation";

	public NorthwindServiceCS()
	{
		//CODEGEN: This call is required by the ASP.NET Web Services Designer
		InitializeComponent();
	}

	#region Component Designer generated code
	
	//Required by the Web Services Designer 
	private IContainer components = null;
			
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if(disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);		
	}
	
	#endregion

	[WebMethod]
	public DataSet LoadOrders()
	{
		DataSet ds = new DataSet();

		SqlDataAdapter da;

		// fill the Order table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM Orders",
			ConfigurationSettings.AppSettings["DataConnectString"]);
		DataTable orderTable = new DataTable(ORDERS_TABLE);
		da.FillSchema(orderTable, SchemaType.Source);
		da.Fill(orderTable);
		ds.Tables.Add(orderTable);

		// fill the OrderDetails table and add it to the DataSet
		da = new SqlDataAdapter("SELECT * FROM [Order Details]",
			ConfigurationSettings.AppSettings["DataConnectString"]);
		DataTable orderDetailTable = new DataTable(ORDERDETAILS_TABLE);
		da.FillSchema(orderDetailTable, SchemaType.Source);
		da.Fill(orderDetailTable);
		ds.Tables.Add(orderDetailTable);

		// create a relation between the tables
		ds.Relations.Add(ORDERS_ORDERDETAILS_RELATION,
			ds.Tables[ORDERS_TABLE].Columns[ORDERID_FIELD],
			ds.Tables[ORDERDETAILS_TABLE].Columns[ORDERID_FIELD],
			true);

		return ds;
	}

	[WebMethod]
	public bool UpdateOrders(DataSet ds)
	{
		// create the DataAdapters for order and order details tables
		SqlDataAdapter daOrders = new SqlDataAdapter("SELECT * FROM Orders",
			ConfigurationSettings.AppSettings["DataConnectString"]);
		SqlDataAdapter daOrderDetails =
			new SqlDataAdapter("SELECT * FROM [Order Details]",
			ConfigurationSettings.AppSettings["DataConnectString"]);

		// use CommandBuilder to generate update logic
		SqlCommandBuilder cbOrders = new SqlCommandBuilder(daOrders);
		SqlCommandBuilder cbOrderDetails =
			new SqlCommandBuilder(daOrderDetails);

		// update parent and child records
		daOrderDetails.Update(ds.Tables[ORDERDETAILS_TABLE].Select(null, null,
			DataViewRowState.Deleted));
		daOrders.Update(ds.Tables[ORDERS_TABLE].Select(null, null,
			DataViewRowState.Deleted));
		daOrders.Update(ds.Tables[ORDERS_TABLE].Select(null, null,
			DataViewRowState.ModifiedCurrent));
		daOrders.Update(ds.Tables[ORDERS_TABLE].Select(null, null,
			DataViewRowState.Added));
		daOrderDetails.Update(ds.Tables[ORDERDETAILS_TABLE].Select(null, null,
			DataViewRowState.ModifiedCurrent));
		daOrderDetails.Update(ds.Tables[ORDERDETAILS_TABLE].Select(null, null,
			DataViewRowState.Added));

		return true;
	}
}