using System;
using System.Configuration;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public class ADOCookbookCS0703 : System.Web.UI.Page
{
	private const String TABLENAME = "TBL0703";

	protected System.Web.UI.WebControls.HyperLink HyperLink1;
	protected System.Web.UI.WebControls.DataList dataList;

	private void Page_Load(object sender, System.EventArgs e)
	{
		if(!Page.IsPostBack)
		{
			dataList.DataSource = CreateDataSource();
			dataList.DataKeyField = "Id";
			dataList.DataBind();
		}
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.dataList.ItemCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.dataList_ItemCommand);
		this.dataList.CancelCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.dataList_CancelCommand);
		this.dataList.EditCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.dataList_EditCommand);
		this.dataList.UpdateCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.dataList_UpdateCommand);
		this.dataList.DeleteCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.dataList_DeleteCommand);
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

	private DataTable CreateDataSource()
	{
		DataTable dt = new DataTable(TABLENAME);

		// create the DataAdapter and fill the table using it
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM " + TABLENAME + " ORDER BY Id",
			ConfigurationSettings.AppSettings["DataConnectString"]);
		da.Fill(dt);
		da.FillSchema(dt, SchemaType.Source);

		// store data in session variable to store data between
		// posts to server
		Session["DataSource"] = dt;

		return dt;
	}
	
	private DataTable UpdateDataSource(DataTable dt)
	{
		// create a DataAdapter for the update
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM " + TABLENAME + " ORDER BY Id",
			ConfigurationSettings.AppSettings["DataConnectString"]);
		// create a CommandBuilder to generate update logic
		SqlCommandBuilder cb = new SqlCommandBuilder(da);

		// update the data source with changes to the table
		da.Update(dt);

		// store updated data in session variable to store data between
		// posts to server
		Session["DataSource"] = dt;

		return dt;
	}

	private void BindDataList()
	{
		// get the data from the session variable
		DataView dv = ((DataTable)Session["DataSource"]).DefaultView;

		// bind the data view to the data list
		dataList.DataSource = dv;
		dataList.DataBind();
	}

	private void dataList_CancelCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
	{
		// set the index of the item being edited out of range
		dataList.EditItemIndex = -1;

		BindDataList();
	}

	private void dataList_DeleteCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
	{
		// get the data from the session variable
		DataTable dt = (DataTable)Session["DataSource"];

		// get the ID of the row to delete
		int id = (int)dataList.DataKeys[e.Item.ItemIndex];

		// delete the row from the table
		dt.Rows.Find(id).Delete();

		// update the data source with the changes to the table
		UpdateDataSource(dt);

		//set the index of the item being edited out of range
		dataList.EditItemIndex = -1;

		BindDataList();
	}

	private void dataList_EditCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
	{
		//set the index of the selected item out of range
		dataList.SelectedIndex = -1;
		// set the index of the item being edited to the current record
		dataList.EditItemIndex = e.Item.ItemIndex;

		BindDataList();
	}

	private void dataList_ItemCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
	{
		// check if the "select" button is pressed
		if (e.CommandName == "Select")
		{
			//set the index of the item being edited out of range
			dataList.EditItemIndex = -1;
			// set the index of the selected item to the current record
			dataList.SelectedIndex = e.Item.ItemIndex;

			BindDataList();
		}				
	}

	private void dataList_UpdateCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
	{
		// get the data from the session variable
		DataTable dt = (DataTable)Session["DataSource"];

		// get the ID of the row to update
		int id = (int)dataList.DataKeys[e.Item.ItemIndex];

		// get the DataRow to update using the ID
		DataRow dr = dt.Rows.Find(id);

		// get the column values for the current record from the DataList
		dr["IntField"] = Int32.Parse(((TextBox)e.Item.FindControl("intFieldTextBox")).Text);
		dr["StringField"] = ((TextBox)e.Item.FindControl("stringFieldTextBox")).Text;

		// update the data source with the changes to the table
		UpdateDataSource(dt);

		// set the index of the item being edited out of range
		dataList.EditItemIndex = -1;
		
		BindDataList();
	}
}