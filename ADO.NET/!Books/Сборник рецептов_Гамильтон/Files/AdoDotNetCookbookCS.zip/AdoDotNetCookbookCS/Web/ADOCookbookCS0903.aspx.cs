using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class ADOCookbookCS0903 : System.Web.UI.Page
{
	protected System.Web.UI.WebControls.HyperLink HyperLink1;
	protected System.Web.UI.WebControls.DataGrid customersDataGrid;
	protected System.Web.UI.WebControls.Label cacheStatusLabel;
	protected System.Web.UI.WebControls.Button clearCacheButton;
	private DataSet ds;

	private void Page_Load(object sender, System.EventArgs e)
	{
		// load the data from database or cache and
		// display where the data came from
		if(Cache["CustomersDataSet"] == null)
		{
			LoadDataSet();
			cacheStatusLabel.Text = "DataSet retrieved from database.";
		}
		else
		{
			ds = (DataSet)Cache["CustomersDataSet"];
			cacheStatusLabel.Text = "DataSet retrieved from cache.";
		}

		if(!Page.IsPostBack)
		{
			// when page is first opened, position to first grid page
			customersDataGrid.CurrentPageIndex = 0;
			BindDataGrid();
		}
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.customersDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.customersDataGrid_PageIndexChanged);
		this.clearCacheButton.Click += new System.EventHandler(this.clearCacheButton_Click);
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

	private void LoadDataSet()
	{
		// create a DataAdapter
		String sqlText = "SELECT * FROM Customers";
		SqlDataAdapter da =
			new SqlDataAdapter(sqlText,
			ConfigurationSettings.AppSettings["DataConnectString"]);
		ds = new DataSet();
		// fill the a customers table in the DataSet with all customers
		da.Fill(ds, "Customers");

		// save the DataSet to the cache expiring in 15 seconds
		Cache.Insert("CustomersDataSet", ds, null,
			DateTime.Now.AddSeconds(15), System.TimeSpan.Zero);
	}

	private void BindDataGrid()
	{
		// bind the default view of the customers table to the grid
		customersDataGrid.DataSource = ds.Tables["Customers"].DefaultView;
		customersDataGrid.DataKeyField = "CustomerID";
		customersDataGrid.DataBind();
	}

	private void customersDataGrid_PageIndexChanged(object source,
		System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
	{
		// change the current page of the grid and rebind
		customersDataGrid.CurrentPageIndex = e.NewPageIndex;
		BindDataGrid();
	}

	private void clearCacheButton_Click(object sender, System.EventArgs e)
	{
		// remove the cache when user presses "clear" button
		Cache.Remove("CustomersDataSet");
		cacheStatusLabel.Text = "Cache cleared.";
	}

}