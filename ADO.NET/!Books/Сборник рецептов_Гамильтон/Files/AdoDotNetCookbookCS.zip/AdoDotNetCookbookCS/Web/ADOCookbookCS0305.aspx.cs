using System;

using System.Threading;
using System.Globalization;

using System.Data;
using System.Data.SqlClient;

public class ADOCookbookCS0305 : System.Web.UI.Page
{
	// this value would normally be retrieved from a user profile
	private String DEFAULTUSERCULTURE = "en-US";
	
	private CultureInfo ci;

	protected System.Web.UI.WebControls.Label Label2;
	protected System.Web.UI.WebControls.Label dateLabel;
	protected System.Web.UI.WebControls.Label Label1;
	protected System.Web.UI.WebControls.Label currentCultureLabel;
	protected System.Web.UI.WebControls.Label cultureNameLabel;
	protected System.Web.UI.WebControls.Label cultureEnglishNameLabel;
	protected System.Web.UI.WebControls.Label cultureNativeNameLabel;
	protected System.Web.UI.WebControls.RadioButton enUsRadioButton;
	protected System.Web.UI.WebControls.RadioButton enCaRadioButton;
	protected System.Web.UI.WebControls.RadioButton jaJpRadioButton;
	protected System.Web.UI.WebControls.RadioButton frFrRadioButton;
	protected System.Web.UI.WebControls.Label Label3;
	protected System.Web.UI.WebControls.Label shortDateLabel;
	protected System.Web.UI.WebControls.Label Label5;
	protected System.Web.UI.WebControls.Label Label4;
	protected System.Web.UI.WebControls.Label Label7;
	protected System.Web.UI.WebControls.Label numberLabel;
	protected System.Web.UI.WebControls.Label Label6;
	protected System.Web.UI.WebControls.Label currencyLabel;
	protected System.Web.UI.WebControls.HyperLink HyperLink1;

	private void Page_Load(object sender, System.EventArgs e)
	{
		if(!IsPostBack) 
			ci = new CultureInfo(DEFAULTUSERCULTURE);
		else
		{
			if(enUsRadioButton.Checked)
				ci = new CultureInfo("en-US");		
			else if(enCaRadioButton.Checked)
				ci = new CultureInfo("en-CA");				
			else if(jaJpRadioButton.Checked)
				ci = new CultureInfo("ja-JP");		
			else if(frFrRadioButton.Checked)
				ci = new CultureInfo("fr-FR");		
		}

		RefreshData();
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.enUsRadioButton.CheckedChanged += new System.EventHandler(this.enUsRadioButton_CheckedChanged);
		this.enCaRadioButton.CheckedChanged += new System.EventHandler(this.enCaRadioButton_CheckedChanged);
		this.jaJpRadioButton.CheckedChanged += new System.EventHandler(this.jaJpRadioButton_CheckedChanged);
		this.frFrRadioButton.CheckedChanged += new System.EventHandler(this.frFrRadioButton_CheckedChanged);
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

	private void RefreshData()
	{
		if(ci != null) 
		{ 
			Thread.CurrentThread.CurrentCulture=ci;

			cultureNameLabel.Text=CultureInfo.CurrentCulture.Name + " (" + Thread.CurrentThread.CurrentCulture.Name + ")";
			cultureEnglishNameLabel.Text=CultureInfo.CurrentCulture.EnglishName;
			cultureNativeNameLabel.Text=CultureInfo.CurrentCulture.NativeName;
		}
	
		// sample data that might come from a database
		dateLabel.Text=DateTime.Now.ToString("D");
		shortDateLabel.Text=DateTime.Now.ToString("d");
	
		Double d=12345.678;
		numberLabel.Text=d.ToString();
		
		currencyLabel.Text=d.ToString("c");
	}

	private void enUsRadioButton_CheckedChanged(object sender, System.EventArgs e)
	{
	}

	private void enCaRadioButton_CheckedChanged(object sender, System.EventArgs e)
	{
	}

	private void jaJpRadioButton_CheckedChanged(object sender, System.EventArgs e)
	{
	}

	private void frFrRadioButton_CheckedChanged(object sender, System.EventArgs e)
	{
	}
}