using System;
using System.Configuration;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

public class ADOCookbookCS0705 : System.Web.UI.Page
{
	private const String TABLENAME = "TBL0705";

	protected System.Web.UI.WebControls.DataGrid dataGrid;
	protected System.Web.UI.WebControls.LinkButton insertLinkButton;
	protected System.Web.UI.HtmlControls.HtmlInputText idTextBox;
	protected System.Web.UI.HtmlControls.HtmlInputText intFieldTextBox;
	protected System.Web.UI.HtmlControls.HtmlInputText stringFieldTextBox;
	protected System.Web.UI.WebControls.Button insertButton;
	protected System.Web.UI.WebControls.Label Label1;
	protected System.Web.UI.WebControls.HyperLink HyperLink1;

	private void Page_Load(object sender, System.EventArgs e)
	{
		if(!Page.IsPostBack)
		{
			dataGrid.DataSource = CreateDataSource();
			dataGrid.DataKeyField = "Id";
			dataGrid.DataBind();
		}
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.dataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dataGrid_PageIndexChanged);
		this.dataGrid.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dataGrid_CancelCommand);
		this.dataGrid.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dataGrid_EditCommand);
		this.dataGrid.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dataGrid_UpdateCommand);
		this.dataGrid.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dataGrid_DeleteCommand);
		this.insertButton.Click += new System.EventHandler(this.insertButton_Click);
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

	private DataTable CreateDataSource()
	{
		DataTable dt = new DataTable(TABLENAME);

		// create the DataAdapter and fill the table using it
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM " + TABLENAME + " ORDER BY Id",
			ConfigurationSettings.AppSettings["DataConnectString"]);
		da.Fill(dt);
		da.FillSchema(dt, SchemaType.Source);

		// store data in session variable to store data between
		// posts to server
		Session["DataSource"] = dt;

		return dt;
	}

	private DataTable UpdateDataSource(DataTable dt)
	{
		// create a DataAdapter for the update
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM " + TABLENAME + " ORDER BY Id",
			ConfigurationSettings.AppSettings["DataConnectString"]);
		// create a CommandBuilder to generate update logic
		SqlCommandBuilder cb = new SqlCommandBuilder(da);

		// update the data source with changes to the table
		da.Update(dt);

		// store updated data in session variable to store data between
		// posts to server
		Session["DataSource"] = dt;

		return dt;
	}

	private void BindDataGrid()
	{
		// get the data from the session variable
		DataView dv = ((DataTable)Session["DataSource"]).DefaultView;

		// bind the data view to the data grid
		dataGrid.DataSource = dv;
		dataGrid.DataBind();
	}

	private void dataGrid_CancelCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
	{
		// set the index of the item being edited out of range
		dataGrid.EditItemIndex = -1;

		BindDataGrid();
	}

	private void dataGrid_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
	{
		// get the data from the session variable
		DataTable dt = (DataTable)Session["DataSource"];

		// get the ID of the row to delete
		int id = (int)dataGrid.DataKeys[e.Item.ItemIndex];

		// delete the row from the table
		dt.Rows.Find(id).Delete();

		// update the data source with the changes to the table
		UpdateDataSource(dt);

		BindDataGrid();
	}

	private void dataGrid_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
	{
		// set the index of the item being edited to the selected item
		dataGrid.EditItemIndex = e.Item.ItemIndex;

		BindDataGrid();
	}

	private void dataGrid_UpdateCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
	{
		// get the data from the session variable
		DataTable dt = (DataTable)Session["DataSource"];

		// get the ID of the row to update
		int id = (int)dataGrid.DataKeys[e.Item.ItemIndex];

		// get the DataRow to update using the ID
		DataRow dr = dt.Rows.Find(id);

		// get the column values for the current record from the DataList
		dr["IntField"] = Int32.Parse(((TextBox)e.Item.FindControl("intFieldTextBox")).Text);
		dr["StringField"] = ((TextBox)e.Item.FindControl("stringFieldTextBox")).Text;

		// update the data source with the changes to the table
		UpdateDataSource(dt);

		// set the index of the item being edited out of range
		dataGrid.EditItemIndex = -1;

		BindDataGrid();
	}

	private void insertButton_Click(object sender, System.EventArgs e)
	{
		// get the data from the session variable
		DataTable dt = (DataTable)Session["DataSource"];

		// add the new row 
		DataRow dr = dt.NewRow();

		dr["Id"] = Int32.Parse(idTextBox.Value);
		dr["IntField"] = Int32.Parse(intFieldTextBox.Value);
		dr["StringField"] = stringFieldTextBox.Value;

		dt.Rows.Add(dr);

		// update the data source with the changes to the table
		UpdateDataSource(dt);

		// clear the controls used to add the record
		idTextBox.Value = "";
		intFieldTextBox.Value = "";
		stringFieldTextBox.Value = "";

		BindDataGrid();
	}

	private void dataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
	{
		// update the current page for the data grid
		dataGrid.CurrentPageIndex = e.NewPageIndex;

		BindDataGrid();
	}
}