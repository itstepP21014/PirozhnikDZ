using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class ADOCookbookCS0706 : System.Web.UI.Page
{
	protected System.Web.UI.WebControls.DataGrid ordersDataGrid;
	protected System.Web.UI.WebControls.DataGrid orderDetailsDataGrid;
	protected System.Web.UI.WebControls.HyperLink HyperLink1;

	private void Page_Load(object sender, System.EventArgs e)
	{
		if(!Page.IsPostBack)
		{
			DataSet ds = CreateDataSource();

			// bind the Orders data grid
			ordersDataGrid.DataSource = ds.Tables["Orders"].DefaultView;
			ordersDataGrid.DataKeyField = "OrderID";

			Page.DataBind();
		}
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.ordersDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.ordersDataGrid_PageIndexChanged);
		this.ordersDataGrid.SelectedIndexChanged += new System.EventHandler(this.ordersDataGrid_SelectedIndexChanged);
		this.orderDetailsDataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.orderDetailsDataGrid_PageIndexChanged);
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

	private DataSet CreateDataSource()
	{
		DataSet ds = new DataSet();

		// create a DataAdapter and fill the Orders table with it
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders",
			ConfigurationSettings.AppSettings["DataConnectString"]);
		da.FillSchema(ds, SchemaType.Source, "Orders");
		da.Fill(ds, "Orders");

		// create a DataAdapter and fill the Order Details table with it
		da = new SqlDataAdapter("SELECT * FROM [Order Details]",
			ConfigurationSettings.AppSettings["DataConnectString"]);
		da.FillSchema(ds, SchemaType.Source, "OrderDetails");
		da.Fill(ds, "OrderDetails");

		// add a relation between parent and child table
		ds.Relations.Add("Order_OrderDetail_Relation",
			ds.Tables["Orders"].Columns["OrderID"], ds.Tables["OrderDetails"].Columns["OrderID"]);

		// store data in session variable to store data between
		// posts to server
		Session["DataSource"] = ds;

		return ds;
	}

	private void ordersDataGrid_SelectedIndexChanged(object sender, System.EventArgs e)
	{
		// get the Orders data view from the session variable
		DataView dv = ((DataSet)Session["DataSource"]).Tables["Orders"].DefaultView;

		// bind the data view to the Orders data grid
		ordersDataGrid.DataSource = dv;

		// bind the default view of the child table to the DataGrid
		if(ordersDataGrid.SelectedIndex != -1)
		{
			// get the OrderID for the selected Order row
			int orderId = (int)ordersDataGrid.DataKeys[ordersDataGrid.SelectedIndex];

			// get the selected DataRowView from the Order table
			dv.Sort = "OrderID";
			DataRowView drv = dv[dv.Find(orderId)];

			// bind the child view to the Order Details data grid
			orderDetailsDataGrid.DataSource = drv.CreateChildView("Order_OrderDetail_Relation");

			// position on the first page of the Order Details grid
			orderDetailsDataGrid.CurrentPageIndex = 0;
		}
		else
			orderDetailsDataGrid.DataSource = null;

		Page.DataBind();
	}

	private void ordersDataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
	{
		// deselect Orders row after page change
		ordersDataGrid.SelectedIndex = -1;

		// get the Orders data from the session variable
		DataView dv = ((DataSet)Session["DataSource"]).Tables["Orders"].DefaultView;

		// bind the data view to the data grid
		ordersDataGrid.DataSource = dv;

		// update the current page in data grid
		ordersDataGrid.CurrentPageIndex = e.NewPageIndex;

		Page.DataBind();
	}

	private void orderDetailsDataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
	{
		// get the Orders data view from the session variable
		DataView dv = ((DataSet)Session["DataSource"]).Tables["Orders"].DefaultView;

		// get the OrderID for the selected Order row
		int orderId = (int)ordersDataGrid.DataKeys[ordersDataGrid.SelectedIndex];

		// get the selected DataRowView from the Order table
		dv.Sort = "OrderID";
		DataRowView drv = dv[dv.Find(orderId)];

		// bind the child view to the Order Details data grid
		orderDetailsDataGrid.DataSource = drv.CreateChildView("Order_OrderDetail_Relation");

		// update the current page index
		orderDetailsDataGrid.CurrentPageIndex = e.NewPageIndex;

		orderDetailsDataGrid.DataBind();
	}
}