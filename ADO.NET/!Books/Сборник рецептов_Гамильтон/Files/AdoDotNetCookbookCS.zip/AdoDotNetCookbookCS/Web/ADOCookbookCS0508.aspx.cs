using System;
using System.Configuration;

using System.Web.Security;

using System.Data;
using System.Data.SqlClient;

public class ADOCookbookCS0508 : System.Web.UI.Page
{
	private const String TABLENAME = "TBL0508";

	protected System.Web.UI.WebControls.TextBox userNameTextBox;
	protected System.Web.UI.WebControls.TextBox passwordTextBox;
	protected System.Web.UI.WebControls.Label Label1;
	protected System.Web.UI.WebControls.Label Label2;
	protected System.Web.UI.WebControls.Button loginButton;
	protected System.Web.UI.WebControls.Label passwordHashLabel;
	protected System.Web.UI.WebControls.Label passwordSaltLabel;
	protected System.Web.UI.WebControls.Label passwordHashDBLabel;
	protected System.Web.UI.WebControls.Button createButton;
	protected System.Web.UI.WebControls.Label statusLabel;
	protected System.Web.UI.WebControls.Label Label3;
	protected System.Web.UI.WebControls.HyperLink HyperLink1;

	private void Page_Load(object sender, System.EventArgs e)
	{
		//this page should be used in conjunction with forms-based authentication or
		//transport secured (i.e., https to protect the plaintext password from client to server)
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.loginButton.Click += new System.EventHandler(this.loginButton_Click);
		this.createButton.Click += new System.EventHandler(this.createButton_Click);
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

	private void createButton_Click(object sender, System.EventArgs e)
	{
		// create and display the password salt
		String passwordSalt = Guid.NewGuid().ToString();
		passwordSaltLabel.Text = passwordSalt;

		// create and display the password hash
		String passwordHash =
			FormsAuthentication.HashPasswordForStoringInConfigFile(
			passwordTextBox.Text + passwordSalt, "md5");
		passwordHashLabel.Text = passwordHashDBLabel.Text = passwordHash;

		// insert UserName with the password hash and salt into the database
		String sqlText = "INSERT " + TABLENAME +
			"(UserName, PasswordHash, PasswordSalt) " +
			"VALUES ('" + userNameTextBox.Text + "', '" + passwordHash +
			"', '" + passwordSalt + "')";
		SqlConnection conn = new SqlConnection(
			ConfigurationSettings.AppSettings["DataConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		conn.Open();

		try
		{
			if(cmd.ExecuteNonQuery() == 1)
				statusLabel.Text = "User created.";
			else
				statusLabel.Text = "Could not create user.";
		}
		catch(SqlException)
		{
			statusLabel.Text = "Could not create user.";
		}
		finally
		{
			conn.Close();
		}
	}

	private void loginButton_Click(object sender, System.EventArgs e)
	{
		bool isAuthenticated = false;

		// get the password hash and salt for the user
		String sqlText = "SELECT PasswordHash, PasswordSalt FROM " +
			TABLENAME + " WHERE UserName = '" + userNameTextBox.Text + "'";
		SqlConnection conn = new SqlConnection(
			ConfigurationSettings.AppSettings["DataConnectString"]);
		SqlCommand cmd = new SqlCommand(sqlText, conn);

		conn.Open();
		SqlDataReader dr = cmd.ExecuteReader();

		// get the DataReader first row containing user's password and salt
		if(dr.Read())
		{
			// get and display password hash and salt from the DataReader
			String passwordHashDB = passwordHashDBLabel.Text =
				dr.GetString(0);
			String passwordSalt = passwordSaltLabel.Text = dr.GetString(1);

			// calculate password hash based on the password entered and
			// the password salt retrieved from the database
			String passwordHash = passwordHashLabel.Text =
				FormsAuthentication.HashPasswordForStoringInConfigFile(
				passwordTextBox.Text + passwordSalt, "md5");

			// check whether the calculated hash matches the hash retrieved
			// from the database
			isAuthenticated = (passwordHash == passwordHashDB);
		}
		conn.Close();

		if(isAuthenticated)
			statusLabel.Text = "Authentication succeeded.";
		else
			statusLabel.Text = "Authentication failed.";
	}

}