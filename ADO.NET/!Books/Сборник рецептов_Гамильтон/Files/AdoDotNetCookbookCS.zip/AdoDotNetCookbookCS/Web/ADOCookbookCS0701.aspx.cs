using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class ADOCookbookCS0701 : System.Web.UI.Page
{
	protected System.Web.UI.WebControls.TextBox companyNameTextBox;
	protected System.Web.UI.WebControls.TextBox customerIdTextBox;
	protected System.Web.UI.WebControls.Button getCompanyNameButton;
	protected System.Web.UI.WebControls.Label Label1;
	protected System.Web.UI.WebControls.Label Label2;

	protected System.Web.UI.WebControls.HyperLink HyperLink1;

	private void Page_Load(object sender, System.EventArgs e)
	{
		companyNameTextBox.DataBind();
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

	public String GetCompanyName(String customerId)
	{
		object companyName = null;
		if (customerIdTextBox.Text != "")
		{
			// create a command to retrieve the company name for the
			// user-specified customer ID
			String sqlText = "SELECT CompanyName FROM Customers WHERE CustomerID='" + customerIdTextBox.Text + "'";
			SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["DataConnectString"]);
			SqlCommand cmd = new SqlCommand(sqlText, conn);
			conn.Open();
	
			// execute the command
			companyName = cmd.ExecuteScalar();

			conn.Close();
		}

		return (companyName == null) ? "Not found." : companyName.ToString();
	}
}