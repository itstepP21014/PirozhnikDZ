using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class ADOCookbookCS0707b : System.Web.UI.Page
{
	private void Page_Load(object sender, System.EventArgs e)
	{	// create the command to retrieve employee image specified
		SqlConnection conn = new SqlConnection(
			ConfigurationSettings.AppSettings["DataConnectString"]);
		String sqlText = "SELECT * FROM Employees WHERE EmployeeId = " +
			Request["EmployeeId"].ToString();
		SqlCommand cmd = new SqlCommand(sqlText, conn);
		// create a DataReader containing the record for the employee
		conn.Open();
		SqlDataReader dr = cmd.ExecuteReader();
		if(dr.Read())
		{
			// set the response content type type
			Response.ContentType = "image/bmp";
			// stream the binary image data in the response
			Response.BinaryWrite((byte[])dr["Photo"]);
		}
		dr.Close();
		conn.Close();
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.Load += new System.EventHandler(this.Page_Load);
	}
	#endregion
}