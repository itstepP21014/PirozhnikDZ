using System;
using System.Configuration;

using System.Data;
using System.Data.SqlClient;

public class ADOCookbookCS0704 : System.Web.UI.Page
{
	protected System.Web.UI.WebControls.DataGrid dataGrid;
	protected System.Web.UI.WebControls.HyperLink HyperLink1;

	private void Page_Load(object sender, System.EventArgs e)
	{
		if(!Page.IsPostBack)
		{
			dataGrid.DataSource = CreateDataSource();
			dataGrid.DataKeyField = "OrderId";
			dataGrid.DataBind();
		}
	}

	#region Web Form Designer generated code
	override protected void OnInit(EventArgs e)
	{
		//
		// CODEGEN: This call is required by the ASP.NET Web Form Designer.
		//
		InitializeComponent();
		base.OnInit(e);
	}
	
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{    
		this.dataGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dataGrid_PageIndexChanged);
		this.dataGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.dataGrid_SortCommand);
		this.Load += new System.EventHandler(this.Page_Load);

	}
	#endregion

	private DataTable CreateDataSource()
	{
		DataTable dt = new DataTable();

		// create a DataAdapter and fill the Orders table with it
		SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Orders", ConfigurationSettings.AppSettings["DataConnectString"]);
		da.Fill(dt);

		// store data in session variable to store data between
		// posts to server
		Session["DataSource"] = dt;

		return dt;
	}
	
	private void dataGrid_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
	{
		// get the data from the session variable
		DataView dv = ((DataTable)Session["DataSource"]).DefaultView;

		// update the current page for the data grid
		dataGrid.CurrentPageIndex = e.NewPageIndex;

		// bind the data view to the data grid
		dataGrid.DataSource = dv;
		dataGrid.DataBind();
	}

	private void dataGrid_SortCommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e)
	{
		// get the data from the session variable
		DataView dv = ((DataTable)Session["DataSource"]).DefaultView;

		// set the sort of the data view
		dv.Sort = e.SortExpression;

		// bind the data view to the data grid
		dataGrid.DataSource = dv;
		dataGrid.DataBind();		
	}
}