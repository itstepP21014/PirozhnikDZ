using System;
using System.Windows.Forms;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

public class MainForm : System.Windows.Forms.Form
{
	private bool isStarted = false;

	private System.Windows.Forms.Button startServerButton;
	private System.Windows.Forms.TextBox serverResultTextBox;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public MainForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.startServerButton = new System.Windows.Forms.Button();
		this.serverResultTextBox = new System.Windows.Forms.TextBox();
		this.SuspendLayout();
		// 
		// startServerButton
		// 
		this.startServerButton.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
		this.startServerButton.Location = new System.Drawing.Point(408, 232);
		this.startServerButton.Name = "startServerButton";
		this.startServerButton.TabIndex = 0;
		this.startServerButton.Text = "Start Server";
		this.startServerButton.Click += new System.EventHandler(this.startServerButton_Click);
		// 
		// serverResultTextBox
		// 
		this.serverResultTextBox.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right);
		this.serverResultTextBox.Location = new System.Drawing.Point(8, 8);
		this.serverResultTextBox.Multiline = true;
		this.serverResultTextBox.Name = "serverResultTextBox";
		this.serverResultTextBox.ReadOnly = true;
		this.serverResultTextBox.Size = new System.Drawing.Size(476, 216);
		this.serverResultTextBox.TabIndex = 1;
		this.serverResultTextBox.Text = "";
		// 
		// MainForm
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.ClientSize = new System.Drawing.Size(492, 266);
		this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		this.serverResultTextBox,
																		this.startServerButton});
		this.Name = "MainForm";
		this.Text = "ADO Cookbook Remote Server";
		this.ResumeLayout(false);

	}
	#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
		Application.Run(new MainForm());
	}

	private void startServerButton_Click(object sender, System.EventArgs e)
	{
		if (!isStarted)
		{
//				TcpServerChannel channel = new TcpServerChannel (1234);
//				ChannelServices.RegisterChannel (channel);
/*
			// well known service
			RemotingConfiguration.RegisterWellKnownServiceType(
				typeof(AdoDotNetCookbookCS.NorthwindRemoteCS.RemoteClass),
				"RemoteClass",
				WellKnownObjectMode.SingleCall);
			RemotingConfiguration.ApplicationName = "RemoteClass (WellKnownServiceType)";
*/
/*
			// activated service
			RemotingConfiguration.RegisterActivatedServiceType(typeof(RemoteClass));
			RemotingConfiguration.ApplicationName = "RemoteClass (ActivatedServiceType)";
*/				
			// config file
			RemotingConfiguration.Configure("NorthwindServerCS.exe.config");

			serverResultTextBox.Text += "Remote server started." + Environment.NewLine +
				"  ApplicationName = " + RemotingConfiguration.ApplicationName + Environment.NewLine +
				"  ApplicationId = " + RemotingConfiguration.ApplicationId + Environment.NewLine +
				"  ProcessId = " + RemotingConfiguration.ProcessId;

			isStarted = true;
		}
		else
		{
			serverResultTextBox.Text += "Remote Server already started." + Environment.NewLine;
		}
	}
}